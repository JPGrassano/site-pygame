"""A gruta do granizo: alternância entre travessia, paredes e plataformas móveis."""
from .modelo import Layout, floor, ledge

LAYOUT = Layout(
    name='A gruta do granizo',
    platforms=(
        floor(0,570,400),
        floor(520,570,420),
        (580,0,220,310),
        ledge(600,460,100),
        floor(990,510,180),
        ledge(1470,340,100),
        floor(1560,570,295),
        (1660,0,70,480),
        floor(1855,270,110),
        ledge(2080,370,95),
        floor(2230,490,170),
    ),
    checkpoints=((150, 570), (1080, 510), (1910, 270)),
    seal_feet=((2125, 370),), exit=(2320, 490),
    shafts=((1730, 1855, 570, 270),),
    movers=((1270, 550, 120, 24, 0, -210, 4.6, 0),),
    hazards=(('slush', 600, 558, 260, 12, 0), ('hail', 1240, 210, 140, 9, 1), ('hail', 2090, 230, 70, 9, 1.8)),
    illusion_x=(),
)
