"""Um arquivo por círculo. A ordem acompanha a descida de Alice."""
from .limbo import LAYOUT as LIMBO
from .luxuria import LAYOUT as LUXURIA
from .gula import LAYOUT as GULA
from .avareza import LAYOUT as AVAREZA
from .ira import LAYOUT as IRA
from .heresia import LAYOUT as HERESIA
from .violencia import LAYOUT as VIOLENCIA
from .fraude import LAYOUT as FRAUDE
from .traicao import LAYOUT as TRAICAO

LAYOUTS = (LIMBO, LUXURIA, GULA, AVAREZA, IRA, HERESIA, VIOLENCIA, FRAUDE, TRAICAO)

from .progressao import expand
LAYOUTS = tuple(expand(layout, i) for i, layout in enumerate(LAYOUTS))
