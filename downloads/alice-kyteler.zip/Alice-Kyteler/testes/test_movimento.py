"""Regressões de física e animação. Execute: py -m unittest test_movimento -v"""
import os
import unittest
from types import SimpleNamespace

os.environ['SDL_VIDEODRIVER'] = 'dummy'
import personagem


class MovementTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        personagem.pygame.display.init()
        personagem.pygame.display.set_mode((personagem.WIDTH, personagem.HEIGHT))
        platform = personagem.pygame.Rect(180, 430, 740, 150)
        cls.game = SimpleNamespace(platform=platform, player=personagem.Player(platform.midtop),
                                   animations=personagem.Animations())

    def setUp(self):
        self.player = self.game.player
        self.player.spawn = self.game.platform.midtop
        self.player.reset()

    def advance(self, seconds, controls=None):
        controls = controls or personagem.Controls()
        for _ in range(round(seconds/personagem.STEP)):
            self.player.update(personagem.STEP, controls, self.game.platform)
            controls.jump = controls.dash = False

    def place(self, feet):
        self.player.rect.midbottom = feet
        self.player.pos.update(self.player.rect.topleft)

    def test_idle_does_not_flicker(self):
        for _ in range(240):
            self.player.update(personagem.STEP, personagem.Controls(), self.game.platform)
            self.assertTrue(self.player.grounded)
            self.assertEqual(self.player.state, 'idle')
        self.assertAlmostEqual(self.player.anim_clock, 2)

    def test_run_animation_does_not_restart(self):
        previous = 0
        for _ in range(120):
            self.player.update(personagem.STEP, personagem.Controls(x=1), self.game.platform)
            if self.player.vel.x > 15:
                self.assertEqual(self.player.state, 'run')
                self.assertGreater(self.player.anim_clock, previous)
                previous = self.player.anim_clock

    def test_jump_starts_with_air_pose_and_lands(self):
        self.advance(.1)
        controls = personagem.Controls(jump=True, jump_held=True)
        for i in range(110):
            self.player.update(personagem.STEP, controls, self.game.platform)
            controls.jump = False
            if self.player.grounded:
                self.assertGreater(i, 10)
                self.assertEqual(self.player.state, 'land')
                break
            self.assertEqual(self.player.state, 'jump')
        else:
            self.fail('Não pousou')
        self.advance(.3)
        self.assertEqual(self.player.state, 'idle')

    def test_variable_jump_height(self):
        heights = []
        for held in (False, True):
            self.player.reset()
            controls = personagem.Controls(jump=True, jump_held=held)
            positions = []
            for _ in range(85):
                self.player.update(personagem.STEP, controls, self.game.platform)
                controls.jump = False
                positions.append(self.player.rect.bottom)
            heights.append(self.game.platform.top-min(positions))
        self.assertGreater(heights[1], heights[0]+50)

    def test_coyote_jump(self):
        self.place((self.game.platform.right-8, self.game.platform.top))
        self.advance(.05)
        self.advance(.16, personagem.Controls(x=1))
        self.assertFalse(self.player.grounded)
        self.advance(personagem.STEP, personagem.Controls(jump=True, jump_held=True))
        self.assertLess(self.player.vel.y, -500)

    def test_buffered_jump_before_landing(self):
        self.place((550, self.game.platform.top-12))
        self.player.vel.y = 250
        self.advance(.1, personagem.Controls(jump=True, jump_held=True))
        self.assertLess(self.player.vel.y, -400)

    def test_eight_directions_have_equal_dash_speed(self):
        for x, y in self.game.animations.dashes:
            with self.subTest(direction=(x, y)):
                self.player.reset()
                self.place((550, 250))
                self.advance(personagem.STEP, personagem.Controls(x=x, y=y, dash=True))
                self.assertAlmostEqual(self.player.vel.length(), personagem.DASH_SPEED, places=4)
                self.assertEqual(self.player.dash_direction, (x, y))

    def test_direction_and_facing_remain_fixed_during_dash(self):
        self.place((550, 250))
        self.advance(personagem.STEP, personagem.Controls(x=1, y=-1, dash=True))
        self.advance(.10, personagem.Controls(x=-1, y=1))
        self.assertEqual(self.player.dash_direction, (1, -1))
        self.assertEqual(self.player.dash_facing, 1)
        self.assertEqual(self.player.state, 'dash')
        self.assertGreater(self.player.vel.x, 0)
        self.assertLess(self.player.vel.y, 0)

    def test_vertical_dash_keeps_original_facing(self):
        self.place((550, 250))
        self.player.facing = -1
        self.advance(personagem.STEP, personagem.Controls(y=-1, dash=True))
        self.advance(.05, personagem.Controls(x=1))
        self.assertEqual(self.player.dash_facing, -1)
        self.assertEqual(self.player.dash_direction, (0, -1))

    def test_single_air_dash_and_ground_recharge(self):
        self.place((550, 250))
        self.advance(.27, personagem.Controls(y=-1, dash=True))
        self.assertEqual(self.player.dashes, 0)
        self.advance(personagem.STEP, personagem.Controls(x=1, dash=True))
        self.assertEqual(self.player.dash_time, 0)
        self.place(self.game.platform.midtop)
        self.player.vel.update(0, 0)
        self.advance(personagem.STEP)
        self.assertEqual(self.player.dashes, 1)

    def test_dash_does_not_cross_platform_side(self):
        self.place((150, 480))
        self.advance(.2, personagem.Controls(x=1, dash=True))
        self.assertEqual(self.player.rect.right, self.game.platform.left)

    def test_dash_does_not_cross_platform_underside(self):
        self.place((550, 625))
        self.advance(.1, personagem.Controls(y=-1, dash=True))
        self.assertGreaterEqual(self.player.rect.top, self.game.platform.bottom)

    def test_climb_uses_energy_and_wall_jump_pushes_away(self):
        self.place((self.game.platform.left-11, 480))
        self.advance(.2, personagem.Controls(y=-1, grab=True))
        self.assertLess(self.player.rect.bottom, 480)
        self.assertLess(self.player.stamina, personagem.MAX_STAMINA)
        self.assertEqual(self.player.state, 'climb')
        self.advance(personagem.STEP, personagem.Controls(jump=True, jump_held=True))
        self.assertLess(self.player.vel.x, 0)
        self.assertLess(self.player.vel.y, 0)

    def test_fall_resets_only_player(self):
        self.place((100, personagem.HEIGHT+200))
        self.advance(personagem.STEP)
        self.assertEqual(self.player.rect.midbottom, self.game.platform.midtop)
        self.assertEqual(tuple(self.game.platform), (180, 430, 740, 150))

    def test_all_eight_dash_animations_have_six_transparent_frames(self):
        self.assertEqual(len(self.game.animations.dashes), 8)
        for direction, frames in self.game.animations.dashes.items():
            self.assertEqual(len(frames), 6)
            for frame in frames:
                self.assertEqual(frame.pivot, (64, 100))
                self.assertEqual(frame.image.get_at((0, 0)).a, 0)
                bounds = frame.image.get_bounding_rect(min_alpha=10)
                self.assertGreater(bounds.left, 0)
                self.assertLess(bounds.right, frame.image.get_width())
                self.assertGreater(bounds.top, 0)
                self.assertLess(bounds.bottom, frame.image.get_height())

    def test_dash_animation_plays_once_without_looping(self):
        bank = self.game.animations
        for direction, frames in bank.dashes.items():
            indices = [frames.index(bank.get('dash', 1, i/600, direction=direction)) for i in range(145)]
            self.assertEqual(set(indices), set(range(6)))
            self.assertEqual(indices, sorted(indices))
            self.assertIs(bank.get('dash', 1, 9, direction=direction), frames[-1])

    def test_dash_has_visual_recovery_after_motion(self):
        self.place((550, 250))
        self.advance(.19, personagem.Controls(y=-1, dash=True))
        self.assertEqual(self.player.dash_time, 0)
        self.assertEqual(self.player.state, 'dash')
        self.advance(.09)
        self.assertEqual(self.player.state, 'jump')

    def test_ground_frame_feet_are_aligned(self):
        for state in ('idle', 'run'):
            for facing in (-1, 1):
                for frame in self.game.animations.frames[state, facing]:
                    self.assertEqual(frame.image.get_bounding_rect(min_alpha=80).bottom, 70)

    def test_audio_is_not_initialized(self):
        self.assertIsNone(personagem.pygame.mixer.get_init())

    def test_idle_breathing_is_visible_and_loops(self):
        bank = self.game.animations
        for facing in (-1, 1):
            poses = [bank.get('idle', facing, personagem.IDLE_BREATH_PERIOD*i/24) for i in range(25)]
            heights = [f.image.get_bounding_rect(min_alpha=80).height for f in poses]
            self.assertGreaterEqual(max(heights)-min(heights), 4)
            self.assertLessEqual(max(heights)-min(heights), 6)
            self.assertIs(poses[0], poses[-1])
            self.assertTrue(all(f.pivot == (36, 70) for f in poses))

    def test_idle_breathing_does_not_move_collision_or_feet(self):
        start = self.player.rect.copy()
        for _ in range(round(personagem.IDLE_BREATH_PERIOD/personagem.STEP)):
            self.player.update(personagem.STEP, personagem.Controls(), self.game.platform)
            frame = self.game.animations.get(self.player.state, self.player.facing, self.player.anim_clock)
            self.assertEqual(self.player.rect, start)
            self.assertEqual(frame.image.get_bounding_rect(min_alpha=80).bottom, 70)


if __name__ == '__main__':
    unittest.main(verbosity=2)
