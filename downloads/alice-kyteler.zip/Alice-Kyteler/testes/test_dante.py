"""Riscos novos e progressão geométrica da campanha de Dante."""
import os
import unittest
os.environ['SDL_VIDEODRIVER']='dummy'
import pygame
from perigos import Hazard
from fases import LAYOUTS
from mapa_jornada import JourneyMap
from plataformas import MovingPlatform
from fases.modelo import WORLD_WIDTH, WORLD_HEIGHT

class DanteTests(unittest.TestCase):
    def test_wall_sequences_vary_in_position_and_final_circles_combine_them(self):
        heights=[sum(s[2]-s[3] for s in layout.shafts) for layout in LAYOUTS]
        starts=[layout.shafts[0][0] for layout in LAYOUTS]
        self.assertGreaterEqual(len(set(starts)),7)
        self.assertTrue(any(x>1500 for x in starts))
        self.assertTrue(any(x<500 for x in starts))
        self.assertGreater(heights[-1],heights[0]+300)
        self.assertTrue(all(len(layout.shafts)==2 for layout in LAYOUTS[6:]))

    def test_boulders_roll_on_their_track_without_flying(self):
        hazard=Hazard('boulder',200,400,120,20,0)
        for step in range(100):
            x,y=hazard.center(step*.1)
            self.assertEqual(y,400)
            self.assertLessEqual(abs(x-200),40)
            self.assertTrue(hazard.hits(pygame.Rect(x-4,y-4,8,8),step*.1))
        self.assertFalse(hazard.hits(pygame.Rect(400,350,22,34),0))

    def test_hail_and_embers_follow_the_announced_vertical_lane(self):
        for kind in ('hail','ember'):
            hazard=Hazard(kind,200,180,100,9,0)
            for t in (0,.6,1.4,2.6):
                x,y=hazard.center(t)
                self.assertEqual(x,250)
                self.assertTrue(hazard.hits(pygame.Rect(x-3,y-3,6,6),t))
                self.assertFalse(hazard.hits(pygame.Rect(x+25,y,22,34),t))

    def test_filthy_mud_is_not_relabelled_poison(self):
        for kind in ('slush','swamp'):
            hazard=Hazard(kind,0,550,100,20,0)
            self.assertFalse(hazard.hits(pygame.Rect(10,545,22,34),1))

    def test_journey_map_loads_its_illustration_and_nine_separate_nodes(self):
        pygame.display.init()
        pygame.display.set_mode((1100,650))
        scene=JourneyMap()
        self.assertEqual(scene.backdrop.get_size(),(1100,650))
        self.assertEqual(len(set(scene.NODES)),9)
        hitboxes=[]
        for index,(x,y) in enumerate(scene.NODES):
            self.assertTrue(30<x<690 and 65<y<600)
            box=pygame.Rect(x-23,y-22,46,44)
            self.assertFalse(any(box.colliderect(other) for other in hitboxes))
            hitboxes.append(box)
            self.assertEqual(scene.preview(index).get_size(),(312,118))
        self.assertEqual(len(scene.previews),9)

    def test_moving_platforms_leave_headroom_for_their_passengers(self):
        for index,layout in enumerate(LAYOUTS):
            if index > 0: self.assertTrue(layout.movers)
            for spec in layout.movers:
                mover=MovingPlatform(*spec)
                for step in range(120):
                    rect=mover.rect_at(step*mover.period/120)
                    passenger=pygame.Rect(rect.x,rect.y-34,rect.width,34)
                    with self.subTest(circle=index+1,time=step):
                        self.assertTrue(pygame.Rect(0,0,WORLD_WIDTH,WORLD_HEIGHT).contains(rect))
                        self.assertFalse(any(passenger.colliderect(pygame.Rect(p)) for p in layout.platforms),
                                         'O trilho leva os passageiros contra uma parede ou teto')

    def test_lust_orb_crosses_the_air_above_a_landing(self):
        layout=LAYOUTS[1]
        orb=Hazard(*next(h for h in layout.hazards if h[0]=='orb'))
        platform=min((p for p in layout.platforms if p[1]>0),key=lambda p:abs(p[0]+p[2]/2-orb.x))
        corridor=pygame.Rect(platform[0]-40,platform[1]-80,platform[2]+80,80)
        self.assertTrue(any(orb.hits(corridor,step*.05) for step in range(100)),
                        'A esfera ficou abaixo da rota de salto')
