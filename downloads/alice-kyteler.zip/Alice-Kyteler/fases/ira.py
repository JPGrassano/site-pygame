"""Balsas sobre o Estige: alternância entre travessia, paredes e plataformas móveis."""
from .modelo import Layout, floor, ledge

LAYOUT = Layout(
    name='Balsas sobre o Estige',
    platforms=(
        floor(0,570,330),
        floor(820,550,220),
        floor(1040,570,370),
        (1210,0,70,480),
        floor(1410,290,110),
        floor(1620,450,190),
        floor(2200,500,200),
    ),
    checkpoints=((150, 570), (930, 550), (1710, 450)),
    seal_feet=((2280, 500),), exit=(2340, 500),
    shafts=((1280, 1410, 570, 290),),
    movers=((450, 560, 140, 24, 230, 0, 5, 0), (1880, 490, 120, 24, 150, -70, 4.2, 1.3)),
    hazards=(('swamp', 230, 558, 100, 12, 0), ('vapor', 970, 450, 60, 100, 0.5), ('vapor', 2210, 390, 55, 110, 1.5)),
    illusion_x=(),
)
