"""Pontes entre as fossas: alternância entre travessia, paredes e plataformas móveis."""
from .modelo import Layout, floor, ledge

LAYOUT = Layout(
    name='Pontes entre as fossas',
    platforms=(
        floor(0,570,540),
        (340,0,70,480),
        floor(540,330,110),
        ledge(720,390,100),
        floor(940,460,180),
        floor(1420,570,325),
        (1530,0,70,480),
        floor(1745,200,110),
        ledge(1990,320,90),
        floor(2230,480,170),
    ),
    checkpoints=((150, 570), (1030, 460), (1800, 200)),
    seal_feet=((2300, 480),), exit=(2350, 480),
    shafts=((410, 540, 570, 330), (1600, 1745, 570, 200)),
    movers=((1250, 470, 100, 24, 110, -60, 3.6, 0),),
    hazards=(('pitch', 1120, 630, 130, 20, 0), ('fire', 2240, 370, 50, 110, 1.7)),
    illusion_x=(720, 1990),
)
