"""Plataformas móveis: trajetória determinística e transporte da personagem.

Os oito números de uma plataforma são x, y, largura, altura, deslocamento x,
deslocamento y, período e fase (em segundos). A posição inicial é uma ponta
do trilho; a outra fica em (x + dx, y + dy). O movimento desacelera nas pontas.
"""
from dataclasses import dataclass
import math

import pygame


@dataclass(frozen=True)
class MovingPlatform:
    x: int
    y: int
    width: int
    height: int
    dx: int
    dy: int
    period: float
    phase: float = 0

    def __post_init__(self):
        if self.width <= 0 or self.height <= 0 or self.period <= 0:
            raise ValueError("Plataforma móvel precisa de tamanho e período positivos.")

    def rect_at(self, time):
        amount = (1-math.cos(math.tau*(time+self.phase)/self.period))/2
        return pygame.Rect(round(self.x+self.dx*amount), round(self.y+self.dy*amount),
                           self.width, self.height)

    @property
    def endpoints(self):
        return ((self.x+self.width//2, self.y+self.height//2),
                (self.x+self.dx+self.width//2, self.y+self.dy+self.height//2))


def riding_index(player, previous, grab=False):
    """Reconhece pés apoiados ou mãos agarradas antes de mover os apoios."""
    rect = player.rect
    for i, platform in enumerate(previous):
        above = rect.bottom == platform.top and rect.right > platform.left and rect.left < platform.right
        if above and player.vel.y >= 0 and player.dash_time <= 0:
            return i
    if grab and player.wall_lock <= 0 and player.stamina > 0 and player.dash_time <= 0:
        for i, platform in enumerate(previous):
            beside = abs(rect.right-platform.left) <= 2 or abs(rect.left-platform.right) <= 2
            if beside and rect.bottom > platform.top and rect.top < platform.bottom:
                return i
    return None


def transport_player(player, previous, current, static_solids, grab=False):
    """Carrega passageiros e empurra contatos laterais; retorna se houve esmagamento.

    O motor chama esta função em passos pequenos. Uma obstrução real mata de
    maneira determinística; nunca deixa a personagem presa dentro da plataforma.
    Os percursos mantêm os trilhos longe de tetos ou paredes que esmagariam Alice.
    """
    rider = riding_index(player, previous, grab)
    if rider is not None:
        old, new = previous[rider], current[rider]
        obstacles = [*static_solids, *(r for i, r in enumerate(current) if i != rider)]
        player.move(new.x-old.x, new.y-old.y, obstacles)
        if player.rect.colliderect(new):
            return True

    for i, (old, new) in enumerate(zip(previous, current)):
        if i == rider or not new.colliderect(player.rect):
            continue
        dx, dy = new.x-old.x, new.y-old.y
        # A face que entrou na personagem decide a direção do empurrão.
        pushes = []
        if dx > 0 and player.rect.left >= old.right:
            pushes.append((new.right-player.rect.left, 0))
        elif dx < 0 and player.rect.right <= old.left:
            pushes.append((new.left-player.rect.right, 0))
        if dy > 0 and player.rect.top >= old.bottom:
            pushes.append((0, new.bottom-player.rect.top))
        elif dy < 0 and player.rect.bottom <= old.top:
            pushes.append((0, new.top-player.rect.bottom))
        if not pushes:
            # Recupera um contato de um pixel causado pelo arredondamento.
            candidates = ((new.left-player.rect.right, 0), (new.right-player.rect.left, 0),
                          (0, new.top-player.rect.bottom), (0, new.bottom-player.rect.top))
            pushes = [min(candidates, key=lambda delta: abs(delta[0])+abs(delta[1]))]
        push_x, push_y = min(pushes, key=lambda delta: abs(delta[0])+abs(delta[1]))
        obstacles = [*static_solids, *(r for j, r in enumerate(current) if j != i)]
        player.move(push_x, push_y, obstacles)
        if push_y < 0:
            player.vel.y = min(0, player.vel.y)
        if player.rect.colliderect(new):
            return True
    return False


def draw_track(surface, platform, offset, color):
    """Um trilho discreto deixa previsíveis as duas pontas do movimento."""
    a, b = platform.endpoints
    a = (a[0]-offset, a[1])
    b = (b[0]-offset, b[1])
    dim = tuple(round(c*.34) for c in color)
    pygame.draw.line(surface, dim, a, b, 2)
    for x, y in (a, b):
        pygame.draw.circle(surface, (23, 23, 36), (x, y), 6)
        pygame.draw.circle(surface, dim, (x, y), 6, 1)
        pygame.draw.circle(surface, color, (x, y), 2)
