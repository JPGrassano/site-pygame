"""Pátios e pontes do castelo: alternância entre travessia, paredes e plataformas móveis."""
from .modelo import Layout, floor, ledge

LAYOUT = Layout(
    name='Pátios e pontes do castelo',
    platforms=(
        floor(0,570,380),
        ledge(480,470,150),
        floor(740,480,180),
        floor(900,570,250),
        (970,0,70,480),
        floor(1150,330,110),
        floor(1400,450,190),
        ledge(1940,350,110),
        floor(2180,490,220),
    ),
    checkpoints=((150, 570), (830, 480), (1490, 450)),
    seal_feet=((1995, 350),), exit=(2320, 490),
    shafts=((1040, 1150, 570, 330),),
    movers=((1660, 430, 120, 24, 140, -50, 4.8, 0),),
    hazards=(),
    illusion_x=(),
)
