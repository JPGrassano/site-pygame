"""Materiais ilustrados dos nove círculos, separados da colisão do mapa."""
from functools import lru_cache
from pathlib import Path

import pygame


@lru_cache(maxsize=1)
def materials():
    """Recorta o atlas uma vez. A mesma escala mantém a textura coesa."""
    atlas = pygame.image.load(str(Path(__file__).parent / "cenario/materiais_atlas.png"))
    width, height = atlas.get_size()
    tiles = []
    for row in range(3):
        for col in range(3):
            left, top = round(col*width/3), round(row*height/3)
            right, bottom = round((col+1)*width/3), round((row+1)*height/3)
            tile = atlas.subsurface((left+3, top+3, right-left-6, bottom-top-6))
            tiles.append(pygame.transform.scale(tile, (144, 144)))
    return tuple(tiles)


def finish_tile(surface, rect, index, accent):
    """Textura, relevo e iluminação sem alterar o tamanho da plataforma."""
    w, h = rect.size
    # Uma textura fornecida por círculo, da esquerda para a direita no atlas.
    tint = (245, 245, 250)
    texture = materials()[index]
    for y in range(0, h, 144):
        for x in range(0, w, 144):
            surface.blit(texture, (x, y))
    surface.fill((*tint, 255), special_flags=pygame.BLEND_RGBA_MULT)

    # O topo e as faces utilizáveis são claros; a base recua na sombra.
    shade = pygame.Surface((w, h), pygame.SRCALPHA)
    for y in range(h):
        alpha = min(100, 10 + int(y*.22))
        pygame.draw.line(shade, (10, 10, 24, alpha), (0, y), (w, y))
    surface.blit(shade, (0, 0))
    edge = tuple(round(v*.52) for v in accent)
    light = tuple(min(255, round(v*.8+35)) for v in accent)
    pygame.draw.rect(surface, (19, 18, 30), surface.get_rect(), 1)
    pygame.draw.line(surface, light, (0, 0), (w-1, 0), 2)
    pygame.draw.line(surface, edge, (1, 3), (w-2, 3), 2)
    pygame.draw.line(surface, (15, 15, 26), (1, 6), (w-2, 6))
    pygame.draw.line(surface, edge, (1, 6), (1, h-2))
    pygame.draw.line(surface, (15, 15, 26), (w-2, 6), (w-2, h-2), 2)

    # Recortes de luz irregulares evitam uma barra luminosa uniforme.
    for x in range(9, w-8, 37):
        pygame.draw.line(surface, light, (x, 2), (min(w-3, x+13), 2))
    if h > 110 and w >= 115 and index in (0, 5, 7):
        niche = pygame.Rect(w//2-16, 48, 32, min(70, h-60))
        pygame.draw.rect(surface, (17, 17, 29), niche,
                         border_top_left_radius=16, border_top_right_radius=16)
        pygame.draw.rect(surface, edge, niche, 1,
                         border_top_left_radius=16, border_top_right_radius=16)


def draw_tombs(surface, hazards, offset):
    for hazard in hazards:
        if hazard.kind != "fire":
            continue
        x, y = hazard.x-offset, hazard.y+hazard.height
        pygame.draw.rect(surface, (67, 45, 49), (x-4, y-16, hazard.width+8, 16))
        pygame.draw.rect(surface, (151, 103, 91), (x-4, y-16, hazard.width+8, 16), 2)
        pygame.draw.polygon(surface, (123, 83, 77), ((x-4, y-16), (x+5, y-25),
                            (x+hazard.width+10, y-25), (x+hazard.width+4, y-16)))
        pygame.draw.rect(surface, (28, 24, 34), (x+3, y-14, hazard.width-6, 9))
