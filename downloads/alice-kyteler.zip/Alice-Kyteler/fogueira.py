"""Fogueiras de retorno: atlas animado e transição laranja → violeta."""
import math
from pathlib import Path

import pygame


WARM = (255, 153, 65)
MAGIC = (183, 100, 255)


class CampfireArt:
    _frames = None
    _glows = None

    def __init__(self):
        if self.__class__._frames is None:
            atlas = pygame.image.load(str(Path(__file__).parent/'cenario'/'fogueira-atlas.png')).convert_alpha()
            width, height = atlas.get_size()
            tiles = []
            for row in range(2):
                for column in range(4):
                    x0, x1 = round(column*width/4), round((column+1)*width/4)
                    y0, y1 = round(row*height/2), round((row+1)*height/2)
                    tile = atlas.subsurface((x0, y0, x1-x0, y1-y0)).copy()
                    # A base sólida define o pivô, não uma brasa solta na margem.
                    component = pygame.mask.from_surface(tile, 96).connected_component()
                    bounds = component.get_bounding_rects()[0]
                    tiles.append(tile.subsurface(bounds).copy())
            scale = 48/max(tile.get_width() for tile in tiles)
            frames = []
            for tile in tiles:
                # Mesma escala e base em todos os quadros: a lenha não quica.
                tile = pygame.transform.scale(tile, (round(tile.get_width()*scale), round(tile.get_height()*scale)))
                frame = pygame.Surface((64, 72), pygame.SRCALPHA)
                frame.blit(tile, ((64-tile.get_width())//2, 70-tile.get_height()))
                frames.append(frame)
            self.__class__._frames = (frames[:4], frames[4:])
            self.__class__._glows = []
            for color in (WARM, MAGIC):
                glow = pygame.Surface((144, 120), pygame.SRCALPHA)
                for radius in range(58, 0, -2):
                    pygame.draw.circle(glow, (*color, round(22*(1-radius/60)**1.4)), (72, 60), radius)
                self.__class__._glows.append(glow)
        self.frames = self.__class__._frames
        self.glows = self.__class__._glows

    @staticmethod
    def blend(time, activated_at):
        return max(0, min(1, (time-activated_at)/.55))

    def draw(self, surface, feet, time, active=False, activated_at=None, phase=0):
        x, y = round(feet[0]), round(feet[1])
        blend = self.blend(time, activated_at) if active and activated_at is not None else float(active)
        frame_index = int((time+phase)*8) % 4
        flicker = .9+.07*math.sin(time*9+phase)+.03*math.sin(time*17)
        for row, opacity in ((0, 1-blend), (1, blend)):
            if opacity <= 0:
                continue
            glow = self.glows[row]
            glow.set_alpha(round(210*opacity*flicker))
            surface.blit(glow, (x-72, y-92))
            frame = self.frames[row][frame_index]
            frame.set_alpha(round(255*opacity))
            surface.blit(frame, (x-32, y-70))
            frame.set_alpha(255)
        # Poucas brasas sobem do fogo, sem explosão de quadradinhos.
        color = tuple(round(a+(b-a)*blend) for a, b in zip(WARM, MAGIC))
        for ember in range(3):
            travel = (time*.46+ember/3+phase) % 1
            ex = x+math.sin(time*1.4+ember*2.3)*7
            ey = y-32-travel*40
            shade = tuple(round(c*(1-travel)*.75) for c in color)
            pygame.draw.line(surface, shade, (round(ex), round(ey)), (round(ex), round(ey+2)))
