"""Sprites das armadilhas; recorte do atlas e poses compartilhadas por desenho/colisão."""
from functools import lru_cache
from pathlib import Path
import pygame

CELLS={'boulder':(0,0),'spikes':(1,0),'spikes_off':(2,0),'rune':(0,1),'rune_glow':(1,1),'blade':(2,1)}

@lru_cache(maxsize=1)
def atlas():
    return pygame.image.load(str(Path(__file__).parent/'cenario/armadilhas_atlas.png'))

@lru_cache(maxsize=6)
def source(name):
    sheet=atlas();col,row=CELLS[name];w,h=sheet.get_size();cw,ch=w//3,h//2
    cell=sheet.subsurface((col*cw,row*ch,cw,ch))
    # Desconsidera o halo translúcido ao determinar a escala do objeto sólido.
    boxes=pygame.mask.from_surface(cell,170).get_bounding_rects()
    bounds=boxes[0].unionall(boxes[1:]) if boxes else cell.get_rect()
    return cell.subsurface(bounds).copy()

@lru_cache(maxsize=512)
def sprite(name,width,height,angle=0):
    result=pygame.transform.scale(source(name),(max(1,width),max(1,height)))
    return pygame.transform.rotate(result,angle) if angle else result

@lru_cache(maxsize=120)
def blade_pose(radius,angle):
    image=sprite('blade',radius*2,round(radius*1.4),angle)
    return image,pygame.mask.from_surface(image,170)
