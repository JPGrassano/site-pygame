import os,sys
from pathlib import Path
os.environ['SDL_VIDEODRIVER']='dummy';os.environ['SDL_AUDIODRIVER']='dummy'
import unittest
import pygame
from mapa import World
from fases.progressao import ROUTES
from personagem import Player,Controls,STEP
pygame.display.init();pygame.display.set_mode((1100,650))
class RouteTests(unittest.TestCase):
 def test_tutorial_and_all_new_traversals_have_a_safe_solution(self):
  fail=[];passed=0
  for index in range(9):
   w=World(index)
   route=[max((r for r in w.platforms if r.x<2400),key=lambda r:r.right)]
   route += [pygame.Rect(x,y,width,24) for x,y,width in ROUTES[index]]
  
   for a,b in zip(route,route[1:]):
    if b.x<a.right:continue
    found=False
    for fall in (None,12,24):
     for hold in (45,8,16,30):
      for delay in (None,0,12,24,36,60):
       for dy in (0,-1):
        for phase in (0,.8,1.6,2.4,3.2):
         p=Player((a.right-30,a.top),(4800,820),auto_respawn=False);p.vel.x=235
         w.time=phase
         for tick in range(180):
          x=1 if p.rect.centerx < b.centerx-10 else -1 if p.vel.x>80 else 0
          c=Controls(x=x,jump=tick==0,jump_held=tick<hold,dash=delay is not None and tick==delay,y=dy if tick==delay else 1 if fall is not None and tick>=fall else 0)
          w.step_player(STEP,c,p)
          if w.deadly(p.rect):break
          if p.grounded:
           if p.rect.bottom==b.top and p.rect.right>b.left and p.rect.left<b.right:found=True
           break
         if found:break
        if found:break
       if found:break
      if found:break
     if found:break
    if found:passed+=1
    else:fail.append((index,a.x,a.top,b.x,b.top))
  self.assertEqual(fail, [])
  self.assertEqual(passed, sum(map(len, ROUTES)))

 def test_all_twelve_wall_climbs_have_a_solution(self):
  policies=(((-180,0),),((-180,0),),((-180,0),),((-180,0),),((-180,0),),
            ((-180,0),),((-180,0),(-180,100)),((-180,0),(-180,100)),((0,100),(0,0)))
  for index in range(9):
   w=World(index)
   for (left,right,bottom,top),(threshold,dash_height) in zip(w.layout.shafts,policies[index]):
    p=Player(((left+right)//2,bottom),(4800,820),False);direction=1;w.time=0;found=False
    for tick in range(1200):
     if p.rect.bottom<=top-8:direction=1
     wall=1 if p.rect.move(2,0).collidelist(w.active_platforms())>=0 else -1 if p.rect.move(-2,0).collidelist(w.active_platforms())>=0 else 0
     jump=bool(wall and p.wall_lock<=0 and p.vel.y>threshold and p.rect.bottom>top-8)
     if jump:direction=-wall
     dash=bool(dash_height and p.dashes and top<p.rect.bottom<top+dash_height and wall==1)
     c=Controls(x=0 if dash else wall if jump else direction,y=-1,jump=jump and not dash,jump_held=True,grab=True,dash=dash)
     w.step_player(STEP,c,p)
     if w.deadly(p.rect):break
     if p.grounded and p.rect.bottom==top and p.rect.centerx>=right:
      found=True;break
    self.assertTrue(found,(index,left,right))

 def test_final_gauntlet_replays_continuously_until_exit(self):
  import json
  from pathlib import Path
  data=json.loads((Path(__file__).parent/'replay_final.json').read_text(encoding='utf-8'))
  w=World(data['chapter']);p=Player(data['spawn'],(4800,820),False)
  for frame,values in enumerate(data['controls']):
   w.step_player(STEP,Controls(*values),p)
   self.assertFalse(w.deadly(p.rect),frame)
  self.assertEqual(list(p.rect.midbottom),data['finish'])
  crossed=False
  for frame in range(300):
   x=1 if p.rect.centerx<w.descent.centerx-10 else -1 if p.vel.x>30 else 0
   w.step_player(STEP,Controls(x=x),p)
   self.assertFalse(w.deadly(p.rect),frame)
   if w.descent.left<=p.rect.centerx<=w.descent.right and p.rect.top>w.descent.top+48:
    crossed=True;break
  self.assertTrue(crossed)
