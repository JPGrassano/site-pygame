"""Do sangue à floresta em chamas: alternância entre travessia, paredes e plataformas móveis."""
from .modelo import Layout, floor, ledge

LAYOUT = Layout(
    name='Do sangue à floresta em chamas',
    platforms=(
        floor(0,570,555),
        (350,0,70,480),
        floor(555,330,110),
        floor(780,450,170),
        floor(1360,570,370),
        (1520,0,70,480),
        floor(1730,230,110),
        ledge(1990,330,100),
        floor(2240,490,160),
    ),
    checkpoints=((150, 570), (865, 450), (1785, 230)),
    seal_feet=((2040, 330),), exit=(2330, 490),
    shafts=((420, 555, 570, 330), (1590, 1730, 570, 230)),
    movers=((1100, 440, 120, 24, 150, -65, 3.7, 0),),
    hazards=(('blood', 665, 610, 115, 20, 0), ('arrow', 1190, 400, 210, 8, 0), ('ember', 1970, 190, 100, 10, 1)),
    illusion_x=(),
)
