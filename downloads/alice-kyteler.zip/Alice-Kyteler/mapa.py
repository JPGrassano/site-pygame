"""Construção e desenho dos nove mapas, selos, portais e pontos de retorno."""
import math
from dataclasses import replace
from pathlib import Path
import random

import pygame

from campanha import CHAPTERS, WORLD_WIDTH, WORLD_HEIGHT
from fases import LAYOUTS
from perigos import Hazard, circle_hits_rect
from cenografia import finish_tile, draw_tombs
from plataformas import MovingPlatform, transport_player, draw_track
from fogueira import CampfireArt

ART = Path(__file__).resolve().parent / "cenario"


class World:
    _backgrounds = {}

    def __init__(self, index, size=(1100, 650), checkpoint=0, seals=()):
        self.index, self.chapter = index, CHAPTERS[index]
        self.layout = LAYOUTS[index]
        self.width, self.height = size
        self.platforms = [pygame.Rect(*r) for r in self.layout.platforms]
        self.movers = [MovingPlatform(*data) for data in getattr(self.layout, "movers", ())]
        self.crushed = False
        self.hazards = [Hazard(*data) for data in self.layout.hazards]
        self.seals = ()
        self.checkpoints = self.layout.checkpoints
        self.broken = {i for i in seals if 0 <= i < len(self.seals)}
        self.checkpoint = max(0, min(len(self.checkpoints)-1, checkpoint))
        self.campfire_art = CampfireArt()
        self.checkpoint_ignited = {}
        exit_x, exit_y = self.layout.exit
        self.portal = pygame.Rect(exit_x-45, exit_y-115, 90, 115)
        self.descent = pygame.Rect(exit_x-38, exit_y, 76, WORLD_HEIGHT-exit_y+200)
        pieces = []
        for rect in self.platforms:
            if rect.bottom > exit_y and rect.right > self.descent.left and rect.left < self.descent.right:
                if rect.left < self.descent.left:
                    pieces.append(pygame.Rect(rect.left, rect.top, self.descent.left-rect.left, rect.height))
                if rect.right > self.descent.right:
                    pieces.append(pygame.Rect(self.descent.right, rect.top, rect.right-self.descent.right, rect.height))
            else:
                pieces.append(rect)
        self.platforms = pieces
        self.camera_x = max(0, min(WORLD_WIDTH-self.width, self.spawn[0]-self.width*.38))
        self.time = 0.0
        key = (self.chapter.background, self.chapter.tint, size)
        if key not in self._backgrounds:
            source = pygame.image.load(str(ART / f"{self.chapter.background}.png")).convert()
            # Grupos de pixels maiores reduzem a textura e aproximam os planos.
            source = pygame.transform.scale(source, (750, 250))
            source.fill(self.chapter.tint, special_flags=pygame.BLEND_RGB_MULT)
            scale = max(self.width/750, self.height/250)*1.10
            background = pygame.transform.scale(source, (round(750*scale), round(250*scale)))
            shade = pygame.Surface(background.get_size())
            shade.fill((120, 122, 146))
            background.blit(shade, (0, 0), special_flags=pygame.BLEND_RGB_MULT)
            self._backgrounds[key] = background
        self.background = self._backgrounds[key]
        self.tiles = [(rect, self.make_platform(rect)) for rect in self.platforms]
        self.moving_tiles = [self.make_platform(mover.rect_at(0)) for mover in self.movers]
        # As pontes falsas estão identificadas no próprio arquivo de Fraude.
        self.illusory = {i for i, rect in enumerate(self.platforms) if rect.x in self.layout.illusion_x}
        rng = random.Random(91+index)
        self.motes = [(rng.randrange(WORLD_WIDTH), rng.randrange(60, 600), rng.random()*6)
                      for _ in range(85)]
        self.fog = pygame.Surface(size, pygame.SRCALPHA)
        for y in range(460, self.height):
            pygame.draw.line(self.fog, (*self.chapter.accent, min(24, (y-460)//7)),
                             (0, y), (self.width, y))

    @property
    def spawn(self):
        return self.checkpoints[self.checkpoint]

    @property
    def offset(self):
        return round(self.camera_x)

    @property
    def open(self):
        return len(self.broken) == len(self.seals)

    def bridge_active(self, index):
        return (self.time+index*.37) % 4.8 < 3.6

    def static_platforms(self):
        return [r for i, r in enumerate(self.platforms) if i not in self.illusory or self.bridge_active(i)]

    def moving_rects(self, time=None):
        return [mover.rect_at(self.time if time is None else time) for mover in self.movers]

    def active_platforms(self):
        return [*self.static_platforms(), *self.moving_rects()]

    def step_player(self, dt, controls, player):
        """Avança cenário e física juntos; também é usado pelos replays de teste."""
        self.crushed = False
        # Mesmo chamadas grandes respeitam os passos pequenos usados pelo jogo.
        max_speed = max((math.pi*math.hypot(m.dx,m.dy)/m.period for m in self.movers), default=0)
        count = max(1, math.ceil(dt/(1/120)), math.ceil(dt*max_speed/4))
        step = dt/count
        for index in range(count):
            previous = self.moving_rects()
            self.time += step
            current = self.moving_rects()
            if transport_player(player, previous, current, self.static_platforms(), controls.grab):
                self.crushed = True
                break
            self.configure_player(player)
            held = controls if index == 0 else replace(controls, jump=False, dash=False)
            player.update(step, held, self.active_platforms())
            for hazard in self.hazards:
                hazard.update(self.time,player.rect)

        self.update_camera(dt, player)

    def wind(self):
        return math.sin(self.time*.7)*80 if self.chapter.mechanic == "wind" else 0

    def deadly(self, rect):
        return self.crushed or rect.top > WORLD_HEIGHT or any(h.hits(rect, self.time) for h in self.hazards)

    def update(self, dt, player):
        """Atualização visual; para jogar e simular física use step_player."""
        self.time += dt
        self.update_camera(dt, player)

    def update_camera(self, dt, player):
        target = max(0, min(WORLD_WIDTH-self.width, player.rect.centerx-self.width*.38))
        if abs(target-self.camera_x) > self.width*1.2:
            self.camera_x = target
        else:
            self.camera_x += (target-self.camera_x)*(1-math.exp(-8*dt))

    def activate_checkpoint(self, player, previous=None):
        swept = previous.union(player.rect) if previous is not None else player.rect
        for index in range(self.checkpoint+1, len(self.checkpoints)):
            x, y = self.checkpoints[index]
            # Também reconhece um dash cruzando a chama; não exige parar nela.
            trigger = pygame.Rect(x-35, y-48, 70, 49)
            if swept.colliderect(trigger) and player.rect.bottom <= y+8:
                self.checkpoint = index
                self.checkpoint_ignited[index] = self.time
                return True
        return False

    def break_seals(self, rect, dashing):
        if not dashing:
            return []
        newly = []
        for i, center in enumerate(self.seals):
            if i not in self.broken and circle_hits_rect(center, 20, rect):
                self.broken.add(i)
                newly.append(center)
        return newly

    def make_platform(self, rect):
        surface = pygame.Surface(rect.size, pygame.SRCALPHA)
        finish_tile(surface, rect, self.index, self.chapter.accent)
        return surface

    def draw_background(self, surface):
        travel = self.background.get_width()-self.width
        progress = self.camera_x/max(1, WORLD_WIDTH-self.width)
        surface.blit(self.background, (-round(travel*progress), (self.height-self.background.get_height())//2))
        for x, y, phase in self.motes:
            sx = round((x-self.time*(12 if self.index != 8 else 5)-self.offset*.6) % (WORLD_WIDTH+80)-40)
            if sx < self.width:
                sy = round(y+math.sin(self.time*.7+phase)*10)
                c = tuple(round(v*.55) for v in self.chapter.accent)
                if self.chapter.mechanic in ("slush", "wind", "swamp"):
                    pygame.draw.line(surface, c, (sx, sy), (sx-4, sy+9))
                else:
                    pygame.draw.rect(surface, c, (sx, sy, 2, 2))
        if self.chapter.mechanic == "wind":
            direction = 1 if self.wind() > 0 else -1
            for i in range(8):
                x = round((i*177+self.time*direction*120) % (self.width+100)-50)
                y = 175+i*46
                pygame.draw.line(surface, (115, 104, 145), (x, y), (x+direction*38, y), 1)

    def draw_instructions(self, surface):
        if not hasattr(self, 'inscription_font'):
            pygame.font.init()
            self.inscription_font = pygame.font.Font(str(Path(__file__).parent/'fontes'/'Coolvetica Rg.otf'), 17)
            self.inscriptions = []
            for x,y,*lines in self.layout.inscriptions:
                width = max(self.inscription_font.size(line)[0] for line in lines)+28
                plaque = pygame.Surface((width,66),pygame.SRCALPHA)
                pygame.draw.rect(plaque,(24,21,36,248),plaque.get_rect(),border_radius=3)
                pygame.draw.rect(plaque,(88,66,107),plaque.get_rect(),1,border_radius=3)
                for i,line in enumerate(lines):
                    plaque.blit(self.inscription_font.render(line,True,(220,188,237) if i==0 else (208,198,218)),(14,10+i*25))
                self.inscriptions.append((x,y,plaque))
        for x,y,plaque in self.inscriptions:
            if -plaque.get_width() < x-self.offset < self.width:
                surface.blit(plaque,(x-self.offset,y))

    def draw_platforms(self, surface):
        for mover in self.movers:
            draw_track(surface, mover, self.offset, self.chapter.accent)
        for i, (rect, tile) in enumerate(self.tiles):
            if rect.right < self.offset or rect.left > self.offset+self.width:
                continue
            x = rect.x-self.offset
            if rect.height == 24 and i not in self.illusory:
                # As varandas sólidas são suspensas por correntes de fundo.
                for anchor in (x+12, x+rect.width-12):
                    pygame.draw.line(surface, (57, 49, 70), (anchor, 0), (anchor, rect.y), 2)
                    for cy in range(12, rect.y, 18):
                        pygame.draw.ellipse(surface, (78, 65, 91), (anchor-2, cy, 5, 8), 1)
            if i in self.illusory:
                phase = (self.time+i*.37) % 4.8
                tile.set_alpha(215 if phase < 2.9 else (115 if int(self.time*9)%2 else 190) if phase < 3.6 else 35)
                surface.blit(tile, (x, rect.y))
                pygame.draw.rect(surface, self.chapter.accent, (x, rect.y, rect.width, rect.height), 1)
            else:
                surface.blit(tile, (x, rect.y))
        for mover, tile in zip(self.movers, self.moving_tiles):
            rect = mover.rect_at(self.time)
            if rect.right < self.offset or rect.left > self.offset+self.width:
                continue
            x, y = rect.x-self.offset, rect.y
            surface.blit(tile, (x, y))
            # Duas pequenas polias distinguem os apoios móveis dos fixos.
            for px in (x+12, x+rect.width-12):
                pygame.draw.circle(surface, (26, 25, 38), (px, y+rect.height-1), 5)
                pygame.draw.circle(surface, self.chapter.accent, (px, y+rect.height-1), 4, 1)
            pygame.draw.line(surface, self.chapter.accent, (x+7,y+3), (x+rect.width-7,y+3), 2)
        # Bordas claras indicam as faces que podem ser usadas na subida.
        for left,right,bottom,top in self.layout.shafts:
            c=tuple(round(v*.65) for v in self.chapter.accent)
            pygame.draw.line(surface,c,(left-self.offset,0),(left-self.offset,bottom-90),2)
            pygame.draw.line(surface,c,(right-self.offset,top),(right-self.offset,bottom),2)
            for y in range(top+45,bottom-60,75):
                for x,side in ((left,1),(right,-1)):
                    if side==1 and y>bottom-90:
                        continue
                    pygame.draw.line(surface,c,(x-self.offset,y),(x-self.offset+side*5,y-5),2)
        for i, (x, y) in enumerate(self.checkpoints):
            sx = x-self.offset
            if -80 < sx < self.width+80:
                self.campfire_art.draw(surface, (sx, y), self.time, i <= self.checkpoint,
                                       self.checkpoint_ignited.get(i), i*.19)
        self.draw_portal(surface)
        for i, (x, y) in enumerate(self.seals):
            sx = x-self.offset
            if i in self.broken:
                pygame.draw.circle(surface, (95, 90, 116), (sx, y), 13, 1)
                continue
            c = self.chapter.accent
            radius = round(19+math.sin(self.time*3)*2)
            pygame.draw.circle(surface, (39, 29, 56), (sx, y), radius+5)
            pygame.draw.circle(surface, c, (sx, y), radius, 2)
            points = [(sx+math.cos(a*math.tau/5-math.pi/2)*12,
                       y+math.sin(a*math.tau/5-math.pi/2)*12) for a in (0, 2, 4, 1, 3)]
            pygame.draw.polygon(surface, c, points, 1)
            pygame.draw.line(surface, c, (sx, y-radius-10), (sx, y-radius-5), 2)
            pygame.draw.line(surface, c, (sx, y+radius+5), (sx, y+radius+10), 2)
        if self.index == 5:
            draw_tombs(surface, self.hazards, self.offset)
        for hazard in self.hazards:
            if hazard.kind == "pendulum":
                hx = hazard.x-self.offset
                pygame.draw.line(surface, (70, 57, 71), (hx, 0), (hx, hazard.y), 5)
                pygame.draw.rect(surface, (144, 115, 77), (hx-12, hazard.y-5, 24, 10), 2)
            elif hazard.kind == "arrow":
                hx = hazard.x-self.offset
                pygame.draw.line(surface, (72, 49, 67), (hx+9, 0), (hx+9, hazard.y-17), 2)
                pygame.draw.rect(surface, (49, 34, 51), (hx, hazard.y-17, 18, 34))
                pygame.draw.rect(surface, (137, 77, 95), (hx, hazard.y-17, 18, 34), 2)
            hazard.draw(surface, self.offset, self.time)

    def draw_portal(self, surface):
        x, y = self.descent.centerx-self.offset, self.descent.top
        pygame.draw.rect(surface, (10, 8, 23), (x-38, y, 76, self.height-y))
        for side in (-1, 1):
            pygame.draw.line(surface, (179, 110, 240), (x+side*39,y-4), (x+side*39,y+38), 3)
        glow = pygame.Surface((76, 130), pygame.SRCALPHA)
        for depth in range(130):
            pygame.draw.line(glow, (151, 88, 208, round(38*(1-depth/130))), (0, depth), (76, depth))
        surface.blit(glow, (x-38, y))

    def draw_atmosphere(self, surface):
        surface.blit(self.fog, (0, 0))

    def configure_player(self, player):
        player.wind_x = self.wind()
        player.ice = self.chapter.mechanic == "ice"
        player.speed_scale = 1.0
