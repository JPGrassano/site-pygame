"""Bruxa: movimentos, colisões, respiração e animações, sem cenário ou loop."""
from __future__ import annotations

from dataclasses import dataclass
import math
import os
from pathlib import Path

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
import pygame

ROOT = Path(__file__).resolve().parent
WIDTH, HEIGHT = 1100, 650
STEP = 1 / 120
RUN_SPEED, DASH_SPEED = 235, 850
DASH_DURATION, DASH_RECOVERY = .17, .07
MAX_STAMINA = 2.8
CLIMB_DRAIN, HOLD_DRAIN, DESCEND_DRAIN = 1.0, .22, .45
WAVEDASH_SPEED = 690  # +21% de impulso horizontal; dash comum permanece igual.
IDLE_BREATH_PIXELS = 5  # Respiração visível, com os pés ancorados.
IDLE_BREATH_PERIOD = 2.4  # Segundos para um ciclo completo.
SPRITES = ROOT / "bruxa"
Vec = pygame.Vector2


def approach(value, target, amount):
    return min(value + amount, target) if value < target else max(value - amount, target)


@dataclass
class Controls:
    x: int = 0
    y: int = 0
    jump: bool = False
    jump_held: bool = False
    dash: bool = False
    grab: bool = False


@dataclass
class Frame:
    image: pygame.Surface
    pivot: tuple[int, int] = (36, 70)

    def draw(self, target, feet):
        target.blit(self.image, (round(feet[0]-self.pivot[0]), round(feet[1]-self.pivot[1])))


class Animations:
    """Um único atlas, uma escala e a mesma personagem em todas as ações."""

    def __init__(self):
        self.frames = {}
        for state in ('idle', 'run', 'jump', 'climb'):
            right = self.load_sequence(state)
            if state == 'idle':
                right = self.make_idle_frames(right[0])
            elif state == 'climb':
                right = self.load_climb_art()
            self.frames[state, 1] = right
            self.frames[state, -1] = self.mirror(right)

        horizontal = self.load_sequence('dash_right', dash=True)
        up = self.load_sequence('dash_up', dash=True)
        down = self.load_sequence('dash_down', dash=True)
        # As poses inclinadas e verticais foram desenhadas no mesmo atlas.
        # Três poses ocupam os seis instantes do dash; não giramos o sprite.
        expand = lambda frames: [Frame(frames[i].image.copy(), frames[i].pivot)
                                 for i in (0, 0, 1, 1, 2, 2)]
        self.dashes = {
            (1, 0): horizontal,
            (-1, 0): self.mirror(horizontal),
            (1, -1): expand(up[:3]),
            (0, -1): expand(up[3:]),
            (1, 1): expand(down[:3]),
            (0, 1): expand(down[3:]),
        }
        self.dashes[-1, -1] = self.mirror(self.dashes[1, -1])
        self.dashes[-1, 1] = self.mirror(self.dashes[1, 1])
        self.vertical_left = {direction: self.mirror(self.dashes[direction])
                              for direction in ((0, -1), (0, 1))}

    @staticmethod
    def load_sequence(state, dash=False):
        pivot = (64, 100) if dash else (36, 70)
        frames = []
        for index in range(1, 7):
            path = SPRITES / f'alice_v2_{state}_{index:02d}.png'
            if not path.exists():
                raise FileNotFoundError(f'Quadro do atlas de Alice ausente: {path.name}')
            frames.append(Frame(pygame.image.load(str(path)).convert_alpha(), pivot))
        return frames

    @staticmethod
    def mirror(frames):
        return [Frame(pygame.transform.flip(frame.image, True, False),
                      (frame.image.get_width()-frame.pivot[0], frame.pivot[1]))
                for frame in frames]

    @staticmethod
    def load_climb_art():
        return [Frame(pygame.image.load(str(SPRITES / f'climb_redrawn_{i:02d}.png')).convert_alpha(), (50, 70))
                for i in range(1, 7)]

    @staticmethod
    def make_idle_frames(base):
        # Respiração com os pés ancorados: muda apenas o desenho, não a colisão.
        frames = []
        for amount in range(IDLE_BREATH_PIXELS+1):
            body = pygame.transform.scale(base.image, (72, 72-amount))
            image = pygame.Surface((72, 72), pygame.SRCALPHA)
            image.blit(body, (0, 70-body.get_bounding_rect(min_alpha=80).bottom))
            frames.append(Frame(image, base.pivot))
        return frames

    def get(self, state, facing, clock, vy=0, direction=(1, 0)):
        if state == 'dash':
            frames = self.vertical_left[direction] if direction[0] == 0 and facing == -1 else self.dashes[direction]
            index = min(5, int(clock / (DASH_DURATION+DASH_RECOVERY) * 6))
        else:
            frames = self.frames['jump' if state == 'land' else state, facing]
            if state == 'idle':
                phase = math.tau * (clock % IDLE_BREATH_PERIOD) / IDLE_BREATH_PERIOD
                index = round(IDLE_BREATH_PIXELS * (1-math.cos(phase)) / 2)
            elif state == 'jump':
                index = 0 if clock < .035 and vy < 0 else 1 if vy < -100 else 2 if vy < 100 else 3
            elif state == 'land':
                index = 4 if clock < .06 else 5
            else:
                index = int(clock * (11 if state == 'run' else 9)) % len(frames)
        return frames[index]


class Player:
    def __init__(self, spawn, limits=(WIDTH, HEIGHT), auto_respawn=True):
        self.spawn = spawn
        self.limits = limits
        self.auto_respawn = auto_respawn
        self.max_dashes = 1
        self.wind_x = 0.0
        self.ice = False
        self.speed_scale = 1.0
        self.rect = pygame.Rect(0, 0, 22, 34)
        self.pos, self.vel = Vec(), Vec()
        self.reset()

    def reset(self):
        self.rect.midbottom = self.spawn
        self.pos.update(self.rect.topleft)
        self.vel.update(0, 0)
        self.facing = self.dash_facing = 1
        self.state, self.anim_clock = "idle", 0
        self.grounded = False
        self.coyote = self.jump_buffer = self.wall_lock = 0
        self.air_time = self.land_time = 0
        self.dash_time = self.dash_visual = self.dash_elapsed = self.dash_cooldown = 0
        self.dash_direction = (1, 0)
        self.dashes, self.stamina = self.max_dashes, MAX_STAMINA
        self.boost_time = self.slide_window = 0.0
        self.slide_velocity = 0.0
        self.fast_falling = False
        self.events = []
        self.climb_wall_x = None

    def on_platform(self, platform):
        # Encostar no topo precisa contar como apoio mesmo sem sobreposição.
        platforms = (platform,) if isinstance(platform, pygame.Rect) else platform
        return (self.vel.y >= 0 and self.dash_time <= 0 and any(
                self.rect.bottom == solid.top and self.rect.right > solid.left
                and self.rect.left < solid.right for solid in platforms))

    def move(self, dx, dy, platform):
        platforms = (platform,) if isinstance(platform, pygame.Rect) else platform
        hit_x = hit_y = False
        steps = max(1, math.ceil(max(abs(dx), abs(dy))/6))
        for _ in range(steps):
            self.pos.x += dx/steps
            self.rect.x = round(self.pos.x)
            for solid in platforms:
                if dx and self.rect.colliderect(solid):
                    if dx > 0:
                        self.rect.right = solid.left
                    else:
                        self.rect.left = solid.right
                    self.pos.x, self.vel.x, hit_x = self.rect.x, 0, True
            self.pos.y += dy/steps
            self.rect.y = round(self.pos.y)
            for solid in platforms:
                if dy and self.rect.colliderect(solid):
                    if dy > 0:
                        self.rect.bottom = solid.top
                    else:
                        self.rect.top = solid.bottom
                    self.pos.y, self.vel.y, hit_y = self.rect.y, 0, True
            # O limite superior fecha a sala: não permite correr por cima dos tetos.
            if self.rect.top < 0:
                self.rect.top = 0
                self.pos.y = 0
                self.vel.y = max(0, self.vel.y)
                hit_y = True
            if self.rect.left < 0 or self.rect.right > self.limits[0]:
                self.rect.x = max(0, min(self.limits[0]-self.rect.width, self.rect.x))
                self.pos.x, self.vel.x, hit_x = self.rect.x, 0, True
        return hit_x, hit_y

    def update(self, dt, controls, platform):
        self.events = []
        self.climb_wall_x = None
        platforms = (platform,) if isinstance(platform, pygame.Rect) else platform
        self.boost_time = max(0, self.boost_time-dt)
        self.slide_window = max(0, self.slide_window-dt)
        self.fast_falling = False
        self.dash_cooldown = max(0, self.dash_cooldown-dt)
        self.wall_lock = max(0, self.wall_lock-dt)
        self.land_time = max(0, self.land_time-dt)
        self.jump_buffer = .13 if controls.jump else max(0, self.jump_buffer-dt)
        grounded = self.on_platform(platform)
        if grounded:
            self.coyote, self.stamina = .11, MAX_STAMINA
            if self.dashes == 0:
                self.dashes = self.max_dashes
                self.events.append(("recharge", 1))
        else:
            self.coyote = max(0, self.coyote-dt)
        wall = 1 if self.rect.move(2, 0).collidelist(platforms) >= 0 else (
            -1 if self.rect.move(-2, 0).collidelist(platforms) >= 0 else 0)
        if controls.x and self.wall_lock <= 0 and self.dash_time <= 0:
            self.facing = controls.x
        # No chão, L + W inicia a subida sem exigir um pulo.
        # Agarrar parado no chão continua sendo uma pose de apoio normal.
        climbing = bool(wall and controls.grab and self.stamina > 0 and self.wall_lock <= 0
                        and controls.x != -wall and (not grounded or controls.y < 0))

        if controls.dash and self.dashes and self.dash_cooldown <= 0:
            self.dash_direction = (controls.x, controls.y) if controls.x or controls.y else (self.facing, 0)
            self.dash_facing = controls.x or self.facing
            self.vel = Vec(self.dash_direction).normalize() * DASH_SPEED
            self.dash_time, self.dash_visual = DASH_DURATION, DASH_DURATION+DASH_RECOVERY
            self.dash_elapsed, self.dash_cooldown = 0, .23
            if grounded and self.dash_direction[0] and self.dash_direction[1] >= 0:
                self.slide_window = .30
                self.slide_velocity = self.dash_direction[0]*WAVEDASH_SPEED
            self.dashes -= 1
            self.events.append(("dash", 1))
            self.jump_buffer = self.coyote = 0
        if self.dash_visual > 0:
            self.dash_visual = max(0, self.dash_visual-dt)
            self.dash_elapsed += dt
        supported = any(self.rect.bottom == r.top and self.rect.right > r.left and self.rect.left < r.right for r in platforms)
        if self.jump_buffer and self.slide_window and supported and self.vel.y >= 0:
            self.dash_time = self.dash_visual = 0
            self.vel.update(self.slide_velocity, -540)
            self.boost_time = .62
            self.slide_window = self.jump_buffer = self.coyote = 0
            grounded = False
            self.events.append(('jump', 1))
        dashing = self.dash_time > 0
        if dashing:
            self.dash_time = max(0, self.dash_time-dt)
        else:
            if self.jump_buffer and (self.coyote > 0 or wall):
                # Escalando, o salto se afasta da parede mesmo que ainda
                # exista tolerância de pulo do chão. O lock impede reagarrar.
                if wall and (climbing or self.coyote <= 0):
                    self.vel.update(-wall*285, -540)
                    self.facing, self.wall_lock = -wall, .17
                else:
                    self.vel.y = -570
                self.events.append(("wall_jump" if self.wall_lock > 0 else "jump", 1))
                self.jump_buffer = self.coyote = self.land_time = 0
                climbing = False
            if self.wall_lock <= 0:
                acceleration = 2200 if grounded else 1400
                if grounded and self.ice:
                    acceleration = 600 if controls.x else 110
                target = controls.x*RUN_SPEED*self.speed_scale + self.wind_x*(.35 if grounded else 1)
                if self.boost_time > 0 and not grounded:
                    acceleration = 180 if not controls.x or controls.x*self.vel.x >= 0 else 1900
                self.vel.x = approach(self.vel.x, target, acceleration*dt)
            if climbing:
                self.vel.x = wall*35  # Mantém os quatro apoios junto à face.
                self.vel.y = controls.y*105
                self.stamina = max(0, self.stamina-dt*(CLIMB_DRAIN if controls.y < 0 else DESCEND_DRAIN if controls.y > 0 else HOLD_DRAIN))
                self.facing = wall
            else:
                gravity = 1650 if self.vel.y < 0 and controls.jump_held else 2300
                self.fast_falling = controls.y > 0 and not grounded
                if self.fast_falling:
                    self.vel.y = max(self.vel.y, 380)
                    gravity = 3900
                self.vel.y = min(1050 if self.fast_falling else 650, self.vel.y+gravity*dt)
                if self.vel.y < -220 and not controls.jump_held:
                    self.vel.y = -220
                if wall and controls.x == wall and self.vel.y > 100:
                    self.vel.y = 100
                    climbing = True

        impact_speed = self.vel.y
        hit_x, hit_y = self.move(self.vel.x*dt, self.vel.y*dt, platform)
        if dashing and (self.dash_time == 0 or hit_x or hit_y):
            self.dash_time = 0
            self.vel *= .43
            if hit_x or hit_y:
                self.events.append(("dash_hit", 1))
                self.dash_visual = min(self.dash_visual, DASH_RECOVERY)
                self.dash_elapsed = max(self.dash_elapsed, DASH_DURATION)
        self.grounded = self.on_platform(platform)
        if self.grounded:
            self.pos.y, self.vel.y = self.rect.y, 0
            if self.dashes == 0:
                self.events.append(("recharge", 1))
            self.dashes, self.stamina = self.max_dashes, MAX_STAMINA
            if self.air_time > .06:
                self.land_time = .12
                self.events.append(("land", min(1, max(.15, impact_speed/650))))
            self.air_time = 0
        else:
            self.air_time += dt

        if climbing and not self.grounded:
            touching = [solid for solid in platforms
                        if self.rect.move(wall*2, 0).colliderect(solid)]
            if touching:
                self.facing = wall
                self.climb_wall_x = touching[0].left if wall > 0 else touching[0].right
            else:
                climbing = False

        if self.dash_visual > 0:
            state = "dash"
        elif self.grounded:
            state = "run" if abs(self.vel.x) > 15 else "land" if self.land_time else "idle"
        else:
            state = "climb" if climbing else "jump"
        if state != self.state:
            self.state, self.anim_clock = state, 0
        rate = abs(self.vel.x)/RUN_SPEED if state == "run" else 1
        if state == "climb" and abs(self.vel.y) < 1:
            rate = 0
        self.anim_clock += dt*rate
        if self.auto_respawn and self.rect.top > self.limits[1]+96:
            self.reset()


    def draw(self, surface, animations, offset=0):
        """Desenha a bruxa e os indicadores de dash/energia em coordenadas de tela."""
        facing = self.dash_facing if self.state == "dash" else self.facing
        clock = self.dash_elapsed if self.state == "dash" else self.anim_clock
        frame = animations.get(self.state, facing, clock, self.vel.y, self.dash_direction)
        center_x = self.rect.centerx
        if self.state == "climb" and self.climb_wall_x is not None:
            center_x = self.climb_wall_x-self.facing*11
        frame.draw(surface, (center_x-offset, self.rect.bottom))
        pygame.draw.circle(surface, (115, 226, 255) if self.dashes else (94, 118, 157),
                           (self.rect.centerx-offset, self.rect.top-42), 3)
        if self.state == "climb":
            x, y = self.rect.right-offset+8, self.rect.top-8
            pygame.draw.rect(surface, (8, 20, 44), (x, y, 4, 30))
            filled = round(30*self.stamina/MAX_STAMINA)
            pygame.draw.rect(surface, (115, 226, 255), (x, y+30-filled, 4, filled))
