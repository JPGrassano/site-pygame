"""Mapa ilustrado da jornada; seleção e progresso ficam sobre a arte."""
import math
import pygame
from campanha import CHAPTERS
from interface import GOLD, MUTED, PAPER
from mapa import ART


class JourneyMap:
    # Pontos sobre a escadaria da ilustração em coordenadas de tela.
    NODES = ((253,104),(530,163),(513,207),(445,254),(550,284),
             (476,328),(385,386),(431,465),(373,548))
    ROMAN = ('I','II','III','IV','V','VI','VII','VIII','IX')

    def __init__(self):
        self.previews = {}
        self.backdrop = pygame.transform.smoothscale(
            pygame.image.load(str(ART/'mapa_ilustrado.png')).convert(), (1100,650))
        self.shade = pygame.Surface((1100,650),pygame.SRCALPHA)
        for x in range(690,1100):
            pygame.draw.line(self.shade,(10,12,25,min(120,(x-690)//2)),(x,0),(x,650))

    def preview(self,index):
        if index not in self.previews:
            source=pygame.image.load(str(ART/f'{CHAPTERS[index].background}.png')).convert()
            self.previews[index]=pygame.transform.smoothscale(source,(312,118))
        return self.previews[index]

    def draw(self,surface,ui,progress,selected,time,animations):
        surface.blit(self.backdrop,(0,0))
        surface.blit(self.shade,(0,0))
        chapter=CHAPTERS[selected]
        unlocked=progress['unlocked']
        complete=9 if progress['completed'] else unlocked
        for i,(x,y) in enumerate(self.NODES):
            enabled=i<=unlocked
            color=GOLD if i<complete else CHAPTERS[i].accent if enabled else (132,135,156)
            if i==selected:
                glow=pygame.Surface((72,72),pygame.SRCALPHA)
                for r in range(32,15,-2):
                    pygame.draw.circle(glow,(*chapter.accent,round((32-r)*2)),(36,36),r)
                surface.blit(glow,(x-36,y-36))
                pygame.draw.circle(surface,chapter.accent,(x,y),round(22+math.sin(time*3)),1)
            pygame.draw.circle(surface,(14,18,34),(x,y),15)
            pygame.draw.circle(surface,color,(x,y),15,2 if enabled else 1)
            ui.text(surface,self.ROMAN[i],x,y-10,'tiny',color,center=True)
            if i<complete:
                pygame.draw.lines(surface,GOLD,False,((x+8,y+11),(x+11,y+14),(x+17,y+7)),2)
            ui.buttons.append((pygame.Rect(x-23,y-22,46,44),i))
        x,y=self.NODES[selected]
        frame=animations.get('idle',1,time)
        surface.blit(pygame.transform.scale(frame.image,(46,46)),(x-23,y-62))
        ui.text(surface,'MAPA DA JORNADA',731,40,'tiny',GOLD)
        ui.text(surface,'A DESCIDA',727,66,'heading')
        ui.text(surface,'DE ALICE',727,108,'heading')
        ui.text(surface,f'{complete:02d} de 09 círculos atravessados',731,160,'small',MUTED)
        surface.blit(self.preview(selected),(731,200))
        pygame.draw.line(surface,chapter.accent,(731,320),(1043,320),2)
        enabled=selected<=unlocked
        status='ATRAVESSADO' if selected<complete else 'CAMINHO ABERTO' if enabled else 'AINDA SELADO'
        ui.text(surface,f'CÍRCULO {selected+1:02d}  /  {status}',731,339,'tiny',chapter.accent)
        ui.text(surface,chapter.name,727,361,'heading')
        ui.text(surface,chapter.subtitle,731,414,'small',MUTED)
        ui.paragraph(surface,chapter.hint if enabled else 'Atravesse o círculo anterior para abrir esta passagem.',
                     731,448,312,'small',PAPER,2)
        label='RETOMAR' if progress['started'] and selected==progress['chapter'] and not progress['completed'] else 'ENTRAR NO CÍRCULO'
        if not enabled:
            label='PASSAGEM BLOQUEADA'
        button=pygame.Rect(731,536,312,42)
        pygame.draw.rect(surface,(51,43,74) if enabled else (29,29,44),button,border_radius=4)
        pygame.draw.rect(surface,chapter.accent if enabled else (74,73,96),button,1,border_radius=4)
        ui.text(surface,label,button.centerx,547,'small',PAPER if enabled else MUTED,center=True)
        ui.buttons.append((button,selected))
        ui.text(surface,'WASD  escolher   ·   ENTER  entrar',731,597,'tiny',MUTED)
        ui.text(surface,'M / ESC  voltar',731,618,'tiny',MUTED)
