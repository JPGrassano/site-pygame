"""Riscos ambientais: posição, aviso visual e colisão. Sem controle da bruxa."""
import math

import pygame
from armadilhas_arte import sprite, blade_pose


def circle_hits_rect(center, radius, rect):
    x = max(rect.left, min(center[0], rect.right))
    y = max(rect.top, min(center[1], rect.bottom))
    return (x-center[0])**2 + (y-center[1])**2 < radius**2


class Hazard:
    COLORS = {"rune": (199, 115, 251), "spikes_timed": (186, 169, 151), "spikes": (245, 180, 197), "spikes_down": (245, 180, 197), "chain": (191, 133, 240), "acid": (142, 216, 127), "vapor": (113, 201, 179),
              "fire": (255, 157, 91), "frost": (168, 233, 255),
              "orb": (232, 132, 196), "arrow": (255, 150, 168),
              "pendulum": (223, 183, 104), "boulder": (166, 148, 112),
              "slush": (122, 137, 142), "swamp": (77, 126, 109),
              "blood": (171, 53, 69), "pitch": (97, 79, 119),
              "hail": (188, 214, 226), "ember": (246, 145, 83)}

    def __init__(self, kind, x, y, width, height, phase):
        self.kind, self.x, self.y = kind, x, y
        self.width, self.height, self.phase = width, height, phase
        self.color = self.COLORS[kind]
        self.triggered_at = None

    def update(self, time, rect):
        """Runas respondem ao contato dos pés; consulta de colisão não muda estado."""
        if self.kind != 'rune':
            return
        if self.triggered_at is not None and time-self.triggered_at >= 2.4:
            self.triggered_at = None
        base=self.y+self.height
        if (self.triggered_at is None and abs(rect.bottom-base)<=3
                and rect.right>self.x and rect.left<self.x+self.width):
            self.triggered_at=time

    def rune_state(self,time):
        if self.triggered_at is None:return 'idle'
        age=time-self.triggered_at
        return 'charging' if age<.55 else 'firing' if age<.95 else 'cooldown'

    def pendulum_pose(self,time):
        angle=round(-math.degrees(math.sin(time*1.25+self.phase)*.78)/4)*4
        image,mask=blade_pose(self.height,angle)
        x,y=self.center(time)
        return image,mask,image.get_rect(center=(round(x),round(y)))

    def cycle(self, time):
        return (time+self.phase) % 3.8

    def active(self, time):
        if self.kind == 'rune':return self.rune_state(time)=='firing'
        if self.kind == 'spikes_timed':return 1.0<=self.cycle(time)<2.3
        if self.kind == "chain":
            return 1.25 <= self.cycle(time) < 3.15
        return self.kind not in ("fire", "vapor", "frost") or 1.0 <= self.cycle(time) < 2.05

    def center(self, time):
        if self.kind == "boulder":
            return self.x+math.sin(time*1.25+self.phase)*(self.width/2-self.height), self.y
        if self.kind in ("hail", "ember"):
            return self.x+self.width/2, self.y+((time+self.phase) % 2.7)*145
        if self.kind == "orb":
            return (self.x+math.sin(time*1.6+self.phase)*self.width/2,
                    self.y+math.cos(time*2+self.phase)*18)
        if self.kind == "pendulum":
            angle = math.sin(time*1.25+self.phase)*.78
            return self.x+math.sin(angle)*self.width, self.y+math.cos(angle)*self.width
        if self.kind == "arrow":
            # O projétil cruza uma pista marcada e tem um intervalo de repouso.
            return self.x-min(1, self.cycle(time)/2.2)*self.width, self.y
        return self.x+self.width/2, self.y+self.height/2

    def hits(self, rect, time):
        if self.kind in ("slush", "swamp"):
            return False  # Lama atrapalha os passos; os projéteis são o perigo.
        if not self.active(time):
            return False
        if self.kind == 'pendulum':
            _,mask,bounds=self.pendulum_pose(time)
            overlap=rect.clip(bounds)
            if not overlap:return False
            # O vazio da foice e o halo não causam dano.
            return mask.overlap_area(pygame.Mask(overlap.size,fill=True),
                                     (overlap.x-bounds.x,overlap.y-bounds.y))>0
        if self.kind in ("orb", "boulder", "hail", "ember"):
            return circle_hits_rect(self.center(time), self.height-3, rect)
        if self.kind == "arrow":
            if self.cycle(time) >= 2.2:
                return False
            x, y = self.center(time)
            return rect.colliderect(pygame.Rect(round(x)-15, round(y)-3, 30, 6))
        # A colisão fica dentro do desenho, nunca fora dele.
        return rect.colliderect(pygame.Rect(self.x+4, self.y+4, self.width-8, self.height-4))

    def draw(self, surface, offset, time):
        x, y = self.x-offset, self.y
        c = self.color
        if self.kind in ('spikes','spikes_down','spikes_timed'):
            down=self.kind=='spikes_down'
            extended=self.active(time)
            warning=self.kind=='spikes_timed' and .45<=self.cycle(time)<1.0
            if self.width>=26:
                height=self.height if extended else max(4,self.height//4)
                image=sprite('spikes' if extended else 'spikes_off',self.width,height)
                if down:image=pygame.transform.flip(image,False,True)
                surface.blit(image,(x,y if down else y+self.height-height))
            else:
                # Um espinho isolado nas bordas estreitas conserva a silhueta.
                base=y if down else y+self.height
                tip=y+self.height if down else y
                pygame.draw.polygon(surface,(51,48,54),((x,base),(x+self.width/2,tip),(x+self.width,base)))
                pygame.draw.lines(surface,(200,205,211),False,((x+2,base),(x+self.width/2,tip+(-2 if down else 2)),(x+self.width-2,base)),2)
                pygame.draw.line(surface,(105,74,61),(x,base),(x+self.width,base),3)
            if warning:
                pygame.draw.line(surface,(198,111,236),(x,y+self.height-2),(x+self.width,y+self.height-2),2)
            return
        if self.kind == 'rune':
            state=self.rune_state(time)
            disk_height=max(18,min(32,round(self.width*.45)))
            image=sprite('rune' if state in ('idle','cooldown') else 'rune_glow',self.width,disk_height)
            surface.blit(image,(x,y+self.height-disk_height+3))
            if state in ('charging','firing'):
                color=(94,59,119) if state=='charging' else c
                for yy in range(round(y),round(y+self.height-16),12):
                    pygame.draw.line(surface,color,(x+3,yy),(x+3,yy+4),1)
                    pygame.draw.line(surface,color,(x+self.width-3,yy),(x+self.width-3,yy+4),1)
            if state=='firing':
                beam=pygame.Surface((self.width,self.height),pygame.SRCALPHA)
                beam.fill((*c,75))
                for dx in range(7,self.width-5,9):
                    points=[(dx+round(math.sin(time*35+dy)*3),dy) for dy in range(5,self.height,10)]
                    if len(points)>1:pygame.draw.lines(beam,(233,197,255,235),False,points,2)
                surface.blit(beam,(x,y))
            return
        if self.kind == 'pendulum':
            px,py=self.center(time)
            end=(round(px-offset),round(py))
            pygame.draw.line(surface,(44,38,53),(x,y),end,4)
            for i in range(1,max(2,self.width//11)):
                amount=i/max(2,self.width//11)
                cx=x+(end[0]-x)*amount;cy=y+(end[1]-y)*amount
                pygame.draw.ellipse(surface,(147,134,160),(cx-2,cy-3,5,8),1)
            image,_,bounds=self.pendulum_pose(time)
            surface.blit(image,bounds.move(-offset,0))
            pygame.draw.circle(surface,(191,155,210),(round(x),round(y)),5,2)
            return
        if self.kind == 'chain':
            active = self.active(time)
            warning = .65 <= self.cycle(time) < 1.25
            color = c if active else (153, 100, 180) if warning else (50, 41, 64)
            for cy in range(round(y), round(y+self.height), 12):
                pygame.draw.ellipse(surface, color, (round(x),cy,self.width,16), 2 if active else 1)
            return
        if self.kind == "boulder":
            px,py=self.center(time)
            image=sprite('boulder',self.height*2,self.height*2,round(math.degrees(math.sin(time*1.25+self.phase))*2))
            surface.blit(image,image.get_rect(center=(round(px-offset),round(py))))
            return
        if self.kind in ("hail", "ember"):
            px, py = self.center(time)
            px = round(px-offset)
            for yy in range(y, 625, 22):
                pygame.draw.line(surface, tuple(v//4 for v in c), (px,yy),(px,yy+4))
            if py < 635:
                pygame.draw.line(surface, tuple(v//2 for v in c), (px,py-22),(px,py), 3)
                pygame.draw.polygon(surface, c, ((px,py-self.height),(px+self.height,py),
                                                (px,py+self.height),(px-self.height,py)))
            return
        if self.kind in ("orb", "pendulum"):
            px, py = self.center(time)
            px, py = round(px-offset), round(py)
            if self.kind == "pendulum":
                pygame.draw.line(surface, (91, 81, 91), (x, y), (px, py), 3)
                for i in range(1, 10):
                    pygame.draw.circle(surface, (157, 132, 101),
                                       (round(x+(px-x)*i/10), round(y+(py-y)*i/10)), 3, 1)
            for radius, color in ((self.height+6, (50, 31, 53)), (self.height, c),
                                  (self.height-5, (40, 26, 43))):
                pygame.draw.circle(surface, color, (px, py), radius)
            angle = time*1.8
            for i in range(4):
                a = angle+i*math.pi/2
                pygame.draw.line(surface, c, (px, py),
                                 (px+math.cos(a)*(self.height-2), py+math.sin(a)*(self.height-2)), 2)
            return
        if self.kind in ("acid", "slush", "swamp", "blood", "pitch"):
            pygame.draw.rect(surface, tuple(v//3 for v in c), (x, y, self.width, self.height))
            points = [(x+i, y+round(math.sin(time*3+i*.12)*2)) for i in range(0, self.width+1, 5)]
            pygame.draw.lines(surface, c, False, points, 3)
            for i in range(5):
                bx = x+(i*29+time*12) % self.width
                pygame.draw.circle(surface, c, (round(bx), y+6), 2, 1)
            return
        if self.kind == "arrow":
            # A linha pontilhada anuncia a altura do disparo.
            for i in range(0, self.width, 18):
                pygame.draw.line(surface, (93, 55, 72), (x-i, y), (x-i-5, y))
            pygame.draw.polygon(surface, c, ((x+5, y-9), (x-4, y), (x+5, y+9)), 2)
            if self.cycle(time) < 2.2:
                px, py = self.center(time)
                px -= offset
                pygame.draw.line(surface, c, (px-16, py), (px+14, py), 3)
                pygame.draw.lines(surface, c, False, ((px-8, py-6), (px-17, py), (px-8, py+6)), 2)
            return
        # Jatos: uma grelha permanente, 0,6 s de aviso, depois a coluna perigosa.
        floor = y+self.height
        pygame.draw.rect(surface, (43, 36, 52), (x, floor-5, self.width, 5))
        warning = .4 <= self.cycle(time) < 1
        color = c if warning or self.active(time) else tuple(v//3 for v in c)
        pygame.draw.line(surface, color, (x+3, floor-4), (x+self.width-3, floor-4), 3)
        for i in range(6, self.width, 12):
            pygame.draw.line(surface, color, (x+i, floor-8), (x+i+4, floor-2), 2)
        if warning:
            pygame.draw.polygon(surface, c, ((x+self.width/2, floor-24),
                                            (x+self.width/2-4, floor-17),
                                            (x+self.width/2+4, floor-17)), 1)
        if self.active(time):
            layer = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
            for i in range(0, self.width, 8):
                tip = 5+int((1+math.sin(time*19+i)) * 6)
                pygame.draw.polygon(layer, (*c, 155), ((i, self.height), (i, tip+10),
                                    (i+4, tip), (i+8, tip+18), (i+8, self.height)))
                pygame.draw.line(layer, (*c, 230), (i+4, tip+15), (i+4, self.height), 2)
            surface.blit(layer, (x, y))
