import pygame

def inicializa():
    pygame.init()
    window = pygame.display.set_mode((1024, 720))
    pygame.display.set_caption("Jogo")
    assets = {
        
    }
    return window, assets

def recebe_eventos(assets):
    game = True
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game = False
    return game


def desenha(window, assets):
    window.fill((0,0,0))
    pygame.display.update()

def game_loop(window, assets):
    
    game = True
    while game:
        game = recebe_eventos(assets)
        if not game:
            break
        desenha(window, assets)