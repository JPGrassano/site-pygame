"""Regressões da campanha, salvamento, riscos, retomada e conclusão."""
import json
import hashlib
import os
from pathlib import Path
import shutil
import unittest
import uuid

os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"
os.environ["PYGAME_HIDE_SUPPORT_PROMPT"] = "1"
import pygame

from campanha import CHAPTERS, CHECKPOINTS, WORLD_HEIGHT, WORLD_WIDTH, platform_layout
from mapa import ART, World
from motor import Game
from perigos import Hazard
from personagem import Controls, Player, STEP
from progresso import SaveStore, fresh_progress

TEMP_ROOT = Path(__file__).resolve().parent / "_temporario"
TEMP_ROOT.mkdir(exist_ok=True)


class TestDirectory:
    """Diretório herdando a permissão do projeto, inclusive no sandbox Windows."""
    def __init__(self):
        self.path = TEMP_ROOT / uuid.uuid4().hex
        self.path.mkdir()
        self.name = str(self.path)

    def cleanup(self):
        if self.path.resolve().is_relative_to(TEMP_ROOT.resolve()):
            shutil.rmtree(self.path)


class SaveTests(unittest.TestCase):
    def setUp(self):
        self.directory = TestDirectory()
        self.addCleanup(self.directory.cleanup)
        self.path = Path(self.directory.name)/"progresso.json"
        self.store = SaveStore(self.path)

    def test_missing_or_corrupt_save_recovers(self):
        self.assertEqual(self.store.load(), fresh_progress())
        for content in ("{", "null", "[]", '{"chapter": "oito", "seals": false}'):
            self.path.write_text(content, encoding="utf-8")
            self.assertEqual(self.store.load()["chapter"], 0)

    def test_save_round_trip_and_atomic_replacement(self):
        data = fresh_progress()
        data.update(chapter=8, checkpoint=2, seals=[0, 2], unlocked=8, seconds=13.5)
        self.assertTrue(self.store.save(data))
        self.assertEqual(self.store.load(), data)
        self.assertFalse(self.path.with_suffix(".tmp").exists())

    def test_invalid_values_cannot_break_map_indexing(self):
        self.path.write_text(json.dumps({"chapter": 50, "checkpoint": -5, "deaths": -2,
                                        "seals": [0, 1, 2, 3, "1", True, 0], "seconds": -90}), encoding="utf-8")
        loaded = self.store.load()
        self.assertEqual(loaded["chapter"], 8)
        self.assertEqual(loaded["checkpoint"], 0)
        self.assertEqual(loaded["seals"], [0, 1, 2])
        self.assertEqual(loaded["unlocked"], 8)
        self.assertEqual(loaded["seconds"], 0)


class CampaignTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        pygame.display.init()
        pygame.font.init()
        pygame.display.set_mode((1100, 650))

    def test_all_nine_circles_have_distinct_routes_and_mechanics(self):
        self.assertEqual(len(CHAPTERS), 9)
        self.assertEqual(len({c.mechanic for c in CHAPTERS}), 9)
        self.assertEqual(len({tuple(platform_layout(i)) for i in range(9)}), 9)

    def test_every_circle_uses_a_different_background_image(self):
        images = [(ART / f"{c.background}.png").read_bytes() for c in CHAPTERS]
        self.assertEqual(len({hashlib.sha256(image).digest() for image in images}), 9)

    @unittest.skip("Mecânica removida: substituída por descida livre")
    def test_portals_have_safe_support_at_their_own_height(self):
        for chapter in range(9):
            world = World(chapter)
            player = Player(world.portal.midbottom, (WORLD_WIDTH, WORLD_HEIGHT))
            self.assertEqual(world.portal.midbottom, world.layout.exit)
            self.assertTrue(player.on_platform(world.active_platforms()))

    def test_every_spawn_and_checkpoint_has_safe_solid_support(self):
        for chapter in range(9):
            world = World(chapter)
            for point in world.checkpoints:
                player = Player(point, (WORLD_WIDTH, WORLD_HEIGHT), auto_respawn=False)
                self.assertTrue(player.on_platform(world.active_platforms()), (chapter, point))
                for time in (0, 1.2, 2, 3.6, 8):
                    world.time = time
                    self.assertFalse(world.deadly(player.rect), (chapter, point, time))

    @unittest.skip("Mecânica removida: substituída por descida livre")
    def test_seals_require_dash_and_stay_broken(self):
        world = World(0)
        x, y = world.seals[0]
        rect = pygame.Rect(x-10, y-10, 22, 34)
        self.assertFalse(world.break_seals(rect, False))
        self.assertFalse(world.open)
        self.assertEqual(len(world.break_seals(rect, True)), 1)
        self.assertTrue(world.open)
        self.assertFalse(world.break_seals(rect, True))

    @unittest.skip("Mecânica removida: substituída por descida livre")
    def test_final_circle_requires_three_seals(self):
        world = World(8)
        for i, (x, y) in enumerate(world.seals):
            world.break_seals(pygame.Rect(x-10, y-10, 22, 34), True)
            self.assertEqual(world.open, i == 2)

    def test_checkpoint_only_activates_on_its_platform(self):
        world = World(0)
        player = Player((1880, 570), (WORLD_WIDTH, WORLD_HEIGHT))
        player.grounded = True
        self.assertFalse(world.activate_checkpoint(player))
        player.rect.midbottom = CHECKPOINTS[1]
        self.assertTrue(world.activate_checkpoint(player))
        self.assertEqual(world.spawn, CHECKPOINTS[1])

    def test_jets_warn_before_becoming_deadly_and_have_safe_interval(self):
        for kind in ("fire", "vapor", "frost"):
            hazard = Hazard(kind, 100, 400, 75, 100, 0)
            rect = pygame.Rect(110, 410, 22, 34)
            self.assertFalse(hazard.hits(rect, .7), kind)
            self.assertTrue(hazard.hits(rect, 1.2), kind)
            self.assertFalse(hazard.hits(rect, 2.3), kind)
            self.assertFalse(hazard.hits(rect.move(100, 0), 1.2), kind)

    def test_illusion_never_removes_checkpoint_support(self):
        world = World(7)
        self.assertTrue(world.illusory)
        for time in (0, .5, 1.5, 2.5, 3.7, 4.7):
            world.time = time
            for point in world.checkpoints:
                self.assertTrue(Player(point).on_platform(world.active_platforms()))

    def test_ice_preserves_more_momentum(self):
        floor = pygame.Rect(0, 570, 3600, 250)
        results = []
        for icy in (False, True):
            player = Player((150, 570))
            player.ice = icy
            player.vel.x = 235
            for _ in range(24):
                player.update(STEP, Controls(), floor)
            results.append(player.vel.x)
        self.assertEqual(results[0], 0)
        self.assertGreater(results[1], 180)

class GameTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.directory = TestDirectory()
        cls.game = Game(Path(cls.directory.name)/"save.json", headless=True)

    @classmethod
    def tearDownClass(cls):
        cls.directory.cleanup()

    def setUp(self):
        self.game.progress = fresh_progress()
        self.game.load_chapter(0, intro=False)

    def place(self, feet):
        self.game.player.rect.midbottom = feet
        self.game.player.pos.update(self.game.player.rect.topleft)

    def test_menu_quit_does_not_erase_a_saved_checkpoint(self):
        saved = fresh_progress()
        saved.update(chapter=8, unlocked=8, checkpoint=2, seals=[0, 1], started=True)
        self.game.store.save(saved)
        game = Game(self.game.store.path, headless=True)
        game.save()
        self.assertEqual(game.store.load(), saved)

    def test_death_returns_to_checkpoint_and_keeps_seals(self):
        self.game.world.checkpoint = 1
        self.game.world.broken = set()
        self.game.die()
        for _ in range(45):
            self.game.simulate(STEP, Controls())
        self.assertEqual(self.game.player.rect.midbottom, CHECKPOINTS[1])
        self.assertEqual(self.game.world.broken, set())
        self.assertEqual(self.game.progress["deaths"], 1)

    def test_play_always_starts_a_fresh_run(self):
        for index in range(9):
            self.game.load_chapter(index, checkpoint=2, intro=False)
            self.game.progress['seconds'] = 800
            self.game.change_state('menu')
            self.game.selected = 0
            self.game.activate()
            self.assertEqual(self.game.world.index, 0)
            self.assertEqual(self.game.world.checkpoint, 0)
            self.assertEqual(self.game.progress['seconds'], 0)
            self.assertEqual(self.game.player.rect.midbottom, CHECKPOINTS[0])

    def test_all_stage_transitions_and_ending_save(self):
        for chapter in range(9):
            self.assertEqual(self.game.world.index, chapter)
            self.game.world.broken = set(range(len(self.game.world.seals)))
            self.place((self.game.world.descent.centerx, self.game.world.descent.top))
            self.game.player.vel.update(0, 0)
            for _ in range(120):
                self.game.simulate(STEP, Controls())
                if self.game.world.index != chapter or self.game.state == 'result':
                    break
            for _ in range(90): self.game.update(1/60)
            if chapter < 8:
                self.assertEqual(self.game.state, "playing")
                self.assertEqual(self.game.store.load()["chapter"], chapter+1)
            else:
                self.assertEqual(self.game.state, "result")
                self.assertTrue(self.game.store.load()["completed"])
                self.game.selected = 1
                self.game.activate()
                self.assertEqual(self.game.state, "menu")
        self.assertEqual(self.game.progress["unlocked"], 8)

    def test_pause_freezes_world_and_character(self):
        before = self.game.player.rect.copy(), self.game.world.time
        self.game.escape()
        self.game.update(1)
        self.assertEqual(self.game.state, "paused")
        self.assertEqual(before, (self.game.player.rect, self.game.world.time))
        self.game.escape()
        self.assertEqual(self.game.state, "playing")

    def test_controls_return_to_pause(self):
        self.game.change_state("paused")
        self.game.selected = 1
        self.game.activate()
        self.assertEqual(self.game.state, "controls")
        self.game.escape()
        self.assertEqual(self.game.state, "paused")

    def test_audio_is_never_initialized(self):
        self.assertIsNone(pygame.mixer.get_init())


if __name__ == "__main__":
    unittest.main()
