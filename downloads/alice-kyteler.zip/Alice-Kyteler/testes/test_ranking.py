"""Fluxo completo de corrida, relógio, inscrição opcional e ranking persistente."""
import os
os.environ['SDL_VIDEODRIVER']='dummy'
os.environ['SDL_AUDIODRIVER']='dummy'
import json
from pathlib import Path
import unittest
import uuid
from unittest.mock import patch
import pygame
from motor import Game
from personagem import Controls,STEP,Player
from ranking import RankingStore,clean_name,duration_ms

class RaceTests(unittest.TestCase):
 def setUp(self):
  self.folder=Path(__file__).parent/'_temporario'/uuid.uuid4().hex
  self.folder.mkdir(parents=True)
  self.game=Game(self.folder/'save.json',headless=True)
  self.addCleanup(self.cleanup)
 def cleanup(self):
  for f in self.folder.iterdir():f.unlink()
  self.folder.rmdir()
 def finish(self,seconds=123.456):
  g=self.game;g.new_game()
  for index in range(9):
   self.assertEqual(g.world.index,index)
   g.progress['seconds']=seconds
   g.complete_chapter()
  self.assertEqual(g.state,'result')
  return g
 def test_menu_has_only_four_requested_actions(self):
  g=self.game
  self.assertEqual([name for name,_ in g.menu_options()],['Jogar','Ranking','Como jogar','Sair'])
  self.assertEqual(g.selected,0)
 def test_restart_zeros_every_part_of_run_but_preserves_ranking(self):
  g=self.game;g.ranking.add('Ana',120000,3,'old');g.new_game();run=g.run_id
  g.load_chapter(6,checkpoint=2,intro=False);g.progress.update(seconds=600,deaths=14)
  g.change_state('paused');g.selected=2;g.activate()
  self.assertEqual((g.world.index,g.world.checkpoint,g.progress['seconds'],g.progress['deaths']),(0,0,0,0))
  self.assertEqual(g.player.rect.midbottom,g.world.checkpoints[0]);self.assertNotEqual(g.run_id,run)
  self.assertEqual(len(g.ranking.entries()),1)
 def test_clock_counts_death_and_transitions_but_not_menus_or_pause(self):
  g=self.game;g.new_game();g.simulate(STEP,Controls());initial=g.progress['seconds']
  g.die();g.simulate(STEP,Controls());self.assertAlmostEqual(g.progress['seconds'],initial+STEP)
  g.change_state('paused');g.update(1);g.simulate(STEP,Controls())
  self.assertAlmostEqual(g.progress['seconds'],initial+STEP)
  g.change_state('playing');g.begin_descent();before=g.progress['seconds'];g.update(.2)
  self.assertAlmostEqual(g.progress['seconds'],before+.2)
 def test_declining_does_not_create_score(self):
  g=self.finish();value=g.final_ms
  g.update(10);self.assertEqual(g.final_ms,value)
  g.selected=1;g.activate();self.assertEqual(g.state,'menu');self.assertEqual(g.ranking.entries(),[])
 def test_unicode_name_input_save_and_reload(self):
  g=self.finish();g.activate();self.assertEqual(g.state,'name')
  pygame.event.post(pygame.event.Event(pygame.TEXTINPUT,text='João da Silva'))
  pygame.event.post(pygame.event.Event(pygame.KEYDOWN,key=pygame.K_SPACE))
  g.events();self.assertEqual(g.runner_name,'João da Silva');self.assertEqual(g.state,'name')
  pygame.event.post(pygame.event.Event(pygame.KEYDOWN,key=pygame.K_RETURN));g.events()
  self.assertEqual(g.state,'ranking')
  rows=RankingStore(g.ranking.path).entries()
  self.assertEqual([(r['name'],r['milliseconds']) for r in rows],[('João da Silva',123456)])
  g.register_result();self.assertEqual(len(g.ranking.entries()),1)
 def test_empty_name_and_cancel_keep_choice(self):
  g=self.finish();g.activate();g.activate()
  self.assertEqual(g.state,'name');self.assertTrue(g.result_error);self.assertFalse(g.ranking.path.exists())
  g.escape();self.assertEqual(g.state,'result');g.escape();self.assertEqual(g.state,'menu')
 def test_save_failure_preserves_result_for_retry(self):
  g=self.finish();g.activate();g.runner_name='Caio'
  with patch('ranking.os.replace',side_effect=OSError('disk full')):g.activate()
  self.assertEqual(g.state,'name');self.assertTrue(g.can_register());self.assertTrue(g.result_error)
  g.activate();self.assertEqual(g.state,'ranking');self.assertEqual(len(g.ranking.entries()),1)
 def test_only_full_run_can_register(self):
  g=self.game;g.new_game();g.load_chapter(8,intro=False);g.complete_chapter()
  self.assertFalse(g.can_register());g.runner_name='Atalho';g.register_result()
  self.assertFalse(g.ranking.path.exists())
 def test_ranking_sorted_stable_paginated_and_persistent(self):
  g=self.game
  for i in range(20):self.assertTrue(g.ranking.add(f'Pessoa {i}',(20-i)*1000,0,str(i)))
  g.ranking.add('Empate',1000,5,'tie')
  g.open_ranking();self.assertEqual(g.rank_rows[0]['name'],'Pessoa 19')
  self.assertEqual(g.rank_rows[1]['name'],'Empate')
  g.selected=1;g.activate();self.assertEqual(g.rank_page,1);g.draw()
  reloaded=Game(self.folder/'save.json',headless=True);reloaded.open_ranking()
  self.assertEqual(len(reloaded.rank_rows),21)
 def test_corrupt_ranking_is_not_silently_overwritten(self):
  store=self.game.ranking;store.path.write_text('{bad',encoding='utf-8')
  self.assertEqual(store.entries(),[]);self.assertTrue(store.error)
  self.assertFalse(store.add('Ana',123,0,'run'))
  self.assertEqual(store.path.read_text(encoding='utf-8'),'{bad')
 def test_format_validation_and_composed_accents(self):
  self.assertEqual(duration_ms(61509),'01:01.509')
  self.assertEqual(clean_name('Joa\u0303o'),'João')
  for time in (-1,True,float('nan'),0):self.assertFalse(self.game.ranking.add('A',time,0,'a'))
  self.assertLessEqual(len(clean_name('a'*50)),18)
 def test_upper_boundary_prevents_roof_skip(self):
  p=Player((200,40));p.vel.y=-850
  for _ in range(40):p.update(STEP,Controls(y=-1,dash=True),[])
  self.assertGreaterEqual(p.rect.top,0)

if __name__=='__main__':unittest.main()
