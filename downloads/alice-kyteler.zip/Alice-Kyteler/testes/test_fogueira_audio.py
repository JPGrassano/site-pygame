"""Fogueiras, arquivos de som reais, cadência dos apoios e pousos suaves."""
from array import array
import math
import os
from pathlib import Path
import unittest
from unittest.mock import patch
import uuid

os.environ['SDL_VIDEODRIVER'] = 'dummy'
os.environ['SDL_AUDIODRIVER'] = 'dummy'
import pygame
from audio import SoundDesign, SOUND_ROOT, locomotion_sound, synthesize
from fogueira import CampfireArt
from mapa import World
from motor import Game
from personagem import Controls, Player, STEP


class CampfireFeedbackTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        pygame.display.init()
        pygame.display.set_mode((1100, 650))

    def setUp(self):
        folder = Path(__file__).parent / '_temporario'
        folder.mkdir(exist_ok=True)
        self.save = folder / (uuid.uuid4().hex+'.json')

    def tearDown(self):
        self.save.unlink(missing_ok=True)

    def test_fire_has_distinct_animated_states_and_fixed_ground_anchor(self):
        art = CampfireArt()
        for row in art.frames:
            self.assertEqual(len(row), 4)
            self.assertEqual(len({pygame.image.tobytes(frame, 'RGBA') for frame in row}), 4)
            for frame in row:
                self.assertLessEqual(abs(frame.get_bounding_rect(min_alpha=80).bottom-70), 1)
                self.assertEqual(frame.get_at((0, 0)).a, 0)
        self.assertNotEqual(pygame.image.tobytes(art.frames[0][0], 'RGBA'),
                            pygame.image.tobytes(art.frames[1][0], 'RGBA'))
        self.assertEqual(art.blend(2, 2), 0)
        self.assertAlmostEqual(art.blend(2.275, 2), .5)
        self.assertEqual(art.blend(3, 2), 1)

    def test_low_dash_crossing_fire_activates_once_but_high_jump_does_not(self):
        world = World(0)
        x, y = world.checkpoints[1]
        player = Player((x, y-100))
        self.assertFalse(world.activate_checkpoint(player))
        previous = pygame.Rect(x-100, y-34, 22, 34)
        player.rect.midbottom = (x+80, y-10)
        self.assertFalse(player.grounded)
        self.assertTrue(world.activate_checkpoint(player, previous))
        self.assertEqual(world.checkpoint, 1)
        self.assertFalse(world.activate_checkpoint(player, previous))
        self.assertEqual(world.spawn, (x, y))

    def test_checkpoint_sound_fires_once_and_death_returns_to_fire(self):
        game = Game(self.save, headless=True)
        game.load_chapter(0, intro=False)
        point = game.world.checkpoints[1]
        game.player.rect.midbottom = point
        game.player.pos.update(game.player.rect.topleft)
        with patch.object(game.audio, 'play') as play:
            for _ in range(100):
                game.simulate(STEP, Controls())
            self.assertEqual(sum(call.args[0] == 'checkpoint' for call in play.call_args_list), 1)
        self.assertEqual(game.world.checkpoint, 1)
        self.assertEqual(game.world.spawn, point)
        game.retry()
        self.assertEqual(game.world.checkpoint, 1)
        self.assertEqual(game.player.rect.midbottom, point)

    def test_landing_has_sand_sound_but_never_adds_camera_shake(self):
        game = Game(self.save, headless=True)
        game.load_chapter(0, intro=False)
        x, y = game.world.spawn
        game.player.rect.midbottom = (x, y-90)
        game.player.pos.update(game.player.rect.topleft)
        game.player.vel.y = 400
        with patch.object(game.audio, 'play') as play:
            for _ in range(80):
                game.simulate(STEP, Controls())
                self.assertEqual(game.shake, 0)
            self.assertTrue(any(call.args[0] == 'land' for call in play.call_args_list))
            self.assertFalse(any(call.args[0] == 'step' for call in play.call_args_list))

    def test_steps_follow_animation_not_a_rapid_distance_timer(self):
        calls = []
        previous = 0
        for tick in range(1, 361):
            now = tick*STEP
            if locomotion_sound('run', 'run', now, previous, 235*STEP):
                calls.append(now)
            previous = now
        self.assertEqual(len(calls), 5)  # ~1.8 sons/s, antes ~5.6 sons/s.
        self.assertTrue(all(b-a >= .53 for a, b in zip(calls, calls[1:])))
        self.assertIsNone(locomotion_sound('run', 'run', .56, .54, 0))
        self.assertIsNone(locomotion_sound('run', 'idle', .56, .54, 2))
        self.assertEqual(locomotion_sound('climb', 'climb', .68, .65, .8), 'climb')


class ProvidedAudioTests(unittest.TestCase):
    def tearDown(self):
        pygame.mixer.quit()

    def test_provided_mp3s_are_loaded_with_original_tails_and_headroom(self):
        sound = SoundDesign()
        self.assertTrue(sound.available, sound.error)
        self.assertFalse(sound.recording_errors)
        for name in ('dash', 'checkpoint'):
            original = pygame.mixer.Sound(str(SOUND_ROOT / (name+'.mp3')))
            loaded = sound.sounds[name][0]
            self.assertLessEqual(original.get_length()-loaded.get_length(), .12)
            self.assertGreater(loaded.get_length(), 1)
            samples = array('h', loaded.get_raw())
            self.assertLessEqual(max(abs(s) for s in samples), 24500)
            self.assertEqual(samples[0], 0)
            self.assertEqual(samples[-1], 0)
        sound.play('checkpoint')
        self.assertTrue(pygame.mixer.Channel(15).get_busy())
        sound.play('dash')
        self.assertTrue(pygame.mixer.Channel(14).get_busy())
        self.assertTrue(pygame.mixer.Channel(15).get_busy())

    def test_sand_and_stone_are_quiet_but_have_distinct_textures(self):
        samples = {name: array('h', synthesize(name))[::2] for name in ('step', 'land', 'climb')}
        for values in samples.values():
            rms = math.sqrt(sum(v*v for v in values)/len(values))/32768
            self.assertLess(rms, .04)
            self.assertGreater(rms, .002)
        def crossings(values):
            return sum(a*b < 0 for a, b in zip(values, values[1:]))/len(values)
        self.assertGreater(crossings(samples['climb']), crossings(samples['step']))
        self.assertNotEqual(samples['climb'], samples['step'])
