"""Dados de uma fase. As coordenadas são pixels do mundo, não da tela."""
from dataclasses import dataclass

WORLD_WIDTH, WORLD_HEIGHT = 4800, 820


def floor(x, top, width):
    """Um bloco que se estende até o fundo do mundo."""
    return (x, top, width, WORLD_HEIGHT-top)


def ledge(x, top, width):
    """Uma plataforma suspensa, com 24 pixels de espessura."""
    return (x, top, width, 24)


@dataclass(frozen=True)
class Layout:
    name: str
    platforms: tuple
    checkpoints: tuple
    seal_feet: tuple
    exit: tuple
    hazards: tuple = ()
    illusion_x: tuple = ()
    # (parede interna esquerda, direita, chão, saída): poços de salto de parede.
    shafts: tuple = ()
    # x, y, largura, altura, deslocamento x/y, período e fase do transporte.
    movers: tuple = ()
    inscriptions: tuple = ()
    runes: tuple = ()
    ash: tuple = ()

    @property
    def seals(self):
        return tuple((x, y-36) for x, y in self.seal_feet)

    @property
    def goals(self):
        """Pontos de referência usados na verificação automatizada do percurso."""
        points = [(x, y, None) for x, y in self.checkpoints[1:]]
        points += [(x, y, i) for i, (x, y) in enumerate(self.seal_feet)]
        for left, right, bottom, top in self.shafts:
            points += [((left+right)//2, bottom, None), (right+55, top, None)]
        goals = []
        for x, y, seal in sorted(points, key=lambda p: (p[0], p[1], -1 if p[2] is None else p[2])):
            support = next(r for r in self.platforms if r[1] == y and r[0] <= x < r[0]+r[2])
            goals.append((x, y, min(140, support[2]), seal))
        return (*goals, (*self.exit, 90, None))
