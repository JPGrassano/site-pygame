import os,sys,unittest
from pathlib import Path
os.environ['SDL_VIDEODRIVER']='dummy';os.environ['SDL_AUDIODRIVER']='dummy'
sys.path.insert(0,str(Path(__file__).parents[1]))
import pygame
from personagem import Player,Controls,STEP,RUN_SPEED
from motor import Game
from mapa import World
from fases import LAYOUTS

class Mechanics(unittest.TestCase):
 def test_fast_fall_lands_earlier(self):
  floor=pygame.Rect(0,570,1000,250);times=[]
  for fast in (False,True):
   p=Player((200,300));p.vel.y=-150
   for tick in range(200):
    p.update(STEP,Controls(y=1 if fast else 0,jump_held=True),[floor])
    if p.grounded:times.append(tick);break
  self.assertLess(times[1],times[0]*.65)
 def test_slide_jump_preserves_speed_and_cannot_repeat_in_air(self):
  floor=pygame.Rect(0,570,2000,250);p=Player((200,570))
  p.update(STEP,Controls(x=1,dash=True),[floor])
  for _ in range(6):p.update(STEP,Controls(x=1),[floor])
  p.update(STEP,Controls(x=1,jump=True,jump_held=True),[floor])
  self.assertLess(p.vel.y,-400);self.assertGreater(p.vel.x,680)
  for _ in range(20):p.update(STEP,Controls(x=1,jump_held=True),[floor])
  self.assertGreater(p.vel.x,640);self.assertEqual(p.dashes,0)
 def test_checkpoint_counts_and_length_progression(self):
  self.assertEqual([len(x.checkpoints) for x in LAYOUTS],[4]*9)
  self.assertTrue(all(x.exit[0]>=4600 for x in LAYOUTS))
 def test_all_descents_animate_into_next_stage(self):
  path=Path(__file__).parent/'_temporario'/'descent-new.json';path.parent.mkdir(exist_ok=True)
  g=Game(path,headless=True)
  try:
   for i in range(9):
    g.load_chapter(i,intro=False);g.player.rect.midbottom=(g.world.descent.centerx,g.world.descent.top)
    g.player.pos.update(g.player.rect.topleft)
    for _ in range(150):
     g.simulate(STEP,Controls())
     if g.state=='descending':break
    self.assertEqual(g.state,'result' if i==8 else 'descending')
    for _ in range(90):g.update(1/60);g.draw()
    self.assertEqual(g.state,'result' if i==8 else 'playing')
    self.assertEqual(g.world.index,min(8,i+1))
  finally:path.unlink(missing_ok=True)
 def test_no_jump_runes_or_slowing_surfaces_in_any_circle(self):
  pygame.display.init();pygame.display.set_mode((1100,650))
  for index in range(9):
   w=World(index)
   self.assertEqual(w.layout.runes,())
   self.assertEqual(w.layout.ash,())
   self.assertFalse(any(h.kind in ('slush','swamp') for h in w.hazards))
   for rect in w.platforms:
    p=Player(rect.midtop);p.grounded=True;w.configure_player(p)
    self.assertEqual(p.speed_scale,1)

 def test_portuguese_titles_have_glyphs_and_accents(self):
  from interface import Interface
  pygame.font.init();ui=Interface()
  for name in ('Luxúria','Violência','Traição','Cócito','CÍRCULOS'):
   for font in ('title','heading','sub'):
    self.assertTrue(all(metric is not None for metric in ui.fonts[font].metrics(name)))
    plain=name.translate(str.maketrans('úêçãóÍ','uecaoI'))
    original=ui.fonts[font].render(name,True,'white')
    stripped=ui.fonts[font].render(plain,True,'white')
    self.assertNotEqual(pygame.image.tobytes(original,'RGBA'),pygame.image.tobytes(stripped,'RGBA'))

 def test_old_assist_save_is_ignored_and_pause_menu_returns_home(self):
  import uuid,json
  from progresso import SaveStore
  folder=Path(__file__).parent/'_temporario';folder.mkdir(exist_ok=True)
  path=folder/(uuid.uuid4().hex+'.json')
  try:
   path.write_text(json.dumps({'assist':True,'started':True,'chapter':2}))
   self.assertNotIn('assist',SaveStore(path).load())
   g=Game(path,headless=True);g.load_chapter(2,intro=False)
   g.change_state('paused')
   self.assertEqual([name for name,_ in g.menu_options()],['Retomar','Como jogar','Reiniciar','Voltar ao início'])
   g.selected=3;g.activate();self.assertEqual(g.state,'menu')
  finally:path.unlink(missing_ok=True)

if __name__=='__main__':unittest.main()

