"""História, nove círculos e dados dos percursos. Sem janela ou física."""
from dataclasses import dataclass
from fases import LAYOUTS
from fases.modelo import WORLD_WIDTH, WORLD_HEIGHT

# Atalhos para o mapa inicial; os demais círculos têm seus próprios retornos.
CHECKPOINTS = LAYOUTS[0].checkpoints
SPAWN = CHECKPOINTS[0]

PROLOGUE = (
    "Irlanda. Uma Idade Média que a história não registrou.",
    "Alice Kyteler foi chamada de bruxa. Suas palavras não foram ouvidas; seu corpo foi entregue ao fogo.",
    "Mas o fogo encontrou algo que não podia consumir.",
    "Sob as cinzas, Alice despertou nos nove círculos do Inferno. Cada círculo guardava uma corrente de sua sentença.",
    "Para voltar a ver o céu, ela teria de romper todas elas."
)
ENDING = (
    "O gelo se abriu. Pela primeira vez, não havia outra porta abaixo dela.",
    "Alice atravessou a última fenda e encontrou o amanhecer.",
    "Não recebera absolvição. Não pedira uma nova sentença. Recuperara algo que nunca deveria ter sido tomado: a própria voz.",
    "O nome que tentaram reduzir a cinzas voltou a pertencer a uma mulher.",
    "Alice Kyteler. Livre."
)


@dataclass(frozen=True)
class Chapter:
    number: int
    name: str
    subtitle: str
    background: str
    accent: tuple[int, int, int]
    tint: tuple[int, int, int]
    mechanic: str
    hint: str
    story: tuple[str, ...]
    release: str


CHAPTERS = (
    Chapter(1, "Limbo", "O nome entre as cinzas", "limbo_circulo", (187, 159, 232), (255, 245, 255), "quiet",
        "No castelo, alterne os saltos entre paredes. Atravesse as ruínas até a fenda.",
        ("Meu nome chegou antes de mim. Aqui, até os ecos parecem esquecer a quem pertencem.",
         "Se uma sentença me trouxe até este lugar, encontrarei a forma de atravessá-la."),
        "A primeira corrente perdeu o seu nome."),
    Chapter(2, "Luxúria", "A tempestade dos desejos", "luxuria_circulo", (203, 156, 232), (255, 226, 255), "wind",
        "Embarque na varanda móvel. Corrija o dash contra o vento e evite a esfera na travessia.",
        ("Chamaram meu desejo de viver de pecado. Depois, decidiram que poderiam escolher por mim.",
         "A tempestade pode me empurrar. Não vai escolher meu caminho."),
        "Alice retomou a direção da própria vida."),
    Chapter(3, "Gula", "As galerias do granizo", "gula_dante", (167, 190, 200), (219, 232, 238), "slush",
        "Atravesse os abrigos de pedra entre as linhas de granizo. Suba pelas paredes da galeria.",
        ("Foi minha vida que devoraram: minhas palavras, meus bens, meu futuro.",
         "Não oferecerei mais nada à fome deste lugar."),
        "A fome do abismo ficou para trás."),
    Chapter(4, "Avareza", "Os pesos em conflito", "avareza_dante", (230, 192, 112), (255, 230, 193), "boulders",
        "Saia do poço, salte sobre os pesos e embarque na plataforma entre as pistas.",
        ("Pesaram minha fortuna com mais cuidado do que pesaram as acusações.",
         "Hoje, atravessarei estes portões de mãos vazias e cabeça erguida."),
        "O peso da sentença já não era dela."),
    Chapter(5, "Ira", "Sob a pele do Estige", "ira_circulo", (120, 196, 187), (183, 235, 217), "swamp",
        "Duas balsas atravessam o Estige. Observe o vapor antes de saltar para as margens.",
        ("Minha raiva me manteve de pé. Também poderia ter se tornado outra prisão.",
         "Aprenderei a carregá-la sem deixá-la me carregar."),
        "O Estige não conseguiu guardar sua voz."),
    Chapter(6, "Heresia", "Os túmulos em chamas", "heresia_dante", (244, 155, 112), (255, 204, 188), "fire",
        "Os sepulcros avisam antes das chamas. Use o elevador e encadeie os saltos no poço alto.",
        ("Disseram que minhas perguntas eram uma ameaça. Acenderam a fogueira para não responder.",
         "Aqui, o fogo vai ouvir tudo o que não me deixaram dizer."),
        "Uma pergunta sobreviveu a todas as chamas."),
    Chapter(7, "Violência", "Sangue, bosque e areia", "violencia_dante", (234, 128, 151), (255, 218, 216), "arrows",
        "Alterne paredes no bosque, cruze o rio pela plataforma móvel e escape da chuva de fogo.",
        ("A fogueira não provou minha culpa. Só mostrou até onde estavam dispostos a ir.",
         "Não transformarei a violência que sofri no destino de outra pessoa."),
        "A sentença perdeu o direito de ferir."),
    Chapter(8, "Fraude", "As dez fossas de Malebolge", "fraude_dante", (183, 154, 244), (229, 202, 255), "illusion",
        "Pontes translúcidas desaparecem. Combine a travessia móvel com dois trechos de paredes.",
        ("Prometeram perdão se eu entregasse meu nome. Prometeram paz se eu aceitasse a mentira.",
         "Desta vez, escolherei o chão com os próprios olhos."),
        "Nenhuma promessa falsa a conduziria novamente."),
    Chapter(9, "Traição", "O gelo de Cócito", "traicao_dante", (153, 226, 239), (201, 242, 255), "ice",
        "Controle a inércia nos poços de gelo. Pouse entre os espinhos e guarde o dash para as passagens estreitas.",
        ("No fundo do mundo, congelaram o que restava da minha sentença.",
         "Não peço que me libertem. Eu mesma quebrarei os últimos vínculos."),
        "E então o Inferno ficou sem correntes."),
)


def platform_layout(chapter_index):
    return list(LAYOUTS[chapter_index].platforms)


def seal_positions(chapter_index):
    return LAYOUTS[chapter_index].seals


def danger_layout(chapter_index):
    return LAYOUTS[chapter_index].hazards
