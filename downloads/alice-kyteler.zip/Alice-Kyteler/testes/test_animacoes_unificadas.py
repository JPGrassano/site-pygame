"""Regressões que evitam mudança de escala, recortes e versões diferentes à esquerda."""
import os
import unittest

os.environ['SDL_VIDEODRIVER'] = 'dummy'
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = '1'
import pygame
from personagem import Animations


class UnifiedAnimationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        pygame.display.init()
        pygame.display.set_mode((1100,650))
        cls.bank = Animations()

    def test_left_facing_is_the_exact_same_art_mirrored(self):
        for state in ('idle','run','jump','climb'):
            for right,left in zip(self.bank.frames[state,1],self.bank.frames[state,-1]):
                expected=pygame.transform.flip(right.image,True,False)
                self.assertEqual(pygame.image.tobytes(expected,'RGBA'),pygame.image.tobytes(left.image,'RGBA'))
        for direction in ((1,0),(1,-1),(1,1)):
            opposite=(-1,direction[1])
            for right,left in zip(self.bank.dashes[direction],self.bank.dashes[opposite]):
                expected=pygame.transform.flip(right.image,True,False)
                self.assertEqual(pygame.image.tobytes(expected,'RGBA'),pygame.image.tobytes(left.image,'RGBA'))

    def test_running_to_dashing_does_not_shift_body_vertical_anchor(self):
        body_centers=[]
        frames=[*self.bank.frames['idle',1],*self.bank.frames['run',1]]
        frames += [frame for direction in self.bank.dashes.values() for frame in direction]
        for frame in frames:
            bounds=frame.image.get_bounding_rect(min_alpha=80)
            body_centers.append(bounds.centery-frame.pivot[1])
            self.assertGreater(bounds.left,0)
            self.assertGreater(bounds.top,0)
            self.assertLess(bounds.right,frame.image.get_width())
            self.assertLess(bounds.bottom,frame.image.get_height())
            for corner in ((0,0),(frame.image.get_width()-1,0),(0,frame.image.get_height()-1)):
                self.assertEqual(frame.image.get_at(corner).a,0)
        self.assertLessEqual(max(body_centers)-min(body_centers),5)

    def test_jump_pose_follows_rise_apex_fall_and_landing(self):
        frames=self.bank.frames['jump',1]
        self.assertIs(self.bank.get('jump',1,.01,vy=-540),frames[0])
        self.assertIs(self.bank.get('jump',1,.15,vy=-300),frames[1])
        self.assertIs(self.bank.get('jump',1,.3,vy=0),frames[2])
        self.assertIs(self.bank.get('jump',1,.5,vy=240),frames[3])
        self.assertIs(self.bank.get('land',1,.03),frames[4])
        self.assertIs(self.bank.get('land',1,.08),frames[5])
