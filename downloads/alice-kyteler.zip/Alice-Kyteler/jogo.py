"""Ponto de entrada: execute com py jogo.py."""
from motor import main


if __name__ == "__main__":
    main()
