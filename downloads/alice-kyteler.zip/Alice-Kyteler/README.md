esse aqui é o jogo massa do jp e do mc caio, tamo junto.

## Alice Kyteler — Corrida dos Nove Círculos

O jogo completo está nesta pasta. Abra **Jogar.bat**, execute `py jogo.py`
ou selecione **Jogar Alice Kyteler — Nove Círculos** no depurador do VS Code.
Dependências: `py -m pip install -r requirements.txt`.

Controles: WASD, Espaço para pular, K para dash, L para escalar e Esc para pausar.
Veja [LEIA-ME.txt](LEIA-ME.txt) para a organização dos arquivos e controles.
Verificação: `py -m unittest discover -s testes -v`.

`jogo.py` chama `motor.py`; os movimentos ficam em `personagem.py`, os
percursos em `fases/` e as plataformas móveis em `plataformas.py`.
Este pacote contém os recursos usados pelo jogo atual, em `bruxa/`, `cenario/`,
`sons/` e `fontes/`. As cópias de arte dos protótipos antigos ficam no repositório.

Jogar inicia uma tentativa do zero. Ao concluir, o registro de nome e tempo no ranking local é opcional. Esc → Reiniciar zera a corrida.
