"""Transporte, saltos e colisões dos apoios móveis com a física do jogo."""
import os
import unittest

os.environ['SDL_VIDEODRIVER'] = 'dummy'
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = '1'
import pygame

from mapa import World
from plataformas import MovingPlatform, transport_player
from personagem import Player, Controls, STEP


class MovingPlatformTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        pygame.display.init()
        pygame.display.set_mode((1100,650))

    def world(self, data, solids=()):
        world = World(0)
        world.platforms = [pygame.Rect(r) for r in solids]
        world.illusory = set()
        world.hazards = []
        world.movers = [MovingPlatform(*data)]
        world.time = 0
        return world

    def advance(self, world, player, seconds, controls=None):
        controls = controls or Controls()
        for _ in range(round(seconds/STEP)):
            world.step_player(STEP,controls,player)
            controls = Controls(controls.x,controls.y,False,controls.jump_held,False,controls.grab)
            self.assertFalse(world.crushed)

    def test_endpoints_period_and_phase_are_reproducible(self):
        mover = MovingPlatform(200,400,120,20,180,-100,4,0)
        self.assertEqual(mover.rect_at(0).topleft,(200,400))
        self.assertEqual(mover.rect_at(2).topleft,(380,300))
        self.assertEqual(mover.rect_at(4),mover.rect_at(0))
        phased = MovingPlatform(200,400,120,20,180,-100,4,2)
        self.assertEqual(phased.rect_at(0),mover.rect_at(2))

    def test_horizontal_carriage_keeps_relative_feet_and_refills_dash(self):
        world = self.world((200,400,120,20,180,0,4,0))
        player = Player((260,400),(2400,820),False)
        player.dashes = 0
        self.advance(world,player,2)
        self.assertEqual(player.rect.midbottom,(440,400))
        self.assertTrue(player.grounded)
        self.assertEqual(player.dashes,1)

    def test_elevator_keeps_feet_on_both_rising_and_descending_half_cycles(self):
        world = self.world((200,460,120,20,0,-180,4,0))
        player = Player((260,460),(2400,820),False)
        for _ in range(480):
            world.step_player(STEP,Controls(),player)
            self.assertEqual(player.rect.bottom,world.moving_rects()[0].top)
            self.assertTrue(player.grounded)
            self.assertFalse(world.crushed)
        self.assertEqual(player.rect.midbottom,(260,460))

    def test_jump_detaches_from_platform_and_is_not_cancelled(self):
        world = self.world((200,420,120,20,240,0,4,0))
        player = Player((260,420),(2400,820),False)
        self.advance(world,player,.4)
        world.step_player(STEP,Controls(jump=True,jump_held=True),player)
        x = player.rect.centerx
        self.advance(world,player,.2,Controls(jump_held=True))
        self.assertLess(player.rect.bottom,world.moving_rects()[0].top-40)
        self.assertFalse(player.grounded)
        self.assertAlmostEqual(player.rect.centerx,x,delta=1)

    def test_rising_elevator_catches_falling_player_without_overlap(self):
        world = self.world((200,500,120,20,0,-180,4,0))
        player = Player((260,390),(2400,820),False)
        for _ in range(100):
            world.step_player(STEP,Controls(),player)
            self.assertFalse(player.rect.colliderect(world.moving_rects()[0]))
            if player.grounded:
                break
        self.assertTrue(player.grounded)
        self.assertEqual(player.rect.bottom,world.moving_rects()[0].top)

    def test_climbing_moving_wall_then_jumping_away_while_grab_is_held(self):
        world = self.world((500,300,40,220,100,0,4,0))
        player = Player((489,470),(2400,820),False)
        self.advance(world,player,.1,Controls(x=1,y=-1,grab=True))
        self.assertEqual(player.state,'climb')
        self.assertEqual(player.rect.right,world.moving_rects()[0].left)
        world.step_player(STEP,Controls(x=1,y=-1,jump=True,jump_held=True,grab=True),player)
        self.assertLess(player.vel.x,-200)
        self.assertLess(player.vel.y,-400)
        self.assertEqual(player.state,'jump')

    def test_horizontal_push_respects_static_wall_and_reports_real_crush(self):
        old = pygame.Rect(250,400,60,40)
        new = old.move(4,0)
        player = Player((321,440),(2400,820),False)
        wall = pygame.Rect(332,350,100,200)
        self.assertTrue(transport_player(player,[old],[new],[wall]))
        self.assertEqual(player.rect.right,wall.left)
        self.assertFalse(player.rect.colliderect(wall))

    def test_elevator_cannot_silently_embed_rider_in_ceiling(self):
        world = self.world((200,400,120,20,0,-180,4,0),((180,280,160,20),))
        player = Player((260,400),(2400,820),False)
        for _ in range(240):
            world.step_player(STEP,Controls(),player)
            if world.crushed:
                break
        self.assertTrue(world.crushed)
        self.assertTrue(world.deadly(player.rect))
        self.assertFalse(player.rect.colliderect(world.platforms[0]))

    def test_resetting_time_resets_geometry_without_hidden_mover_state(self):
        world = self.world((200,400,120,20,180,-100,4,.3))
        initial = world.active_platforms()
        world.time = 8.75
        self.assertNotEqual(world.active_platforms(),initial)
        world.time = 0
        self.assertEqual(world.active_platforms(),initial)

    def test_large_step_is_subdivided_and_does_not_teleport_through_player(self):
        world = self.world((200,410,60,35,300,0,1,0),((0,450,2400,370),))
        player = Player((350,450),(2400,820),False)
        world.step_player(.5,Controls(),player)
        self.assertFalse(world.crushed)
        self.assertGreaterEqual(player.rect.left,world.moving_rects()[0].right)
        self.assertFalse(player.rect.colliderect(world.moving_rects()[0]))

    def test_game_pause_freezes_the_moving_geometry(self):
        from motor import Game
        from pathlib import Path
        from test_campanha import TestDirectory
        folder = TestDirectory()
        try:
            game = Game(Path(folder.name)/'moving-save.json',headless=True)
            game.load_chapter(0,intro=False)
            game.world.movers = [MovingPlatform(200,400,120,20,180,0,4)]
            before = game.world.time, game.world.moving_rects()
            game.change_state('paused')
            game.update(.5)
            self.assertEqual(before,(game.world.time,game.world.moving_rects()))
        finally:
            folder.cleanup()


if __name__ == '__main__':
    unittest.main()
