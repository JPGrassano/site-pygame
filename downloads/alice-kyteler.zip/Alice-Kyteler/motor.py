"""Liga personagem, mapas, interface e progresso; mantém o ciclo do jogo."""
from __future__ import annotations

import argparse
import math
import os
import uuid
from pathlib import Path

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
import pygame

from campanha import CHAPTERS, ENDING, PROLOGUE, WORLD_HEIGHT, WORLD_WIDTH
from audio import SoundDesign, locomotion_sound
from efeitos import MAGIC, Particles
from interface import GOLD, INK, MUTED, PAPER, VIOLET, Interface
from mapa import World
from personagem import Animations, Controls, HEIGHT, Player, STEP, WIDTH
from progresso import SaveStore, fresh_progress
from ranking import RankingStore, clean_name, duration_ms


class Game:
    def __init__(self, save_path=None, headless=False):
        pygame.display.init()
        pygame.font.init()
        self.headless = headless
        self.fullscreen = False
        self.window = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
        pygame.display.set_caption("Alice Kyteler — Nove Círculos")
        self.surface = pygame.Surface((WIDTH, HEIGHT))
        self.scene = pygame.Surface((WIDTH, HEIGHT))
        self.ui, self.animations = Interface(), Animations()
        self.map_return = "menu"
        pygame.display.set_icon(pygame.transform.scale(self.animations.frames["idle", 1][0].image, (48, 48)))
        self.store = SaveStore(save_path)
        self.progress = fresh_progress()
        self.ranking = RankingStore(self.store.path.with_name('ranking.json'))
        self.rank_page = 0
        self.rank_rows = []
        self.run_id = None
        self.run_chapters = set()
        self.final_ms = None
        self.result_saved = False
        self.runner_name = ''
        self.result_error = '' 
        self.session_loaded = False
        self.world = World(0)
        self.player = Player(self.world.spawn, (WORLD_WIDTH, WORLD_HEIGHT), auto_respawn=False)
        self.effects = Particles()
        self.audio = SoundDesign(enabled=not headless)
        self.running, self.state, self.return_state = True, "menu", "menu"
        self.selected, self.menu_time, self.state_time = 0, 0.0, 0.0
        self.accumulator, self.autosave = 0.0, 0.0
        self.pending_jump = self.pending_dash = False
        self.death_timer = self.invulnerable = self.shake = 0.0
        self.toast, self.toast_time = "", 0.0
        self.previous_chapter = 0
        self.debug = False
        self.pause_sound_hover = False
        self.viewport = pygame.Rect(0, 0, WIDTH, HEIGHT)

    def change_state(self, state):
        if self.state == 'name' and state != 'name':
            pygame.key.stop_text_input()
        self.state, self.selected, self.state_time = state, 0, 0
        if state == 'name':
            pygame.key.start_text_input()
            pygame.key.set_text_input_rect(pygame.Rect(320,320,460,55))
        self.audio.set_music_context(self.world.index, state, self.return_state)
        self.accumulator = 0
        self.pending_jump = self.pending_dash = False
        self.selected = next((i for i,(_,enabled) in enumerate(self.menu_options()) if enabled),0)

    def notify(self, message, duration=3.3):
        self.toast, self.toast_time = message, duration

    def save(self):
        if not self.session_loaded:
            return
        if self.session_loaded:
            self.progress["checkpoint"] = self.world.checkpoint
            self.progress["seals"] = sorted(self.world.broken)
        if not self.store.save(self.progress):
            self.notify("Não foi possível salvar. Confira a permissão da pasta de progresso.", 7)

    def load_chapter(self, index, checkpoint=0, seals=(), intro=True):
        self.session_loaded = True
        self.world = World(index, checkpoint=checkpoint, seals=seals)
        self.player = Player(self.world.spawn, (WORLD_WIDTH, WORLD_HEIGHT), auto_respawn=False)
        self.player.reset()
        self.effects = Particles()
        self.death_timer, self.invulnerable, self.shake = 0, .7, 0
        self.progress.update(chapter=index, checkpoint=checkpoint, seals=list(self.world.broken), started=True)
        self.progress["unlocked"] = max(index, self.progress["unlocked"])
        self.toast_time = 0
        self.change_state("intro" if intro else "playing")
        self.save()

    def new_game(self):
        self.run_id = uuid.uuid4().hex
        self.run_chapters = set()
        self.final_ms = None
        self.result_saved = False
        self.runner_name = self.result_error = ''
        self.autosave = 0
        self.progress = fresh_progress()
        self.load_chapter(0, intro=False)
        self.change_state("playing")

    def retry(self):
        self.player.spawn = self.world.spawn
        self.player.reset()
        self.invulnerable = .65
        self.death_timer = 0
        self.audio.play("respawn")
        self.effects = Particles()
        self.effects.burst(self.player.rect.center, self.world.chapter.accent, 20, 90)
        self.world.camera_x = max(0, min(WORLD_WIDTH-WIDTH, self.player.rect.centerx-WIDTH*.38))
        self.pending_jump = self.pending_dash = False

    def die(self):
        if self.death_timer:
            return
        self.progress["deaths"] += 1
        self.death_timer, self.shake = .32, 5
        self.audio.play("death")
        self.effects.burst(self.player.rect.center, (220, 178, 230), 38, 190)
        self.save()

    def complete_chapter(self):
        self.audio.play("complete")
        self.previous_chapter = self.world.index
        self.run_chapters.add(self.world.index)
        if self.world.index == 8:
            self.progress["completed"] = True
            self.final_ms = max(1, round(self.progress['seconds']*1000))
            self.save()
            self.change_state("result")
        else:
            self.load_chapter(self.previous_chapter+1, intro=False)
            self.change_state("playing")

    def begin_descent(self):
        if self.world.index == 8:
            self.complete_chapter()
            return
        self.descent_feet = (self.player.rect.centerx-self.world.offset, self.player.rect.bottom)
        self.death_timer = 1  # Apenas para capturar o cenário sem duplicar a bruxa.
        self.draw_world()
        self.death_timer = 0
        self.descent_scene = self.surface.copy()
        self.descent_loaded = False
        self.change_state('descending')

    def update_descent(self):
        elapsed = self.state_time
        if elapsed >= .55 and not self.descent_loaded:
            self.complete_chapter()
            if self.state == 'result':
                return
            self.state = 'descending'
            self.state_time = elapsed
            self.descent_loaded = True
        if elapsed >= 1.35:
            self.change_state('playing')
            self.invulnerable = .45

    def draw_descent(self):
        t = self.state_time
        if not self.descent_loaded:
            self.surface.fill(INK)
            self.surface.blit(self.descent_scene, (0, -round(HEIGHT*(t/.55)**2)))
            x,y = self.descent_feet
            self.animations.get('jump', self.player.facing, .5, vy=650).draw(self.surface,(x,y+450*t+700*t*t))
            return
        self.world.draw_background(self.surface)
        self.world.draw_platforms(self.surface)
        self.world.draw_atmosphere(self.surface)
        amount = min(1, max(0, (t-.55)/.8))
        feet_y = -65+(self.player.spawn[1]+65)*amount**1.35
        self.animations.get('jump', 1, .5, vy=500).draw(
            self.surface, (self.player.rect.centerx-self.world.offset, feet_y))
        self.ui.text(self.surface, self.world.chapter.name.upper(), 550, 70, 'heading', center=True)

    def menu_options(self):
        if self.state == "menu":
            return [("Jogar", True), ("Ranking", True),
                    ("Como jogar", True), ("Sair", True)]
        if self.state == "paused":
            return [("Retomar", True), ("Como jogar", True),
                    ("Reiniciar", True), ("Voltar ao início", True)]
        if self.state == 'result':
            return [('Registrar meu tempo', self.can_register()), ('Não registrar · início', True)]
        if self.state == 'name':
            return [('Salvar tempo', True), ('Voltar', True)]
        if self.state == 'ranking':
            pages = max(1, (len(self.rank_rows)+7)//8)
            return [('Anterior', self.rank_page>0), ('Próxima', self.rank_page<pages-1), ('Voltar ao início', True)]
        return []

    def activate(self):
        self.audio.play("ui")
        options = self.menu_options()
        if options:
            if not options[self.selected][1]:
                return
            choice = self.selected
            if self.state == "menu":
                if choice == 0:
                    self.new_game()
                elif choice == 1:
                    self.open_ranking()
                elif choice == 2:
                    self.return_state = "menu"
                    self.change_state("controls")
                else:
                    self.running = False
            elif self.state == "paused":
                if choice == 0:
                    self.change_state("playing")
                elif choice == 1:
                    self.return_state = "paused"
                    self.change_state("controls")
                elif choice == 2:
                    self.new_game()
                else:
                    self.save()
                    self.run_id = None
                    self.change_state("menu")
            elif self.state == 'result':
                if choice == 0:
                    self.change_state('name')
                else:
                    self.run_id = None
                    self.change_state('menu')
            elif self.state == 'name':
                if choice == 0:
                    self.register_result()
                else:
                    self.change_state('result')
            elif self.state == 'ranking':
                if choice == 2:
                    self.change_state('menu')
                else:
                    self.rank_page += -1 if choice == 0 else 1
            return
        if self.state == "prologue":
            self.change_state("playing")
        elif self.state == "intro":
            self.change_state("playing")
            self.notify(self.world.chapter.hint, 5)
        elif self.state == "clear":
            self.change_state("playing")
        elif self.state == "ending":
            self.change_state("credits")
        elif self.state == "credits":
            self.change_state("menu")
        elif self.state == "controls":
            self.change_state(self.return_state)

    def escape(self):
        if self.state == "playing":
            self.save()
            self.change_state("paused")
        elif self.state == "paused":
            self.change_state("playing")
        elif self.state == "controls":
            self.change_state(self.return_state)
        elif self.state == 'name':
            self.change_state('result')
        elif self.state in ('result', 'ranking', "credits"):
            self.run_id = None
            self.change_state("menu")
        elif self.state != "menu":
            self.activate()

    def events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            elif event.type == pygame.WINDOWFOCUSLOST and self.state == "playing" and not self.headless:
                self.escape()
            elif event.type == pygame.TEXTINPUT and self.state == 'name':
                self.runner_name = clean_name(self.runner_name+event.text)
                self.result_error = ''
            elif event.type == pygame.KEYDOWN:
                key = event.key
                if key == pygame.K_F11:
                    self.fullscreen = not self.fullscreen
                    self.window = pygame.display.set_mode((0, 0) if self.fullscreen else (WIDTH, HEIGHT),
                                                         pygame.FULLSCREEN if self.fullscreen else pygame.RESIZABLE)
                elif key == pygame.K_ESCAPE:
                    self.escape()
                elif key == pygame.K_F3:
                    muted = self.audio.toggle()
                    self.notify("Som desligado · F3" if muted else "Som ligado · F3")
                elif key == pygame.K_F1:
                    self.debug = not self.debug
                elif self.state == 'name':
                    if key == pygame.K_BACKSPACE:
                        self.runner_name = self.runner_name[:-1]
                    elif key == pygame.K_TAB:
                        self.selected = 1-self.selected
                    elif key == pygame.K_RETURN:
                        self.activate()
                elif self.state == "playing":
                    if key == pygame.K_SPACE:
                        self.pending_jump = True
                    elif key == pygame.K_k:
                        self.pending_dash = True
                    elif key == pygame.K_r:
                        self.die()
                elif key in (pygame.K_RETURN, pygame.K_SPACE):
                    self.activate()
                elif self.menu_options() and key in (pygame.K_DOWN, pygame.K_s, pygame.K_UP, pygame.K_w, pygame.K_a, pygame.K_d):
                    self.selected = (self.selected+(1 if key in (pygame.K_DOWN, pygame.K_s, pygame.K_d) else -1)) % len(self.menu_options())
                    self.audio.play("ui", .65)
            elif event.type in (pygame.MOUSEMOTION, pygame.MOUSEBUTTONDOWN) and self.menu_options():
                mx, my = event.pos
                mx = (mx-self.viewport.x)*WIDTH/self.viewport.width
                my = (my-self.viewport.y)*HEIGHT/self.viewport.height
                if self.state == 'paused':
                    self.pause_sound_hover = self.pause_sound_rect.collidepoint(mx,my)
                    if self.pause_sound_hover and event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                        self.audio.toggle()
                        continue
                for rect, index in self.ui.buttons:
                    if rect.collidepoint(mx, my):
                        self.selected = index
                        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                            self.activate()
                        break

    def simulate(self, dt, controls):
        if self.state != "playing":
            return
        self.audio.update(dt)
        self.toast_time = max(0, self.toast_time-dt)
        self.invulnerable = max(0, self.invulnerable-dt)
        self.shake = max(0, self.shake-dt*22)
        self.effects.update(dt)
        self.progress["seconds"] += dt
        if self.death_timer:
            self.death_timer = max(0, self.death_timer-dt)
            if not self.death_timer:
                self.retry()
            return
        previous = self.player.rect.copy()
        previous_pos = self.player.pos.copy()
        previous_state, previous_clock = self.player.state, self.player.anim_clock
        was_dashing = self.player.dash_time > 0
        self.world.step_player(dt, controls, self.player)
        started_dash = any(name == "dash" for name, _ in self.player.events)
        dashing = was_dashing or started_dash or self.player.dash_time > 0
        accent = self.world.chapter.accent
        pan = ((self.player.rect.centerx-self.world.offset)/WIDTH-.5)*1.1
        for name, strength in self.player.events:
            if name != "recharge":
                self.audio.play(name, strength, pan)
            if name == "dash":
                self.shake = max(self.shake, 3.5)
                self.effects.pulse((previous.centerx, previous.bottom-34), MAGIC, 32)
                self.effects.magic_burst((previous.centerx, previous.bottom-34), 10,
                                         self.player.dash_direction, 135)
                self.effects.trail_timer = 0
            elif name == "dash_hit":
                self.shake = max(self.shake, 4.5)
                self.effects.magic_burst(self.player.rect.center, 8, speed=100)
            elif name == "land":
                self.effects.dust(self.player.rect.midbottom, (166, 145, 119), strength*.55)
            elif name in ("jump", "wall_jump"):
                self.effects.dust(previous.midbottom,
                                  (139, 131, 148) if name == "wall_jump" else (166, 145, 119), .25)
            elif name == "recharge":
                self.effects.pulse(self.player.rect.center, MAGIC, 18)
        if dashing:
            self.effects.dash_trail(self.player, self.animations, MAGIC)
        displacement = self.player.pos-previous_pos
        distance = abs(displacement.x if self.player.state == "run" else displacement.y)
        cue = locomotion_sound(self.player.state, previous_state, self.player.anim_clock,
                                previous_clock, distance)
        if cue:
            self.audio.play(cue, .7, pan)
        if (self.player.vel.y > 0 and self.world.descent.left <= self.player.rect.centerx <= self.world.descent.right
                and self.player.rect.top > self.world.descent.top+48):
            self.begin_descent()
            return
        if self.world.deadly(self.player.rect) and (self.world.crushed or not self.invulnerable or self.player.rect.top > WORLD_HEIGHT):
            self.die()
            return
        if self.world.activate_checkpoint(self.player, previous):
            self.audio.play("checkpoint")
            fire = (self.world.spawn[0], self.world.spawn[1]-28)
            self.effects.magic_burst(fire, 10, speed=45)
            self.effects.pulse(fire, MAGIC, 28)
            self.notify("Fogueira vinculada. Seu caminho foi salvo.")
            self.save()

    def update(self, dt):
        self.menu_time += dt
        self.state_time += dt
        if self.state == "descending":
            self.progress["seconds"] += dt
            self.update_descent()
            return
        if self.state != "playing":
            self.audio.update(dt)
            return
        keys = pygame.key.get_pressed()
        x = int(keys[pygame.K_d])-int(keys[pygame.K_a])
        y = int(keys[pygame.K_s])-int(keys[pygame.K_w])
        held = keys[pygame.K_SPACE]
        grab = keys[pygame.K_l]
        self.accumulator = min(.08, self.accumulator+dt)
        while self.accumulator >= STEP and self.state == "playing":
            controls = Controls(x, y, self.pending_jump, held, self.pending_dash, grab)
            self.pending_jump = self.pending_dash = False
            self.simulate(STEP, controls)
            self.accumulator -= STEP
        self.autosave += dt
        if self.autosave >= 12:
            self.save()
            self.autosave = 0

    def draw_world(self):
        self.world.draw_background(self.scene)
        self.world.draw_platforms(self.scene)
        self.effects.draw(self.scene, self.world.offset)
        if not self.death_timer and (not self.invulnerable or int(self.invulnerable*14)%2 == 0):
            self.player.draw(self.scene, self.animations, self.world.offset)
        self.world.draw_atmosphere(self.scene)
        self.world.draw_instructions(self.scene)
        if self.debug:
            for rect in self.world.active_platforms():
                pygame.draw.rect(self.scene, (70, 240, 170), rect.move(-self.world.offset, 0), 1)
            pygame.draw.rect(self.scene, (255, 240, 90), self.player.rect.move(-self.world.offset, 0), 1)
        shake_x = round(math.sin(self.menu_time*99)*self.shake)
        shake_y = round(math.cos(self.menu_time*85)*self.shake*.5)
        self.surface.fill(INK)
        self.surface.blit(self.scene, (shake_x, shake_y))

    def draw_menu(self):
        self.world.draw_background(self.surface)
        self.ui.veil(self.surface, 125)
        self.ui.text(self.surface, "UMA SENTENÇA NÃO É UM DESTINO", 79, 74, "tiny", GOLD)
        self.ui.text(self.surface, "ALICE", 72, 106, "title")
        self.ui.text(self.surface, "KYTELER", 72, 165, "title")
        self.ui.text(self.surface, "N O V E   C Í R C U L O S", 77, 244, "small", VIOLET)
        self.ui.menu(self.surface, self.menu_options(), self.selected, 76, 304, 330, 45)
        # Retrato feito com o próprio sprite, preservando a arte da personagem.
        center = (797, 330)
        pygame.draw.circle(self.surface, (48, 37, 66), center, 159, 1)
        pygame.draw.circle(self.surface, (76, 58, 95), center, 146, 1)
        for i in range(9):
            angle = -math.pi/2+i*math.tau/9
            point = (round(center[0]+math.cos(angle)*159), round(center[1]+math.sin(angle)*159))
            pygame.draw.circle(self.surface, GOLD if i <= self.progress["unlocked"] else (97, 75, 117), point, 5, 1)
        frame = self.animations.get("idle", 1, self.menu_time)
        portrait = pygame.transform.scale(frame.image, (216, 216))
        self.surface.blit(portrait, (center[0]-108, center[1]-122))
        self.ui.text(self.surface, "Nove círculos. Seu melhor tempo.", 797, 521, "sub", PAPER, center=True)
        self.ui.text(self.surface, "Uma corrida do Limbo ao amanhecer.", 797, 556, "small", MUTED, center=True)
        self.ui.text(self.surface, "W / S  escolher   ·   ENTER  confirmar   ·   F11  tela cheia", 77, 604, "small", MUTED)
        if self.store.error:
            self.ui.text(self.surface, "Salvamento indisponível nesta pasta.", 1070, 621, "tiny", GOLD, right=True)

    @property
    def pause_sound_rect(self):
        return pygame.Rect(WIDTH-210,24,184,43)

    def draw_pause_sound(self):
        rect=self.pause_sound_rect
        self.ui.panel(self.surface,rect,250)
        if self.pause_sound_hover:
            pygame.draw.rect(self.surface,VIOLET,rect,1,border_radius=10)
        x,y=rect.x+17,rect.centery
        color=GOLD if self.audio.muted else PAPER
        pygame.draw.polygon(self.surface,color,((x,y-5),(x+5,y-5),(x+12,y-11),(x+12,y+11),(x+5,y+5),(x,y+5)),2)
        if self.audio.muted:
            pygame.draw.line(self.surface,color,(x+17,y-6),(x+27,y+6),2)
            pygame.draw.line(self.surface,color,(x+17,y+6),(x+27,y-6),2)
        else:
            pygame.draw.arc(self.surface,color,(x+9,y-12,20,24),-1.0,1.0,2)
        self.ui.text(self.surface,'Som: mudo' if self.audio.muted else 'Som: ligado',rect.x+54,rect.y+5,'small',color)
        self.ui.text(self.surface,'F3',rect.x+54,rect.y+25,'tiny',MUTED)

    def draw_controls(self):
        self.ui.veil(self.surface, 225)
        self.ui.text(self.surface, "COMO JOGAR", 550, 53, "heading", center=True)
        self.ui.text(self.surface, "Movimento preciso. Uma saída sempre adiante.", 550, 104, "small", MUTED, center=True)
        rows = (
            ("W A S D", "A / D caminham; W / S orientam o dash e a escalada"),
            ("ESPAÇO", "Pular; segure para alcançar mais altura"),
            ("K  + direção (WASD)", "Dash em oito direções; recarrega ao tocar o chão"),
            ("L  + W / S", "Agarrar e escalar; a barra indica o fôlego"),
            ("S no ar / K + ESPAÇO", "Queda rápida / dash no chão seguido de salto com impulso"),
            ("R / ESC / F11", "Retornar / pausa / tela cheia"),
            ("F3", "Ligar ou desligar som"),
        )
        for i, (left, right) in enumerate(rows):
            y = 165+i*46
            self.ui.text(self.surface, left, 110, y, "small", GOLD)
            self.ui.text(self.surface, right, 400, y, "small")
        self.ui.paragraph(self.surface, "Complete os nove círculos no menor tempo. As fogueiras guardam o retorno; as fendas levam adiante. Pausas não contam. No fim, registrar nome e tempo é opcional.",
                          110, 507, 880, "small", MUTED, 5)
        self.ui.text(self.surface, "ENTER / ESC  voltar", 550, 601, "small", MUTED, center=True)

    def can_register(self):
        return (self.run_id is not None and self.run_chapters == set(range(9))
                and self.progress['completed'] and self.final_ms is not None and not self.result_saved)

    def open_ranking(self):
        self.rank_rows = self.ranking.entries()
        self.rank_page = 0
        self.change_state('ranking')

    def register_result(self):
        if not self.can_register():
            self.result_error = 'Somente uma corrida completa pode entrar no ranking.'
            return
        if not self.runner_name.strip():
            self.result_error = 'Digite seu nome para registrar o tempo.'
            return
        if not self.ranking.add(self.runner_name, self.final_ms, self.progress['deaths'], self.run_id):
            self.result_error = 'Não foi possível salvar. Seu resultado continua aqui; tente novamente.'
            return
        self.result_saved = True
        self.open_ranking()
        position = next(i for i,r in enumerate(self.rank_rows) if r['id']==self.run_id)
        self.rank_page = position//8

    def draw_race_screen(self):
        self.draw_dawn()
        self.ui.veil(self.surface, 215)
        if self.state == 'ranking':
            self.ui.text(self.surface, 'RANKING LOCAL', 550, 55, 'heading', center=True)
            self.ui.text(self.surface, 'Percurso v2 · menor tempo vence · pausas não contam', 550, 110, 'small', MUTED, center=True)
            self.ui.text(self.surface, '#', 150, 160, 'small', GOLD)
            self.ui.text(self.surface, 'JOGADOR', 220, 160, 'small', GOLD)
            self.ui.text(self.surface, 'TEMPO', 765, 160, 'small', GOLD, right=True)
            self.ui.text(self.surface, 'QUEDAS', 945, 160, 'small', GOLD, right=True)
            for i,r in enumerate(self.rank_rows[self.rank_page*8:(self.rank_page+1)*8]):
                y=198+i*36
                color=GOLD if r['id']==self.run_id else PAPER
                self.ui.text(self.surface,str(self.rank_page*8+i+1),150,y,'body',color)
                self.ui.text(self.surface,r['name'],220,y,'body',color)
                self.ui.text(self.surface,duration_ms(r['milliseconds']),765,y,'body',color,right=True)
                self.ui.text(self.surface,str(r['deaths']),945,y,'body',MUTED,right=True)
            if not self.rank_rows:
                label='Ranking indisponível. O arquivo foi preservado.' if self.ranking.error else 'Ainda não há tempos. Complete uma corrida para inaugurar a tabela.'
                self.ui.text(self.surface,label,550,300,'body',MUTED,center=True)
            pages=max(1,(len(self.rank_rows)+7)//8)
            self.ui.text(self.surface,f'{self.rank_page+1} / {pages}',550,493,'small',MUTED,center=True)
            self.ui.menu(self.surface,self.menu_options(),self.selected,375,523,350,36)
        else:
            self.ui.text(self.surface,'CORRIDA CONCLUÍDA',550,100,'heading',center=True)
            self.ui.text(self.surface,duration_ms(self.final_ms or 0),550,165,'title',GOLD,center=True)
            self.ui.text(self.surface,f"9 círculos · {self.progress['deaths']} quedas",550,245,'body',MUTED,center=True)
            if self.state == 'name':
                self.ui.text(self.surface,'Seu nome (até 18 caracteres)',320,292,'small',MUTED)
                box=pygame.Rect(320,320,460,55)
                self.ui.panel(self.surface,box)
                self.ui.text(self.surface,self.runner_name+('|' if int(self.menu_time*2)%2==0 else ''),335,331,'sub')
                if self.result_error:
                    self.ui.paragraph(self.surface,self.result_error,240,390,620,'small',GOLD)
                self.ui.menu(self.surface,self.menu_options(),self.selected,375,470,350,48)
                self.ui.text(self.surface,'ENTER confirmar · TAB escolher · ESC voltar',550,600,'small',MUTED,center=True)
            else:
                label='Quer guardar seu nome e tempo neste computador?' if self.can_register() else 'Treino concluído. Comece por Jogar para disputar o ranking.'
                self.ui.text(self.surface,label,550,335,'body',center=True)
                self.ui.menu(self.surface,self.menu_options(),self.selected,345,420,410,55)

    def draw_dawn(self):
        """Epílogo: o primeiro horizonte sem as silhuetas do Inferno."""
        for y in range(HEIGHT):
            amount = y/HEIGHT
            top, bottom = (39, 35, 69), (198, 143, 127)
            color = tuple(round(a+(b-a)*amount) for a, b in zip(top, bottom))
            pygame.draw.line(self.surface, color, (0, y), (WIDTH, y))
        sun = pygame.Surface((420, 420), pygame.SRCALPHA)
        for r in range(205, 0, -4):
            pygame.draw.circle(sun, (255, 221, 165, round(35*(1-r/210))), (210, 210), r)
        self.surface.blit(sun, (670, 166))
        pygame.draw.circle(self.surface, (238, 195, 150), (880, 376), 51)
        pygame.draw.polygon(self.surface, (58, 47, 75), ((0, 460), (210, 390), (410, 475),
                              (630, 439), (880, 470), (1100, 403), (1100, 650), (0, 650)))
        pygame.draw.polygon(self.surface, (30, 27, 47), ((0, 549), (250, 508), (415, 548),
                              (710, 536), (1100, 561), (1100, 650), (0, 650)))
        frame = self.animations.get("idle", 1, self.menu_time)
        frame.draw(self.surface, (960, 558))

    def draw(self):
        self.ui.buttons = []
        if self.state == "descending":
            self.draw_descent()
        elif self.state == "menu":
            self.draw_menu()
        elif self.state in ('result', 'name', 'ranking'):
            self.draw_race_screen()
        else:
            self.draw_world()
            if self.state == "playing":
                self.ui.hud(self.surface, self.world, self.player, self.progress,
                            self.toast, self.toast_time, self.death_timer)
            elif self.state == "prologue":
                self.ui.story(self.surface, "PRÓLOGO · UMA FICÇÃO INSPIRADA EM ALICE KYTELER", "O que o fogo não levou", PROLOGUE)
            elif self.state == "intro":
                c = self.world.chapter
                self.ui.story(self.surface, f"CÍRCULO {c.number} DE 9 · {c.name.upper()}", c.subtitle,
                              (*c.story, c.hint), color=c.accent)
            elif self.state == "clear":
                c = CHAPTERS[self.previous_chapter]
                self.ui.story(self.surface, f"{c.name.upper()} · VÍNCULO ROMPIDO", "Mais perto do amanhecer",
                              (c.release, f"Adiante: {CHAPTERS[self.previous_chapter+1].name}."),
                              "ENTER / ESPAÇO  ver o caminho aberto", c.accent)
            elif self.state == "ending":
                self.draw_dawn()
                self.ui.story(self.surface, "NENHUMA SENTENÇA É ETERNA", "O amanhecer de Alice", ENDING, alpha=160)
            elif self.state == "credits":
                self.draw_dawn()
                self.ui.veil(self.surface, 175)
                self.ui.ornament(self.surface, 550, 99)
                self.ui.text(self.surface, "ALICE KYTELER", 550, 143, "heading", center=True)
                self.ui.text(self.surface, "LIVRE", 550, 207, "title", GOLD, center=True)
                self.ui.text(self.surface, "Os nove círculos ficaram para trás.", 550, 306, "sub", center=True)
                self.ui.text(self.surface, f"{self.ui.duration(self.progress['seconds'])} de jornada   ·   {self.progress['deaths']} quedas, sempre um retorno",
                             550, 351, "body", MUTED, center=True)
                self.ui.text(self.surface, "Uma história ficcional inspirada no nome de Alice Kyteler", 550, 430, "small", MUTED, center=True)
                self.ui.text(self.surface, "e nos nove círculos do Inferno de Dante.", 550, 456, "small", MUTED, center=True)
                self.ui.text(self.surface, "Obrigada por conduzi-la até aqui.", 550, 514, "sub", VIOLET, center=True)
                self.ui.text(self.surface, "ENTER  início · Os círculos estão disponíveis para revisitar", 550, 591, "small", MUTED, center=True)
            elif self.state == "controls":
                self.draw_controls()
            elif self.state == "paused":
                self.ui.veil(self.surface, 200)
                self.draw_pause_sound()
                self.ui.text(self.surface, "Um instante entre as cinzas", 550, 151, "heading", center=True)
                self.ui.text(self.surface, "Cronômetro pausado. Reiniciar zera a corrida inteira.", 550, 214, "small", MUTED, center=True)
                self.ui.menu(self.surface, self.menu_options(), self.selected, 360, 286, 380, 51)
            elif self.state == "confirm":
                self.ui.veil(self.surface, 220)
                self.ui.text(self.surface, "Começar uma nova jornada?", 550, 188, "heading", center=True)
                self.ui.text(self.surface, "Isso substitui seu progresso atual.", 550, 253, "body", MUTED, center=True)
                self.ui.menu(self.surface, self.menu_options(), self.selected, 345, 340, 410, 55)
        if self.state in ("playing", "intro") and self.state_time < .45:
            self.ui.veil(self.surface, round(210*(1-self.state_time/.45)))
        size = self.window.get_size()
        ratio = min(size[0]/WIDTH, size[1]/HEIGHT)
        scaled = (max(1, round(WIDTH*ratio)), max(1, round(HEIGHT*ratio)))
        self.viewport = pygame.Rect((size[0]-scaled[0])//2, (size[1]-scaled[1])//2, *scaled)
        self.window.fill(INK)
        self.window.blit(pygame.transform.scale(self.surface, scaled), self.viewport)
        pygame.display.flip()

    def run(self, frames=None, screenshot=None):
        clock, count = pygame.time.Clock(), 0
        try:
            while self.running and (frames is None or count < frames):
                dt = min(.08, clock.tick(60)/1000)
                self.events()
                self.update(dt)
                self.draw()
                count += 1
            if screenshot:
                pygame.image.save(self.surface, str(screenshot))
        finally:
            self.save()
            pygame.quit()


def main(argv=None):
    parser = argparse.ArgumentParser(description="Alice Kyteler — Nove Círculos")
    parser.add_argument("--headless", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--frames", type=int, help=argparse.SUPPRESS)
    parser.add_argument("--screenshot", type=Path, help=argparse.SUPPRESS)
    parser.add_argument("--chapter", type=int, choices=range(1, 10), help=argparse.SUPPRESS)
    parser.add_argument("--save", type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args(argv)
    if args.headless:
        os.environ["SDL_VIDEODRIVER"] = "dummy"
        os.environ["SDL_AUDIODRIVER"] = "dummy"
    game = Game(args.save, args.headless)
    if args.chapter:
        game.load_chapter(args.chapter-1, intro=False)
        game.state_time = 1
    game.run(args.frames, args.screenshot)
