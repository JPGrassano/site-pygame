"""Regressões de dash único, apoios da escalada e feedback audiovisual."""
import os
from array import array
from pathlib import Path
import uuid
import unittest
from unittest.mock import patch

os.environ['SDL_VIDEODRIVER'] = 'dummy'
os.environ['SDL_AUDIODRIVER'] = 'dummy'
import pygame
from audio import PROFILES, SoundDesign, synthesize
from efeitos import Particles
from motor import Game
from personagem import Animations, Controls, Player, STEP


class FeedbackTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        pygame.display.init()
        pygame.display.set_mode((1100, 650))
        cls.animations = Animations()

    def test_upward_dash_from_floor_cannot_repeat_until_landing(self):
        floor = pygame.Rect(0, 500, 1100, 150)
        player = Player((300, 500))
        player.update(STEP, Controls(), floor)
        starts = 0
        for tick in range(45):
            player.update(STEP, Controls(y=-1, dash=tick in (0, 30, 40)), floor)
            starts += sum(name == 'dash' for name, _ in player.events)
        self.assertEqual(starts, 1)
        self.assertFalse(player.grounded)
        self.assertEqual(player.dashes, 0)
        for _ in range(200):
            player.update(STEP, Controls(), floor)
            if player.grounded:
                break
        self.assertTrue(player.grounded)
        self.assertEqual(player.dashes, 1)
        player.update(STEP, Controls(y=-1, dash=True), floor)
        self.assertIn(('dash', 1), player.events)

    def test_wall_and_ceiling_impacts_never_refill(self):
        for direction, obstacle, spawn in (
                ((1, 0), pygame.Rect(400, 0, 50, 700), (360, 300)),
                ((0, -1), pygame.Rect(0, 180, 1100, 30), (300, 270))):
            player = Player(spawn, auto_respawn=False)
            for tick in range(36):
                player.update(STEP, Controls(x=direction[0], y=direction[1],
                                             dash=tick in (0, 30)), [obstacle])
            self.assertEqual(player.dashes, 0)
            self.assertEqual(player.dash_time, 0)

    def test_removed_assist_and_seals_do_not_grant_air_dash(self):
        folder = Path(__file__).parent / '_temporario'
        folder.mkdir(exist_ok=True)
        save = folder / (uuid.uuid4().hex+'.json')
        try:
            game = Game(save, headless=True)
            game.load_chapter(0, intro=False)
            game.player.rect.midbottom = (300, 240)
            game.player.pos.update(game.player.rect.topleft)
            game.simulate(STEP, Controls(y=-1, dash=True))
            self.assertGreater(game.shake, 0)
            self.assertTrue(game.effects.ghosts)
            self.assertTrue(game.effects.rings)
            self.assertEqual(game.player.dashes, 0)
            pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_F2))
            game.events()
            self.assertNotIn("assist", game.progress)
            self.assertEqual(game.player.dashes, 0)
            with patch.object(game.world, 'break_seals', return_value=[(300, 200)]):
                game.simulate(STEP, Controls())
            self.assertEqual(game.player.dashes, 0)
            game.load_chapter(0, intro=False)
            self.assertEqual(game.player.max_dashes, 1)
        finally:
            save.unlink(missing_ok=True)

    def test_four_contacts_share_wall_plane_on_both_sides(self):
        # Pele e couro das quatro extremidades precisam tocar a face da parede.
        for facing in (-1, 1):
            for frame in self.animations.frames['climb', facing]:
                contact_x = 60 if facing == 1 else 11
                column = [frame.image.get_at((contact_x, y)).a > 0 for y in range(20, 70)]
                groups = sum(on and (i == 0 or not column[i-1]) for i, on in enumerate(column))
                self.assertGreaterEqual(groups, 4)
                self.assertEqual(frame.pivot[0], 50 if facing == 1 else 22)

    def test_climbing_stays_against_both_walls_and_faces_them(self):
        for facing in (-1, 1):
            wall = pygame.Rect(500, 0, 60, 650)
            player = Player((489 if facing == 1 else 571, 450))
            player.facing = -facing
            player.vel.x = -facing*100
            for _ in range(60):
                player.update(STEP, Controls(y=-1, grab=True), [wall])
                self.assertEqual(player.state, 'climb')
                self.assertEqual(player.facing, facing)
                self.assertEqual(player.rect.right if facing == 1 else player.rect.left,
                                 wall.left if facing == 1 else wall.right)
            player.update(STEP, Controls(jump=True, jump_held=True, grab=True), [wall])
            self.assertEqual(player.state, 'jump')
            self.assertLess(player.vel.x*facing, 0)

    def test_effects_expire_and_trail_is_bounded(self):
        effects = Particles()
        player = Player((200, 300))
        for _ in range(120):
            effects.dash_trail(player, self.animations, (100, 150, 255))
            effects.pulse(player.rect.center, (100, 150, 255))
            effects.update(STEP)
        self.assertLessEqual(len(effects.ghosts), 8)
        self.assertLessEqual(len(effects.rings), 12)
        effects.update(1)
        self.assertFalse(effects.ghosts)
        self.assertFalse(effects.rings)


class AudioTests(unittest.TestCase):
    def tearDown(self):
        pygame.mixer.quit()

    def test_effects_have_fades_headroom_and_varied_footsteps(self):
        for name in PROFILES:
            samples = array('h', synthesize(name))
            self.assertGreater(max(abs(s) for s in samples), 100)
            self.assertLess(max(abs(s) for s in samples), 30000)
            self.assertEqual(samples[0], 0)
            self.assertEqual(samples[-1], 0)
        self.assertNotEqual(synthesize('step', 0), synthesize('step', 1))

    def test_dummy_device_can_play_mute_and_resume(self):
        audio = SoundDesign()
        self.assertTrue(audio.available, audio.error)
        audio.play('dash')
        self.assertTrue(pygame.mixer.get_busy())
        self.assertTrue(audio.toggle())
        self.assertFalse(pygame.mixer.get_busy())
        audio.update(.3)
        audio.toggle()
        audio.play('land')
        self.assertTrue(pygame.mixer.get_busy())

    def test_no_audio_device_is_nonfatal_and_headless_does_not_open_it(self):
        with patch('pygame.mixer.init', side_effect=pygame.error('sem dispositivo')):
            audio = SoundDesign()
            self.assertFalse(audio.available)
            audio.play('dash')
        with patch('pygame.mixer.init') as init:
            SoundDesign(enabled=False)
            init.assert_not_called()
