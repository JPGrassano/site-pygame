"""Verificações de colisão e câmera para o mapa do Limbo."""
import os
import unittest

os.environ['SDL_VIDEODRIVER'] = 'dummy'
import personagem
from mapa import World
from campanha import WORLD_WIDTH, WORLD_HEIGHT, SPAWN


class MapTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        personagem.pygame.display.init()
        personagem.pygame.font.init()
        personagem.pygame.display.set_mode((personagem.WIDTH, personagem.HEIGHT))
        cls.map = World(0)

    def setUp(self):
        self.player = personagem.Player(SPAWN, (WORLD_WIDTH, WORLD_HEIGHT))
        self.map.camera_x = 0
        self.platforms = self.map.platforms

    def wall_fixture(self):
        """A mesma parede nos dois lados, independente do desenho das fases."""
        self.platforms = [personagem.pygame.Rect(0,570,1100,250),
                          personagem.pygame.Rect(360,490,100,80)]

    def place(self, feet):
        self.player.rect.midbottom = feet
        self.player.pos.update(self.player.rect.topleft)

    def advance(self, seconds, controls=None):
        controls = controls or personagem.Controls()
        for _ in range(round(seconds/personagem.STEP)):
            self.player.update(personagem.STEP, controls, self.platforms)
            controls.jump = controls.dash = False

    def test_spawn_is_supported_by_actual_map(self):
        self.advance(1)
        self.assertEqual(self.player.rect.midbottom, SPAWN)
        self.assertTrue(self.player.grounded)

    def test_dash_collides_with_platform_after_first_floor_segment(self):
        left,right,bottom,top = self.map.layout.shafts[0]
        self.place((right-70, bottom))
        self.advance(.2, personagem.Controls(x=1, dash=True))
        self.assertEqual(self.player.rect.right, right)

    def test_landing_on_an_upper_platform_in_a_list(self):
        x,y = self.map.checkpoints[1]
        self.place((x, y-50))
        self.player.vel.y = 150
        self.advance(.4)
        self.assertEqual(self.player.rect.bottom, y)
        self.assertTrue(self.player.grounded)

    def test_wall_climb_works_on_middle_pillar(self):
        left,right,bottom,top = self.map.layout.shafts[0]
        self.place((right-11, bottom-40))
        self.advance(.2, personagem.Controls(y=-1, grab=True))
        self.assertLess(self.player.rect.bottom, bottom-40)
        self.assertEqual(self.player.state, 'climb')

    def test_climb_can_start_from_ground_on_both_sides(self):
        self.wall_fixture()
        for feet, facing in (((349, 570), 1), ((471, 570), -1)):
            with self.subTest(side=facing):
                self.player.reset()
                self.place(feet)
                self.advance(.05)
                self.assertTrue(self.player.grounded)
                self.advance(.2, personagem.Controls(y=-1, grab=True))
                self.assertLess(self.player.rect.bottom, 570)
                self.assertEqual(self.player.state, 'climb')
                self.assertEqual(self.player.facing, facing)
                self.assertEqual(self.player.vel.y, -105)

    def test_walking_into_wall_can_transition_directly_into_climb(self):
        self.wall_fixture()
        self.place((320, 570))
        self.advance(.4, personagem.Controls(x=1, y=-1, grab=True))
        self.assertLess(self.player.rect.bottom, 570)
        self.assertEqual(self.player.state, 'climb')

    def test_grab_alone_does_not_lift_player_off_floor(self):
        self.wall_fixture()
        self.place((349, 570))
        self.advance(.3, personagem.Controls(grab=True))
        self.assertEqual(self.player.rect.bottom, 570)
        self.assertTrue(self.player.grounded)
        self.assertEqual(self.player.state, 'idle')

    def test_releasing_grab_returns_to_falling(self):
        self.wall_fixture()
        self.place((349, 570))
        self.advance(.15, personagem.Controls(y=-1, grab=True))
        self.assertEqual(self.player.state, 'climb')
        self.advance(.12)
        self.assertGreater(self.player.vel.y, 0)
        self.assertEqual(self.player.state, 'jump')

    def test_wall_jump_while_holding_climb_right_after_leaving_ground(self):
        self.wall_fixture()
        for feet, wall in (((349, 570), 1), ((471, 570), -1)):
            with self.subTest(wall=wall):
                self.player.reset()
                self.place(feet)
                self.advance(.04, personagem.Controls(y=-1, grab=True))
                self.assertEqual(self.player.state, 'climb')
                self.assertGreater(self.player.coyote, 0)
                self.advance(personagem.STEP, personagem.Controls(
                    x=wall, y=-1, grab=True, jump=True, jump_held=True))
                self.assertLess(self.player.vel.x*wall, -200)
                self.assertLess(self.player.vel.y, -400)
                self.assertEqual(self.player.state, 'jump')

    def test_holding_climb_and_direction_does_not_cancel_wall_jump(self):
        self.wall_fixture()
        for feet, wall in (((349, 570), 1), ((471, 570), -1)):
            with self.subTest(wall=wall):
                self.player.reset()
                self.place(feet)
                self.advance(.2, personagem.Controls(y=-1, grab=True))
                before = self.player.rect.centerx
                self.advance(.1, personagem.Controls(
                    x=wall, y=-1, grab=True, jump=True, jump_held=True))
                self.assertLess((self.player.rect.centerx-before)*wall, -20)
                self.assertEqual(self.player.state, 'jump')
                self.assertLess(self.player.vel.y, 0)

    def test_wall_jump_lock_blocks_immediate_regrab(self):
        self.wall_fixture()
        self.place((349, 550))
        self.player.wall_lock = .1
        self.player.vel.update(-285, -400)
        self.advance(personagem.STEP, personagem.Controls(y=-1, grab=True, jump_held=True))
        self.assertEqual(self.player.state, 'jump')
        self.assertLess(self.player.vel.y, -300)

    def test_player_can_move_beyond_window_width(self):
        self.place((2250, 490))
        self.advance(.25, personagem.Controls(x=1))
        self.assertGreater(self.player.rect.centerx, 2250)

    def test_camera_stays_inside_world(self):
        self.place((WORLD_WIDTH-20, 570))
        for _ in range(240):
            self.map.update(personagem.STEP, self.player)
        self.assertGreater(self.map.camera_x, 0)
        self.assertLessEqual(self.map.camera_x, WORLD_WIDTH-personagem.WIDTH)
        self.player.reset()
        for _ in range(240):
            self.map.update(personagem.STEP, self.player)
        self.assertLess(self.map.camera_x, 1)

    def test_falling_outside_world_returns_to_start(self):
        self.place((1450, WORLD_HEIGHT+200))
        self.advance(personagem.STEP)
        self.assertEqual(self.player.rect.midbottom, SPAWN)


if __name__ == '__main__':
    unittest.main(verbosity=2)
