"""As varandas das rajadas: alternância entre travessia, paredes e plataformas móveis."""
from .modelo import Layout, floor, ledge

LAYOUT = Layout(
    name='As varandas das rajadas',
    platforms=(
        floor(0,570,300),
        ledge(740,410,120),
        ledge(1050,320,110),
        floor(1390,570,300),
        (1500,0,70,480),
        floor(1690,250,110),
        floor(1900,390,180),
        ledge(2130,310,120),
        floor(2260,490,140),
    ),
    checkpoints=((150, 570), (800, 410), (1990, 390)),
    seal_feet=((2190, 310),), exit=(2330, 490),
    shafts=((1570, 1690, 570, 250),),
    movers=((410, 500, 120, 24, 190, -70, 4.2, 0),),
    hazards=(('orb', 1020, 285, 140, 17, 0.6),),
    illusion_x=(),
)
