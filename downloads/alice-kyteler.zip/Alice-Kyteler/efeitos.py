"""Partículas visuais de dash, retorno e selos. Não participam das colisões."""
import math
import random

import pygame

MAGIC = (178, 88, 255)
MAGIC_LIGHT = (237, 195, 255)


class Particles:
    def __init__(self):
        self.items = []
        self.random = random.Random(214)
        self.ghosts = []
        self.rings = []
        self.trail_timer = 0
        self.motes = []
        self.ribbon = []
        self.layer = None
        self.spark_glow = pygame.Surface((24, 24), pygame.SRCALPHA)
        for radius in range(11, 0, -1):
            pygame.draw.circle(self.spark_glow, (*MAGIC, round(55*(1-radius/12)**2)), (12, 12), radius)

    def pulse(self, point, color, radius=35):
        self.rings.append([tuple(point), color, .24, radius])
        self.rings = self.rings[-12:]

    def dash_trail(self, player, animations, color):
        if self.trail_timer > 0:
            return
        self.trail_timer = .022
        frame = animations.get('dash', player.dash_facing, player.dash_elapsed,
                               direction=player.dash_direction)
        ghost = frame.image.copy()
        ghost.fill((190, 105, 255, 255), special_flags=pygame.BLEND_RGBA_MULT)
        ghost.fill((95, 35, 145, 0), special_flags=pygame.BLEND_RGBA_ADD)
        self.ghosts.append([ghost, (player.rect.centerx-frame.pivot[0],
                                    player.rect.bottom-frame.pivot[1]), .28])
        self.ghosts = self.ghosts[-8:]
        point = (player.rect.centerx, player.rect.bottom-34)
        self.ribbon.append([point, .28])
        self.ribbon = self.ribbon[-12:]
        self.magic_burst(point, 2, player.dash_direction, 65)

    def magic_burst(self, point, count=10, direction=None, speed=100):
        """Faíscas curvas e estrelas, com fluxo contrário ao impulso do dash."""
        heading = math.atan2(-direction[1], -direction[0]) if direction else None
        for _ in range(count):
            angle = self.random.uniform(-math.pi, math.pi) if heading is None else heading+self.random.uniform(-.65, .65)
            velocity = self.random.uniform(.35, 1)*speed
            life = self.random.uniform(.24, .48)
            self.motes.append([float(point[0]), float(point[1]), math.cos(angle)*velocity,
                               math.sin(angle)*velocity, life, life, self.random.random()*math.tau,
                               self.random.choice((-1, 1)), self.random.choice((2, 2, 3))])
        self.motes = self.motes[-120:]

    def dust(self, point, color, strength=1):
        for _ in range(round(3+5*strength)):
            self.items.append([float(point[0]), float(point[1]-2),
                               self.random.uniform(-100, 100)*strength,
                               self.random.uniform(-90, -20)*strength,
                               self.random.uniform(.16, .35), color])
        self.items = self.items[-350:]

    def burst(self, point, color, count=25, speed=140):
        self.magic_burst(point, min(18, max(4, count//2)), speed=speed*.65)

    def update(self, dt):
        self.trail_timer = max(0, self.trail_timer-dt)
        for ghost in self.ghosts:
            ghost[2] -= dt
        self.ghosts = [ghost for ghost in self.ghosts if ghost[2] > 0]
        for point in self.ribbon:
            point[1] -= dt
        self.ribbon = [point for point in self.ribbon if point[1] > 0]
        for mote in self.motes:
            mote[4] -= dt
            angle = mote[7]*dt*4.5
            vx, vy = mote[2], mote[3]
            drag = math.exp(-2*dt)
            mote[2] = (vx*math.cos(angle)-vy*math.sin(angle))*drag
            mote[3] = (vx*math.sin(angle)+vy*math.cos(angle))*drag
            mote[0] += mote[2]*dt
            mote[1] += mote[3]*dt-8*dt
        self.motes = [mote for mote in self.motes if mote[4] > 0]
        for ring in self.rings:
            ring[2] -= dt
        self.rings = [ring for ring in self.rings if ring[2] > 0]
        for item in self.items:
            item[0] += item[2]*dt
            item[1] += item[3]*dt
            item[3] += 60*dt
            item[4] -= dt
        self.items = [p for p in self.items if p[4] > 0]

    def draw(self, surface, offset):
        if self.layer is None or self.layer.get_size() != surface.get_size():
            self.layer = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        self.layer.fill((0, 0, 0, 0))
        for ((ax, ay), alife), ((bx, by), blife) in zip(self.ribbon, self.ribbon[1:]):
            fade = min(alife, blife)/.28
            a, b = (round(ax-offset), round(ay)), (round(bx-offset), round(by))
            pygame.draw.line(self.layer, (*MAGIC, round(45*fade)), a, b, 15)
            pygame.draw.line(self.layer, (*MAGIC, round(135*fade)), a, b, 6)
            pygame.draw.line(self.layer, (*MAGIC_LIGHT, round(190*fade)), a, b, 2)
        surface.blit(self.layer, (0, 0))
        for ghost, (x, y), life in self.ghosts:
            ghost.set_alpha(round(180*(life/.28)**1.3))
            surface.blit(ghost, (round(x-offset), round(y)))
        for (x, y), color, life, radius in self.rings:
            layer = pygame.Surface((radius*2+6, radius*2+6), pygame.SRCALPHA)
            pygame.draw.circle(layer, (*color, round(155*life/.24)),
                               (radius+3, radius+3), max(2, round(radius*(1-life/.24))), 2)
            surface.blit(layer, (round(x-offset-radius-3), round(y-radius-3)))
        for x, y, vx, vy, life, color in self.items:
            shade = tuple(round(c*min(1, life/.2)*.65) for c in color)
            pygame.draw.line(surface, shade, (round(x-offset), round(y)),
                             (round(x-offset+vx*.016), round(y)), 1)
        self.layer.fill((0, 0, 0, 0))
        for x, y, vx, vy, life, duration, phase, curl, size in self.motes:
            fade = (life/duration)**.7
            sx, sy = round(x-offset), round(y)
            self.spark_glow.set_alpha(round(220*fade))
            self.layer.blit(self.spark_glow, (sx-12, sy-12))
            color = (*MAGIC_LIGHT, round(220*fade))
            reach = max(1, round(size*(.75+.25*math.sin(life*30+phase))))
            pygame.draw.polygon(self.layer, color,
                                ((sx-reach, sy), (sx, sy-reach-1), (sx+reach, sy), (sx, sy+reach+1)))
        surface.blit(self.layer, (0, 0))
