"""O mapa respeita bloqueios, preserva a partida e indica a próxima etapa."""
import os
import unittest
from pathlib import Path

os.environ['SDL_VIDEODRIVER'] = 'dummy'
from motor import Game
from fases import LAYOUTS
from fases.modelo import WORLD_WIDTH
from personagem import Controls
from progresso import fresh_progress
from test_campanha import TestDirectory


@unittest.skip("Mapa da jornada removido a pedido do jogador")
class JourneyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.folder = TestDirectory()
        cls.game = Game(Path(cls.folder.name)/'save.json', headless=True)

    @classmethod
    def tearDownClass(cls):
        cls.folder.cleanup()

    def setUp(self):
        self.game.progress = fresh_progress()
        self.game.load_chapter(3, checkpoint=1, intro=False)

    def test_map_freezes_and_resumes_exact_live_position(self):
        game = self.game
        game.simulate(.05, Controls(x=1))
        position, velocity, clock = game.player.rect.copy(), game.player.vel.copy(), game.world.time
        game.open_map('playing')
        game.update(1)
        self.assertEqual(game.world.time, clock)
        game.activate()
        self.assertEqual(game.state, 'playing')
        self.assertEqual(game.player.rect, position)
        self.assertEqual(game.player.vel, velocity)

    def test_locked_selection_does_not_change_progress(self):
        game = self.game
        before = dict(game.progress)
        game.open_map()
        game.selected = 8
        game.activate()
        self.assertEqual(game.state, 'chapters')
        self.assertEqual(game.progress, before)

    def test_menu_map_resumes_saved_checkpoint_and_seals(self):
        game = self.game
        game.load_chapter(8, checkpoint=2, seals=(0,1), intro=False)
        game.open_map()
        game.activate()
        self.assertEqual(game.player.rect.midbottom, LAYOUTS[8].checkpoints[2])
        self.assertEqual(game.world.broken, {0,1})

    def test_finishing_opens_map_on_next_unlocked_circle(self):
        game = self.game
        game.complete_chapter()
        game.activate()
        self.assertEqual(game.state, 'chapters')
        self.assertEqual(game.selected, 4)
        self.assertEqual(game.progress['unlocked'], 4)

    def test_map_mouse_targets_and_render_for_every_selection(self):
        game = self.game
        game.open_map()
        for index in range(9):
            game.selected = index
            game.draw()
            self.assertEqual(len(game.ui.buttons), 10)
            for rect, target in game.ui.buttons:
                self.assertTrue(game.surface.get_rect().contains(rect))
                self.assertIn(target, range(9))

    def test_compact_layouts_have_visible_supported_floor_hazards(self):
        self.assertLessEqual(WORLD_WIDTH, 2400)
        for layout in LAYOUTS:
            self.assertLessEqual(len(layout.platforms), 12)
            for x,y,w,h in layout.platforms:
                self.assertGreaterEqual(x, 0)
                self.assertLessEqual(x+w, WORLD_WIDTH)
                self.assertTrue(y == 0 or y >= 170)
            for kind,x,y,w,h,phase in layout.hazards:
                if kind in ('fire','frost','vapor','acid'):
                    self.assertLess(y+h, 610)
                    self.assertTrue(any(py == y+h and px <= x and px+pw >= x+w
                                        for px,py,pw,ph in layout.platforms), (layout.name,kind))

    def test_checkpoint_remains_safe_through_complete_hazard_cycle(self):
        from mapa import World
        from personagem import Player
        for index in range(9):
            world = World(index)
            for checkpoint in world.checkpoints:
                rect = Player(checkpoint).rect
                for step in range(240):
                    world.time = step/10
                    self.assertFalse(world.deadly(rect), (index,checkpoint,world.time))
