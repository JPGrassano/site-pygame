"""Áudios fornecidos pelo jogador e foley sutil gerado na abertura.

Transientes curtos, ruído filtrado, corpo tonal e caudas com fade evitam cliques.
Variações determinísticas nos passos evitam repetição mecânica. Nunca sintetiza
durante o gameplay. Falha de dispositivo desativa áudio sem interromper o jogo.
"""
from array import array
import math
import random
from pathlib import Path

import pygame


RATE = 44100
SOUND_ROOT = Path(__file__).resolve().parent / 'sons'
CHAPTER_MUSIC = {0:'Saxa_Silentia.mp3', 1:'The_Second_Circle.mp3',
                 2:'Beneath_The_Icy_Mire.mp3', 3:'Vault_of_Eternal_Labor.mp3'}

RECORDINGS = {'dash': 'dash.mp3', 'checkpoint': 'checkpoint.mp3', 'step': 'step.mp3', 'land': 'land.mp3', 'jump': 'jump.mp3', 'wall_jump': 'jump.mp3', 'dash_hit': 'land.mp3'}


def locomotion_sound(state, previous_state, clock, previous_clock, distance):
    """Um apoio por ciclo visível, nunca por transporte da plataforma ou parado."""
    if state != previous_state or distance < .05 or state not in ('run', 'climb'):
        return None
    frequency = 11 if state == 'run' else 9
    if int(clock*frequency/6) > int(previous_clock*frequency/6):
        return 'step' if state == 'run' else 'climb'
    return None


# duração, frequência inicial/final, ruído, corpo tonal, ganho
PROFILES = {
    'dash': (.24, 190, 48, .85, .6, .65),
    'dash_hit': (.18, 100, 38, .8, .65, .58),
    'jump': (.23, 155, 85, .9, .04, .30),
    'wall_jump': (.22, 145, 75, .9, .04, .27),
    'land': (.18, 90, 55, .95, .02, .17),
    'step': (.12, 140, 65, .9, 0, .11),
    'climb': (.115, 750, 750, .85, .08, .14),
    'recharge': (.23, 880, 1320, .03, .55, .07),
    'seal': (.48, 620, 190, .45, .55, .48),
    'checkpoint': (.6, 660, 990, .02, .5, .35),
    'death': (.4, 185, 38, .65, .5, .50),
    'respawn': (.38, 330, 880, .15, .45, .30),
    'complete': (.85, 523, 1046, .02, .55, .38),
    'ui': (.07, 740, 980, .02, .45, .18),
}


def synthesize(name, variant=0, rate=RATE, channels=2):
    duration, start, end, noise, tone, gain = PROFILES[name]
    rng = random.Random(name+str(variant))
    pitch = (1, .93, 1.07)[variant % 3]
    samples = array('h')
    phase, filtered, low = 0.0, 0.0, 0.0
    count = round(duration*rate)
    for i in range(count):
        t = i/rate
        p = i/(count-1)
        frequency = (start+(end-start)*p)*pitch
        phase += math.tau*frequency/rate
        raw = rng.uniform(-1, 1)
        cutoff = .06+.30*math.sin(math.pi*p) if name in ('jump', 'wall_jump') else .24
        filtered += cutoff*(raw-filtered)
        low += .035*(raw-low)
        envelope = min(1, t/.004) * (1-p)**1.8
        body = math.sin(phase)*.72 + math.sin(phase*2.01)*.20
        if name in ('step', 'land'):
            # Areia: fricção granular, sem nota afinada ou batida de sola dura.
            grains = .55+.45*math.sin(t*math.tau*73+variant)**2
            envelope = min(1, t/.012)*(1-p)**2.1
            value = ((filtered-low)*1.25+raw*.13)*grains*envelope*gain
        elif name == 'climb':
            # Pedra: arranhado seco e ressonância curta, sem som de passos.
            scrape = (raw-filtered)*(.4+.6*math.sin(t*math.tau*41)**2)
            knock = (math.sin(t*math.tau*810*pitch)+.4*math.sin(t*math.tau*1370))*math.exp(-t*65)
            value = (scrape*.48+knock*.12)*envelope*gain
        elif name in ('jump', 'wall_jump'):
            # Um "woop" de ar: ruído filtrado abre e fecha, sem glissando agudo.
            envelope = math.sin(math.pi*p)**1.3
            value = ((filtered-low)*1.8+body*tone)*envelope*gain
        else:
            if name in ('recharge', 'checkpoint', 'complete', 'seal', 'respawn'):
                body += math.sin(phase*1.5)*.22 + math.sin(phase*3)*.08
            value = (body*tone + filtered*noise*1.7)*envelope*gain
        sample = round(max(-1, min(1, value))*32767)
        samples.extend([sample]*channels)
    return samples.tobytes()


def load_recording(name, rate, channels):
    """Mantém a gravação original; tira só silêncio inicial e suaviza as bordas."""
    source = pygame.mixer.Sound(str(SOUND_ROOT / RECORDINGS[name]))
    samples = array('h', source.get_raw())
    if name == 'step':
        # Uma única pisada da gravação, não a faixa de 50 segundos inteira.
        hop = max(1, round(rate*.02))*channels
        search = samples[:round(rate*2)*channels]
        peak_start = max(range(0, len(search)-hop, hop), key=lambda i: sum(v*v for v in search[i:i+hop]))
        start = max(0, peak_start-round(rate*.035)*channels)
        samples = samples[start:start+round(rate*.20)*channels]
    count = len(samples)//channels
    # A gravação de dash tem uma pequena espera antes do ataque.
    onset = next((i for i in range(count)
                  if max(abs(samples[i*channels+c]) for c in range(channels)) > 650), 0)
    start = max(0, onset-round(.004*rate))
    samples = samples[start*channels:]
    count = len(samples)//channels
    peak = max((abs(s) for s in samples), default=1)
    gain = min(1, 24500/max(1, peak))
    attack, release = max(1, round(rate*.003)), max(1, round(rate*.035))
    for i in range(count):
        envelope = min(1, i/attack, (count-1-i)/release)*gain
        for c in range(channels):
            samples[i*channels+c] = round(samples[i*channels+c]*envelope)
    return pygame.mixer.Sound(buffer=samples.tobytes())


class SoundDesign:
    def __init__(self, enabled=True):
        self.available = False
        self.muted = False
        self.sounds = {}
        self.variant = 0
        self.voice = 0
        self.elapsed = 0.0
        self.last_played = {}
        self.error = ''
        self.recording_errors = []
        self.music_track = None
        self.music_volume = .18
        self.music_ducked = False
        if not enabled:
            return
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(frequency=RATE, size=-16, channels=2, buffer=512)
            rate, size, channels = pygame.mixer.get_init()
            if size != -16:
                self.error = 'O dispositivo precisa de áudio de 16 bits.'
                return
            pygame.mixer.set_num_channels(16)
            for name in PROFILES:
                if name in RECORDINGS:
                    try:
                        self.sounds[name] = [load_recording(name, rate, channels)]
                        continue
                    except (pygame.error, OSError) as error:
                        self.recording_errors.append(str(error))
                self.sounds[name] = [pygame.mixer.Sound(buffer=synthesize(name, variant, rate, channels))
                                     for variant in range(3 if name in ('step', 'climb') else 1)]
            self.available = True
        except pygame.error as error:
            self.error = str(error)

    def update(self, dt):
        self.elapsed += dt

    def toggle(self):
        self.muted = not self.muted
        if self.muted and self.available:
            pygame.mixer.stop()
        if self.available:
            self._music_volume()
        return self.muted

    def _music_volume(self):
        gain = .35 if self.music_ducked else 1.0
        pygame.mixer.music.set_volume(0 if self.muted else self.music_volume * gain)

    def set_music_context(self, chapter, state, return_state='menu'):
        """Trilha em streaming: mantém a posição nas mortes e durante a pausa."""
        if not self.available:
            return
        in_game = state in ('intro', 'playing', 'descending', 'paused')
        in_game |= state == 'controls' and return_state == 'paused'
        track = CHAPTER_MUSIC.get(chapter) if in_game else None
        self.music_ducked = state in ('paused', 'controls')
        if track == self.music_track:
            self._music_volume()
            return
        if track is None:
            pygame.mixer.music.fadeout(700)
            self.music_track = None
            return
        try:
            pygame.mixer.music.load(str(SOUND_ROOT / track))
            self._music_volume()
            pygame.mixer.music.play(loops=-1, fade_ms=1200)
            self.music_track = track
        except (pygame.error, OSError) as error:
            self.recording_errors.append(str(error))
            self.music_track = None

    def play(self, name, strength=1, pan=0):
        if not self.available or self.muted:
            return
        gap = .42 if name == 'step' else .34 if name == 'climb' else .035
        if self.elapsed-self.last_played.get(name, -100) < gap:
            return
        self.last_played[name] = self.elapsed
        choices = self.sounds[name]
        sound = choices[self.variant % len(choices)]
        self.variant += 1
        # Locomoção usa canais próprios e não corta o impacto do dash.
        index = {'step': 12, 'climb': 13, 'dash': 14, 'checkpoint': 15}.get(name, self.voice % 12)
        if index < 12:
            self.voice += 1
        channel = pygame.mixer.Channel(index)
        pan = max(-.65, min(.65, pan))
        mix = {'dash': .40, 'checkpoint': .52, 'land': .68, 'dash_hit': .68, 'step': .78,
               'climb': .55, 'jump': .60, 'wall_jump': .60}.get(name, .8)
        volume = max(0, min(1, strength))*mix
        channel.set_volume(volume*(1-max(0, pan)), volume*(1+min(0, pan)))
        channel.play(sound)
