"""Salas da corrida: ensinar, variar, combinar. Geometria deliberada por círculo.

Tetos presos ao alto do mundo impedem atalhos por cima das salas. As fogueiras
separam desafios; a precisão exigida aumenta, sem remover os retornos seguros.
"""
from dataclasses import replace
from .modelo import floor, ledge

ROUTES = (
 # Limbo: pista de impulso, degraus largos, queda de volta ao pátio.
 ((2470,490,350),(2920,440,200),(3220,380,210),(3540,470,250),
  (3890,470,220),(4220,410,180),(4500,490,300)),
 # Luxúria: varandas expostas, sobe, cruza uma torre, desce sob um arco.
 ((2470,430,230),(2810,350,150),(3070,270,150),(3330,350,140),
  (3580,450,230),(3920,380,140),(4180,300,130),(4430,460,370)),
 # Gula: alternância entre galerias baixas e poços abertos ao granizo.
 ((2470,490,250),(2830,490,120),(3060,420,150),(3320,490,140),
  (3570,510,240),(3920,440,120),(4150,510,130),(4410,500,390)),
 # Avareza: pista do peso, contrafortes altos e poço entre cofres.
 ((2470,490,330),(2910,405,110),(3140,320,120),(3380,405,105),
  (3610,490,230),(3960,400,100),(4200,315,100),(4440,490,360)),
 # Ira: ilhas, vigas sob aquedutos e entradas laterais.
 ((2470,500,220),(2810,430,110),(3040,350,110),(3280,430,105),
  (3510,510,230),(3860,430,100),(4100,350,100),(4350,460,110),(4580,500,220)),
 # Heresia: sobe entre criptas, cai numa nave baixa e volta a subir.
 ((2470,490,210),(2800,400,100),(3030,310,100),(3270,235,100),
  (3500,440,220),(3840,360,90),(4070,285,90),(4320,385,90),(4550,490,250)),
 # Violência: três arcos de salto, pilares estreitos e chuva de brasas.
 ((2470,490,220),(2820,400,95),(3060,310,90),(3300,400,85),
  (3540,500,200),(3870,410,85),(4110,320,80),(4350,410,85),(4580,490,220)),
 # Fraude: apoios efêmeros entre ilhas firmes; pouso precede a corrente.
 ((2470,480,200),(2820,400,90),(3060,320,85),(3300,400,85),
  (3540,480,190),(3860,390,80),(4100,310,75),(4340,400,80),(4570,480,230)),
 # Traição: exame final de controle aéreo, frenagem no gelo e dash preciso.
 ((2460,360,180),(2808,300,74),(3038,410,68),(3278,330,68),
  (3510,460,180),(3838,390,64),(4078,310,64),(4308,420,68),(4540,430,260)),
)

# x, y, largura, altura; são sólidos de colisão, não decoração.
CEILINGS = (
 ((0,0,700,220),(2460,0,370,300),(3530,0,580,260)),
 ((0,0,300,240),(740,0,530,100),(2460,0,250,230),(3550,0,280,275),(4410,0,390,240)),
 ((0,0,490,300),(2470,0,260,370),(2810,0,170,345),(3290,0,190,335),(3550,0,270,365),(4120,0,190,345),(4400,0,400,330)),
 ((0,0,300,280),(1000,0,230,280),(2460,0,350,300),(2890,0,150,230),(3360,0,150,245),(3600,0,260,315),(4180,0,140,170)),
 ((0,0,350,300),(820,0,370,300),(2460,0,240,325),(3020,0,150,195),(3490,0,260,345),(4080,0,150,195),(4550,0,250,315)),
 ((0,0,830,280),(2460,0,240,310),(3010,0,140,155),(3480,0,260,290),(4050,0,140,130),(4530,0,270,320)),
 ((0,0,320,280),(780,0,170,270),(2450,0,260,315),(3040,0,130,150),(3520,0,240,335),(4090,0,130,165),(4550,0,250,315)),
 ((0,0,310,290),(940,0,180,280),(2450,0,240,310),(3040,0,130,165),(3520,0,230,320),(4080,0,120,160),(4540,0,260,310)),
 ((0,0,320,310),(790,0,180,265),(1590,0,170,265),(2440,0,220,190),
  (2780,0,130,165),(3010,0,125,265),(3250,0,125,185),(3490,0,220,300),
  (3810,0,120,245),(4050,0,120,165),(4280,0,125,275),(4510,0,290,195)),
)

STORIES = (
    ('O pátio sem nomes', 'As portas ruíram. A passagem continua.'),
    ('A varanda partida', 'O vento leva os véus; não leva sua vontade.'),
    ('O salão vazio', 'Nada resta à mesa de quem devorou sua vida.'),
    ('O cofre aberto', 'A riqueza ficou. Alice seguiu.'),
    ('A outra margem', 'Entre duas rajadas, há um instante de silêncio.'),
    ('Acima das fogueiras', 'As perguntas sobem onde a fumaça não alcança.'),
    ('O bosque ferido', 'Mesmo entre ruínas, existe um caminho.'),
    ('A promessa quebrada', 'Observe o apoio antes de confiar no brilho.'),
    ('A última prisão', 'O céu já não parece tão distante.'),
)


def expand(base, index):
    route = ROUTES[index]
    platforms = list(base.platforms)
    platforms += [floor(x,y,w) if w >= 180 else ledge(x,y,w) for x,y,w in route]
    platforms += CEILINGS[index]
    hazards = [h for h in base.hazards if h[0] not in ('slush','swamp')]
    # O primeiro perigo é isolado e tem espaço de frenagem; depois combinamos
    # restrição do teto, precisão do pouso e uma ameaça anunciada.
    extras = (
      (),
      (('orb',3130,235,100,16,.7),),
      (('rune',2630,390,48,100,0),('hail',2980,180,40,9,.4),('hail',4030,200,40,9,1.8)),
      (('boulder',2650,467,180,23,.7),('spikes_timed',3690,470,40,20,0),('pendulum',2690,300,125,42,.3)),
      (('vapor',3620,410,40,100,.4),('rune',2560,400,36,100,0)),
      (('rune',3590,340,40,100,0),('ember',3980,160,40,9,1.4)),
      (('ember',3980,160,45,9,.4),('arrow',3480,355,180,8,1.8),('spikes',2590,470,44,20,0)),
      (('chain',3440,310,14,130,.5),('rune',3660,390,36,90,0),('pendulum',2650,310,110,36,.8)),
      (('frost',3620,360,35,100,.8),('chain',4470,245,14,180,1.6)),
    )
    hazards += extras[index]
    # Espinhos sob as vergas punem saltos altos; nunca escondidos na textura.
    if index >= 2:
        for x,y,w,h in CEILINGS[index][-(index//2+1):]:
            hazards.append(('spikes_down',x+20,h,w-40,16,0))
    # Os últimos círculos exigem pousar no miolo, não só tocar uma borda.
    if index >= 5:
        for n in ((2,6) if index < 8 else (1,2,3,5,6,7)):
            x,y,w=route[n]
            hazards.append(('spikes',x,y-14,12,14,0))
            if index == 8:
                hazards.append(('spikes',x+w-12,y-14,12,14,0))
    illusions = base.illusion_x + ((2820,3300,4100) if index == 7 else ())
    checkpoints = (base.checkpoints[0], base.checkpoints[1],
                   (route[0][0]+35,route[0][1]),(route[4][0]+35,route[4][1]))
    inscriptions = ((route[0][0]+20,max(125,route[0][1]-270),*STORIES[index]),)
    if index == 0:
        inscriptions = ((65,400,'A / D: mover. ESPAÇO: pular.','Segure o salto para subir mais.'),
                        (480,310,'K + direção: dash','Pouse para recuperar a carga.'),
                        (1080,220,'L + W: escalar. ESPAÇO: salto de parede.','As faces claras podem ser usadas para subir.'),
                        (2470,330,'Dash no chão, depois salto: wavedash','Menos tempo no chão, mais velocidade.'))
    return replace(base,platforms=tuple(platforms),checkpoints=checkpoints,seal_feet=(),
                   exit=(4700,route[-1][1]),hazards=tuple(hazards),illusion_x=illusions,
                   inscriptions=inscriptions,runes=(),ash=())
