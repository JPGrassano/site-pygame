"""As travessias de Cócito: alternância entre travessia, paredes e plataformas móveis."""
from .modelo import Layout, floor, ledge

LAYOUT = Layout(
    name='As travessias de Cócito',
    platforms=(
        floor(0,560,320),
        floor(790,430,180),
        floor(990,570,340),
        (1110,0,70,480),
        floor(1330,200,110),
        floor(1590,430,170),
        floor(1760,570,280),
        (1820,0,70,480),
        floor(2040,180,110),
        floor(2250,360,150),
    ),
    checkpoints=((150, 560), (880, 430), (1675, 430)),
    seal_feet=((1385, 200), (2095, 180), (2290, 360)), exit=(2350, 360),
    shafts=((1180, 1330, 570, 200), (1890, 2040, 570, 180)),
    movers=((440, 500, 100, 24, 130, -60, 3.8, 0),),
    hazards=(('frost', 795, 320, 55, 110, 0.2), ('frost', 1595, 320, 50, 110, 1.8)),
    illusion_x=(),
)
