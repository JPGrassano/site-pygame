"""Ranking local de corridas completas. Escrita atômica, nomes Unicode e empates estáveis."""
import json
import os
import unicodedata
from pathlib import Path
from progresso import default_path

COURSE = 'nove-circulos-corrida-2026-10-v2'
MAX_NAME = 18


def clean_name(value):
    value = unicodedata.normalize('NFC', str(value))
    return ''.join(c for c in value if c.isalnum() or c in " -_.'")[:MAX_NAME]


def duration_ms(value):
    value = max(0, int(value))
    seconds, ms = divmod(value, 1000)
    minutes, seconds = divmod(seconds, 60)
    return f'{minutes:02d}:{seconds:02d}.{ms:03d}'


class RankingStore:
    def __init__(self, path=None):
        self.path = Path(path) if path else default_path().with_name('ranking.json')
        self.error = ''

    def load(self):
        self.error = ''
        if not self.path.exists():
            return []
        try:
            data = json.loads(self.path.read_text(encoding='utf-8'))
            if not isinstance(data, dict) or data.get('version') != 1 or not isinstance(data.get('runs'), list):
                raise ValueError('Formato do ranking inválido')
            records = []
            for r in data['runs']:
                if (isinstance(r, dict) and isinstance(r.get('name'), str)
                        and clean_name(r['name']).strip() and type(r.get('milliseconds')) is int
                        and 0 < r['milliseconds'] < 604800000 and type(r.get('deaths')) is int
                        and 0 <= r['deaths'] < 1000000 and isinstance(r.get('id'), str)
                        and isinstance(r.get('course'), str)):
                    records.append({**r, 'name': clean_name(r['name']).strip()})
            return records
        except (OSError, ValueError, TypeError) as error:
            self.error = str(error)
            return []

    def entries(self):
        return sorted((r for r in self.load() if r['course'] == COURSE), key=lambda r:r['milliseconds'])

    def add(self, name, milliseconds, deaths, run_id):
        records = self.load()
        if self.error:  # Não sobrescrever um arquivo ilegível.
            return False
        name = clean_name(name).strip()
        if (not name or type(milliseconds) is not int or not 0 < milliseconds < 604800000
                or type(deaths) is not int or not 0 <= deaths < 1000000
                or not isinstance(run_id, str) or not run_id):
            self.error = 'Digite um nome e conclua uma corrida válida.'
            return False
        if any(r['id'] == run_id for r in records):
            return True  # Enter repetido não duplica uma corrida.
        records.append(dict(id=run_id,name=name,milliseconds=milliseconds,deaths=deaths,course=COURSE))
        temp = self.path.with_suffix('.tmp')
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            temp.write_text(json.dumps({'version':1,'runs':records},ensure_ascii=False,indent=2),encoding='utf-8')
            os.replace(temp,self.path)
            return True
        except (OSError, ValueError) as error:
            self.error = str(error)
            return False
