@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
    py jogo.py
) else (
    python jogo.py
)
if errorlevel 1 (
    echo.
    echo Nao foi possivel iniciar. Veja o arquivo LEIA-ME.txt.
    echo Se faltar pygame, execute: py -m pip install -r requirements.txt
    pause
)
endlocal
