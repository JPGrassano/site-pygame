"""As pistas dos pesos: alternância entre travessia, paredes e plataformas móveis."""
from .modelo import Layout, floor, ledge

LAYOUT = Layout(
    name='As pistas dos pesos',
    platforms=(
        floor(0,570,545),
        (350,0,70,480),
        floor(545,300,110),
        floor(780,430,180),
        floor(1010,490,220),
        floor(1670,390,180),
        ledge(2050,300,100),
        floor(2250,490,150),
    ),
    checkpoints=((150, 570), (870, 430), (1760, 390)),
    seal_feet=((2100, 300),), exit=(2330, 490),
    shafts=((420, 545, 570, 300),),
    movers=((1370, 470, 110, 24, 130, -80, 4.1, 0),),
    hazards=(('boulder', 1120, 467, 175, 23, 0), ('boulder', 2100, 281, 74, 19, 1.1)),
    illusion_x=(),
)
