"""O elevador dos sepulcros: alternância entre travessia, paredes e plataformas móveis."""
from .modelo import Layout, floor, ledge

LAYOUT = Layout(
    name='O elevador dos sepulcros',
    platforms=(
        floor(0,570,380),
        floor(520,530,260),
        floor(920,440,200),
        floor(1380,570,305),
        (1480,0,70,480),
        floor(1685,210,110),
        ledge(1930,305,110),
        floor(2200,490,200),
    ),
    checkpoints=((150, 570), (1020, 440), (1740, 210)),
    seal_feet=((1985, 305),), exit=(2320, 490),
    shafts=((1550, 1685, 570, 210),),
    movers=((1280, 450, 110, 24, 0, -130, 3.8, 0),),
    hazards=(('fire', 560, 420, 65, 110, 0), ('fire', 690, 420, 65, 110, 1.9), ('fire', 2220, 380, 50, 110, 2.5)),
    illusion_x=(),
)
