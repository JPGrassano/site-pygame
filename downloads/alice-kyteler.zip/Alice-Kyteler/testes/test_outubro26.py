"""Regressões de stamina, botão de áudio, leitura e armadilhas sinalizadas."""
import os
os.environ['SDL_VIDEODRIVER']='dummy';os.environ['SDL_AUDIODRIVER']='dummy'
import unittest,uuid
from pathlib import Path
from dataclasses import replace
from unittest.mock import patch
import pygame
from personagem import Player,Controls,STEP,MAX_STAMINA
from perigos import Hazard
from motor import Game
from audio import SoundDesign
from armadilhas_arte import atlas

class OctoberTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  pygame.display.init();pygame.display.set_mode((1100,650));pygame.font.init()
 def game(self):
  folder=Path(__file__).parent/'_temporario'/uuid.uuid4().hex;folder.mkdir(parents=True)
  g=Game(folder/'save.json',headless=True)
  def cleanup():
   for f in folder.iterdir():f.unlink()
   folder.rmdir()
  self.addCleanup(cleanup)
  return g
 def wall_player(self):
  return Player((489,1200),(4800,2000),False),pygame.Rect(500,0,60,2000)
 def test_climb_last_more_than_two_seconds_and_holding_drains_slowly(self):
  losses=[]
  for y in (-1,0,1):
   p,wall=self.wall_player()
   for _ in range(120):p.update(STEP,Controls(y=y,grab=True),[wall])
   losses.append(MAX_STAMINA-p.stamina)
  self.assertLess(losses[1],losses[0]*.3)
  self.assertLess(losses[1],losses[2])
  p,wall=self.wall_player()
  for _ in range(240):p.update(STEP,Controls(y=-1,grab=True),[wall])
  self.assertGreater(p.stamina,0);self.assertLess(p.rect.bottom,1000)
 def test_landing_restores_full_stamina(self):
  p=Player((200,500));p.stamina=.02
  p.update(STEP,Controls(),[pygame.Rect(0,500,600,400)])
  self.assertEqual(p.stamina,MAX_STAMINA)
 def test_mute_button_respects_scaled_viewport_and_does_not_unpause(self):
  g=self.game();g.new_game();g.change_state('paused');g.draw()
  center=g.pause_sound_rect.center
  g.viewport=pygame.Rect(30,40,1650,975)
  pos=(round(30+center[0]*1.5),round(40+center[1]*1.5))
  pygame.event.post(pygame.event.Event(pygame.MOUSEBUTTONDOWN,pos=pos,button=1));g.events()
  self.assertTrue(g.audio.muted);self.assertEqual(g.state,'paused')
  pygame.event.post(pygame.event.Event(pygame.KEYDOWN,key=pygame.K_F3));g.events()
  self.assertFalse(g.audio.muted);self.assertEqual(g.state,'paused');self.assertEqual(g.progress['seconds'],0)
 def test_dash_gain_is_quieter(self):
  audio=SoundDesign(enabled=False);audio.available=True;audio.sounds={'dash':[object()]}
  with patch('audio.pygame.mixer.Channel') as channel:
   audio.play('dash')
   channel.return_value.set_volume.assert_called_once_with(.4,.4)
 def test_instructions_remain_visible_in_front_of_solid_wall(self):
  g=self.game();g.load_chapter(0,intro=False)
  g.world.layout=replace(g.world.layout,inscriptions=((980,200,'LEIA AQUI','Mesmo diante da parede.'),))
  g.world.camera_x=900;g.draw_world()
  font=g.world.inscription_font
  mask=pygame.mask.from_surface(font.render('LEIA AQUI',True,(220,188,237)),200)
  # Todos os pixels opacos da letra mantêm sua cor, inclusive sobre o pilar.
  checked=0
  for x in range(mask.get_size()[0]):
   for y in range(mask.get_size()[1]):
    if mask.get_at((x,y)):
     color=g.scene.get_at((80+14+x,200+10+y))
     self.assertGreater(color.r,160);self.assertGreater(color.b,180);checked+=1
  self.assertGreater(checked,30)
 def test_rune_warns_then_fires_and_cools_down(self):
  h=Hazard('rune',100,400,48,100,0);feet=pygame.Rect(110,466,22,34)
  self.assertFalse(h.hits(feet,10));h.update(10,feet)
  self.assertEqual(h.rune_state(10.54),'charging');self.assertFalse(h.hits(feet,10.54))
  self.assertTrue(h.hits(feet,10.56));self.assertFalse(h.hits(feet,11.0))
  h.update(12.5,feet.move(200,0));self.assertEqual(h.rune_state(12.5),'idle')
 def test_running_across_rune_escapes_before_burst(self):
  h=Hazard('rune',100,400,48,100,0)
  for tick in range(120):
   t=tick*STEP;rect=pygame.Rect(round(75+235*t),466,22,34)
   h.update(t,rect);self.assertFalse(h.hits(rect,t))
  self.assertIsNotNone(h.triggered_at)
 def test_timed_iron_spikes_are_safe_during_warning(self):
  h=Hazard('spikes_timed',100,480,48,20,0);rect=pygame.Rect(110,476,22,24)
  self.assertFalse(h.hits(rect,.7));self.assertTrue(h.hits(rect,1.2));self.assertFalse(h.hits(rect,2.4))
 def test_pendulum_empty_pixels_and_chain_do_not_hurt(self):
  h=Hazard('pendulum',300,200,120,24,0)
  image,mask,bounds=h.pendulum_pose(0)
  solid=mask.outline()[0]
  self.assertTrue(h.hits(pygame.Rect(bounds.x+solid[0],bounds.y+solid[1],1,1),0))
  self.assertFalse(h.hits(pygame.Rect(bounds.x,bounds.y,1,1),0))
  self.assertFalse(h.hits(pygame.Rect(298,230,4,10),0))
 def test_sprite_sheet_has_real_transparency(self):
  self.assertEqual(atlas().get_at((1535,0)).a,0)

if __name__=='__main__':unittest.main()
