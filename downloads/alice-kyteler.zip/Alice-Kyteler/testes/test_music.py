import os
import unittest
from unittest.mock import patch

os.environ['SDL_AUDIODRIVER'] = 'dummy'
import pygame
from audio import SoundDesign, SOUND_ROOT, CHAPTER_MUSIC


class MusicTests(unittest.TestCase):
    def setUp(self):
        self.audio = SoundDesign(enabled=False)
        self.audio.available = True

    @patch('audio.pygame.mixer.music')
    def test_loop_and_no_restart_on_pause_or_same_chapter(self, music):
        for state in ('playing', 'paused', 'controls', 'playing', 'descending'):
            self.audio.set_music_context(0, state, 'paused')
        music.load.assert_called_once_with(str(SOUND_ROOT / 'Saxa_Silentia.mp3'))
        music.play.assert_called_once_with(loops=-1, fade_ms=1200)
        self.assertIn(((.18 * .35,),), [tuple(c)[:1] for c in music.set_volume.call_args_list])

    @patch('audio.pygame.mixer.music')
    def test_switching_tracks_then_leaving_supported_circles_fades(self, music):
        self.audio.set_music_context(0, 'playing')
        self.audio.set_music_context(1, 'playing')
        self.audio.set_music_context(8, 'playing')
        music.fadeout.assert_called_once_with(700)
        self.assertEqual(music.play.call_count, 2)

    @patch('audio.pygame.mixer.stop')
    @patch('audio.pygame.mixer.music')
    def test_mute_unmute_and_menu(self, music, stop):
        self.audio.set_music_context(0, 'playing')
        self.audio.toggle()
        music.set_volume.assert_called_with(0)
        self.audio.toggle()
        music.set_volume.assert_called_with(.18)
        self.audio.set_music_context(0, 'menu')
        music.fadeout.assert_called_once_with(700)
        self.audio.set_music_context(0, 'controls', 'menu')
        self.assertEqual(music.play.call_count, 1)

    @patch('audio.pygame.mixer.music')
    def test_headless_never_uses_music_device(self, music):
        self.audio.available = False
        self.audio.set_music_context(0, 'playing')
        music.load.assert_not_called()

    @patch('audio.pygame.mixer.music')
    def test_missing_track_does_not_crash_game(self, music):
        music.load.side_effect = pygame.error('missing file')
        self.audio.set_music_context(0, 'playing')
        self.assertIsNone(self.audio.music_track)
        self.assertEqual(len(self.audio.recording_errors), 1)

    def test_real_mp3_stream_loads_and_loops(self):
        pygame.mixer.init()
        try:
            for chapter in CHAPTER_MUSIC:
                self.audio.set_music_context(chapter, 'playing')
                self.assertTrue(pygame.mixer.music.get_busy())
                self.assertAlmostEqual(pygame.mixer.music.get_volume(), .18, delta=.01)
            pygame.mixer.music.stop()
        finally:
            pygame.mixer.quit()

    @patch('audio.pygame.mixer.music')
    def test_supplied_tracks_loop_without_restart_on_pause(self,music):
        for chapter in (1,2,3):
            before=music.play.call_count
            for state in ('playing','paused','controls','playing'):
                self.audio.set_music_context(chapter,state,'paused')
            self.assertEqual(music.play.call_count,before+1)
            music.load.assert_called_with(str(SOUND_ROOT/CHAPTER_MUSIC[chapter]))
