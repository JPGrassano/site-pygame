"""Salvamento local validado e escrita atômica, sem dependências externas."""
import json
import os
from pathlib import Path


def default_path():
    # O executável pode estar em uma pasta protegida; o save pertence ao usuário.
    base = Path(os.environ.get("LOCALAPPDATA", str(Path.home())))
    return base / "AliceKyteler" / "progresso.json"


def fresh_progress():
    return {"version": 1, "chapter": 0, "checkpoint": 0, "seals": [],
            "unlocked": 0, "deaths": 0, "seconds": 0.0, "completed": False,
            "started": False}


class SaveStore:
    def __init__(self, path=None):
        self.path = Path(path) if path else default_path()
        self.error = ""

    def load(self):
        result = fresh_progress()
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(raw, dict):
                return result
            for key, high in (("chapter", 8), ("checkpoint", 3), ("unlocked", 8), ("deaths", 999999)):
                value = raw.get(key, 0)
                if isinstance(value, int) and not isinstance(value, bool):
                    result[key] = max(0, min(high, value))
            seconds = raw.get("seconds", 0)
            if isinstance(seconds, (int, float)) and 0 <= seconds < 1e9:
                result["seconds"] = float(seconds)
            for key in ("completed", "started"):
                result[key] = raw.get(key) is True
            seals = raw.get("seals", [])
            if isinstance(seals, list):
                result["seals"] = sorted({i for i in seals if type(i) is int and 0 <= i < 3})
            result["unlocked"] = max(result["unlocked"], result["chapter"])
        except (OSError, ValueError, TypeError):
            pass
        return result

    def save(self, progress):
        temporary = self.path.with_suffix(".tmp")
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            temporary.write_text(json.dumps(progress, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
            os.replace(temporary, self.path)
            self.error = ""
            return True
        except (OSError, ValueError, TypeError) as error:
            self.error = str(error)
            return False
