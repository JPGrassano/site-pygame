"""Tipografia, botões, textos e HUD. Não altera a física ou o progresso."""
from ranking import duration_ms
import math
from pathlib import Path

import pygame

INK = (17, 17, 30)
PAPER = (238, 228, 237)
MUTED = (174, 164, 188)
GOLD = (228, 196, 146)
VIOLET = (192, 164, 235)


class Interface:
    def __init__(self):
        self.fonts = {
            "title": pygame.font.Font(str(Path(__file__).parent/"fontes"/"Georgia.ttf"), 57),
            "heading": pygame.font.Font(str(Path(__file__).parent/"fontes"/"Georgia.ttf"), 37),
            "sub": pygame.font.Font(str(Path(__file__).parent/"fontes"/"Coolvetica Rg.otf"), 24),
            "body": pygame.font.Font(str(Path(__file__).parent/"fontes"/"Coolvetica Rg.otf"), 21),
            "small": pygame.font.Font(str(Path(__file__).parent/"fontes"/"Coolvetica Rg.otf"), 16),
            "tiny": pygame.font.Font(str(Path(__file__).parent/"fontes"/"Coolvetica Rg.otf"), 13),
        }
        self.buttons = []

    def text(self, surface, value, x, y, font="body", color=PAPER, center=False, right=False):
        image = self.fonts[font].render(str(value), True, color)
        rect = image.get_rect(topleft=(round(x), round(y)))
        if center:
            rect.centerx = round(x)
        if right:
            rect.right = round(x)
        surface.blit(image, rect)
        return rect

    def paragraph(self, surface, value, x, y, width, font="body", color=PAPER, spacing=9):
        face = self.fonts[font]
        words, line = value.split(), ""
        for word in words:
            trial = (line+" "+word).strip()
            if face.size(trial)[0] > width and line:
                self.text(surface, line, x, y, font, color)
                y += face.get_linesize()+spacing
                line = word
            else:
                line = trial
        if line:
            self.text(surface, line, x, y, font, color)
            y += face.get_linesize()+spacing
        return y

    def veil(self, surface, alpha=195):
        layer = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        layer.fill((*INK, alpha))
        surface.blit(layer, (0, 0))

    def panel(self, surface, rect, alpha=230):
        layer = pygame.Surface(rect.size, pygame.SRCALPHA)
        pygame.draw.rect(layer, (20, 19, 34, alpha), layer.get_rect(), border_radius=10)
        pygame.draw.rect(layer, (83, 68, 102, 230), layer.get_rect(), 1, border_radius=10)
        surface.blit(layer, rect)

    def menu(self, surface, options, selected, x, y, width=320, line=43):
        self.buttons = []
        for i, (label, enabled) in enumerate(options):
            rect = pygame.Rect(x, y+i*line, width, line-5)
            if i == selected:
                pygame.draw.rect(surface, (61, 45, 79), rect, border_radius=5)
                pygame.draw.rect(surface, VIOLET, (rect.left, rect.top+6, 3, rect.height-12))
            self.text(surface, label, x+21, rect.y+4, color=PAPER if enabled else (100, 94, 113))
            self.buttons.append((rect, i))

    def ornament(self, surface, x, y, width=240, color=GOLD):
        pygame.draw.line(surface, color, (x-width//2, y), (x-10, y))
        pygame.draw.line(surface, color, (x+10, y), (x+width//2, y))
        pygame.draw.polygon(surface, color, ((x, y-5), (x+5, y), (x, y+5), (x-5, y)), 1)

    @staticmethod
    def duration(seconds):
        whole = int(seconds)
        return f"{whole//3600:02d}:{whole//60%60:02d}:{whole%60:02d}"

    def hud(self, surface, world, player, progress, toast="", toast_time=0, death_timer=0):
        chapter = world.chapter
        layer = pygame.Surface((1100, 91), pygame.SRCALPHA)
        for y in range(91):
            pygame.draw.line(layer, (15, 14, 27, max(0, 220-y*2)), (0, y), (1100, y))
        surface.blit(layer, (0, 0))
        self.text(surface, f"{chapter.number:02d} / 09", 27, 18, "tiny", chapter.accent)
        self.text(surface, chapter.name.upper(), 27, 36, "sub")
        self.text(surface, chapter.subtitle, 160, 43, "small", MUTED)
        self.text(surface, f"{progress['deaths']} quedas  ·  {duration_ms(round(progress['seconds']*1000))}",
                  1067, 44, "tiny", MUTED, right=True)
        self.text(surface, "WASD  mover    ESPAÇO  pular    K  dash    L + W/S  escalar", 28, 630, "tiny", MUTED)
        self.text(surface, "ESC  pausa", 1070, 630, "tiny", MUTED, right=True)
        if toast_time > 0:
            self.notice(surface, toast, chapter.accent)
        elif world.open and player.rect.centerx > world.portal.x-400:
            self.notice(surface, "Caia na fenda iluminada para descer ao próximo círculo.", chapter.accent)
        if death_timer:
            self.veil(surface, int(85*death_timer/.32))

    def notice(self, surface, message, color=VIOLET):
        image = self.fonts["small"].render(message, True, PAPER)
        rect = pygame.Rect(0, 91, image.get_width()+34, 36)
        rect.centerx = 550
        self.panel(surface, rect, 225)
        pygame.draw.circle(surface, color, (rect.x+11, rect.centery), 2)
        surface.blit(image, (rect.x+23, rect.y+6))

    def story(self, surface, eyebrow, title, lines, footer="ENTER / ESPAÇO  continuar", color=GOLD, alpha=210):
        self.veil(surface, alpha)
        self.ornament(surface, 550, 95, 240, color)
        self.text(surface, eyebrow, 550, 119, "small", color, center=True)
        self.text(surface, title, 550, 155, "heading", PAPER, center=True)
        y = 228
        for line in lines:
            y = self.paragraph(surface, line, 225, y, 650)
            y += 15
        self.text(surface, footer, 550, 589, "small", MUTED, center=True)
